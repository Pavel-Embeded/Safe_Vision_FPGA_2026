# 26101716：写入口/物理命令首字记录与双方向诊断

26101715实际报告首轮CFG=001、W/R/CAP均0400、BAD=0400；首错字地址0，期望A55A3CC3、实际00000000。报告已保存到evidence/v3/board_uart_20261017/adapter_path_26101715。该轮用未经修改的生产适配器写、直接对齐读，未经过适配器读缓存，因此至少写入通路有故障；仍不能单凭首字零值认定全部字为零或BRAM/加密IP中某一项已被唯一定位。

本诊断继续保持生产sdram_app_adapter字节不变，默认两轮，第一轮适配器写/直接读，第二轮直接写/适配器读；即使某轮数据出错，仍输出报告并进行下一轮。每轮1024字连续地址、相同地址签名图案，慢写间隔512MEM周期，所有物理突发/掩码及排空规则沿用26101715。跨轮只清适配器控制，不清SDRAM；第二轮使用直接路径重新写入全部测试数据，避免把第一轮坏数据继承到第二轮。

每轮UART报告231字节，首行SVADP26101716，共两份报告。新增一行`TX=xxxxxxxx INPT=xxxxxxxx DM=x CNT=xxxx`：INPT是第一个真正接受写事务边沿的源数据，TX/DM是第一个真正进入厂商控制器的App_wr_en边沿上的数据/掩码；CNT统计该轮DM=0的物理写命令数。正确首字应为A55A3CC3、DM=0、CNT=0400。数据不符定位仍由BAD0给出；两个方向各自清首错，累计TOT保留。任意一轮数据或超时失败，最终LED保持错误状态，不能由后一个通过覆盖错误。

理想接口模型覆盖两个方向以及各自一个单字故障，384次比较、24项检查；1386字节的六份UART报告包含真实引脚串行接收解码和独立预计算逐字节比较。验证包含“先坏后好仍判整次失败”“第一轮出错仍完成第二轮”、写输入反压稳定和64次单字掩码补拍。之前26101715模型另有六种图案双向全覆盖。模型不验证真实BRAM宏、厂商加密IP或电气时序。本诊断临时HDMI无图，完整应用保留，不是删减功能的发布版。

仿真入口safevision/tools/run_v3_sim.py --suite adapter_path_trace --run-dir <新的ASCII目录>；原生入口safevision/tools/run_adapter_path_trace.py --run-dir <新的ASCII目录>。必须完成新进程冻结route.db的Slow/Fast setup/hold/recovery/removal复核并绑定当前输入后，才可用finalize_adapter_path_trace.py生成诊断位流。GitHub不上传。当前尚无26101716实板结果。

已生成本地诊断位流：artifacts/diagnostics/adapter_trace_26101716/SafeVision_ADAPTER_TRACE_26101716.bit，629645字节，SHA-256 35ea2969944530117ac0115a40cb885bcb4ee79a573b8a9a85b8598a3ab83da5。源码绑定883f3da9ca83f5557c01c20836bb7edb7de27ea6，32项输入均核对Git对象。Slow/Fast最小setup+1.174ns、hold+0.095ns、recovery+6.891ns、removal+0.084ns。交付目录包含原始时序、冻结源码、route.db和逐文件载荷指纹。先打开COM6，再用PROGRAM_SRAM下载，保持供电、不按CONFIG1；暂时HDMI无图，等待两份各231字节的真实报告。

## KEY1复位后的真实报告

2026-10-17，首次下载后的串口等待在人工确认前已超时，未收到字节，此次空记录不构成硬件失败。重新打开COM6，用户按KEY1后实际收到462字节，两组各1024次比较均BAD=0000；TX与INPT均A55A3CC3、DM=0、CNT=0400。已逐字节核对完整两帧，并用7项错误/截断主机负控确认审核拒绝。原始记录与条件化验收见evidence/v3/board_uart_20261017/adapter_trace_26101716_key1。

该结论只覆盖同一组连续1024个字地址、一个图案和这次KEY1复位后的两组路径；不是六图案长稳、冷启动或完整应用通过。26101715与16为不同映射程序，因此二者一坏一好也不能单独证明POR/复位、BRAM或厂商IP的唯一根因。先用同一完整BASE位流做自动启动和KEY1复位的受控对照，再决定生产修改。
