# 独立 SDRAM 对照自检 26101612

这是临时硬件排查程序，**不是完整 BASE/HD 应用**。完整工程和全部媒体功能保留；本程序下载到 SRAM 后不输出 HDMI 图片。完成对照后仍须下载最终应用并验证，不能把独立自检成功当作媒体整机通过。GitHub 不上传。

复用现有 `top_sdram_loopback` 的图案、比较流水、超时和 190 字节报告，仅在独立副本中选择当前 V3 的原厂 `sv_v3_memory_pll`、MEM50MHz、SDRAM +8ns、4096 刷新行、下降沿释放 MEM 复位。输入输出仍用原板卡管脚；原加密 SDRAM 文件未修改。该对照直接驱动厂商应用接口，不经过 V3 的 `sdram_app_adapter`、SD/FAT、FIFO、行 CRC、视频和音频装配，因此可以帮助划分排查范围，不能排除完整工程的物理布局影响。

硬件默认六轮图案，每轮比较 1024 个稀疏地址，步长 2049，跨越 21 位地址范围；这不是逐一覆盖全部 2M 字。突发 16 个命令，间隔 16 拍，写后独立等待落地再读取。任一轮发生不符即停止并记录首错轮次、地址、期望和实际。UART 115200/8N1 抬头为 `SV3-M50P8-DIR`，只在完成时发送一次 190 字节报告，所以应先开采集，再下载/按 KEY1。CONFIG1 会重载 Flash，不能用于本次复位。

健康报告必须同时满足：INIT/LOCK 均为 1；CFG=0B1、BASE=000000、N=000400；RND=00000006/00000006、PAT=5；W/R/CAP 均为 0400；BAD=0000；TOT=0000001800。只看到 DONE 或 LED=8 不足以验收。自检 LED 是原回环程序的数字状态码，与完整 V3 的四个独立含义不同。

对应源文件是 `platform/anlogic_eg4s20_hx4s20c/rtl/sv_v3_m50p8_probe.v`，约束和显式源清单位于 `platform/anlogic_eg4s20_hx4s20c/project/m50p8_direct_26101612`。可以运行：

```powershell
python safevision/tools/run_v3_sim.py --suite m50p8_direct --run-dir D:/Codex/probe_sim_new
python safevision/tools/run_m50p8_direct_probe.py --run-dir D:/Codex/probe_native_new
```

模型测试核对完整串口报告，并注入第二轮单比特错误验证 fail-fast 和首错定位；厂商加密内部和 SDRAM 电气不由该模型证明。当前原生路由及独立进程复核均通过；扩大到 4646 条详细路径后，Slow/Fast 四类检查最小裕量为 setup +1.225ns、hold +0.151ns、recovery +7.671ns、removal +10.057ns，零负路径，必需健康检查为零。资源 1561 LUT、1177 DFF、1 PLL，无片上 RAM/DSP。原始报告和位流指纹以本地独立索引为准，板上结果尚待采集。

本地下载包路径为 `artifacts/diagnostics/m50p8_direct_26101612`；只有实际生成 `probe.index.json` 后才可使用。下载模式选择 PROGRAM_SRAM，保持供电，之后读取实际数据。若自检成功，继续对适配器和媒体写入形态做对照；若失败，先据首错数据调查同一时钟下的直接 SDRAM 路径。
