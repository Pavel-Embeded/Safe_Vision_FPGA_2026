# SafeVision 26101723 本地板级修复包

批准源码/功能证据/发布工具提交：10629460d014e7c07d29a857cdd86f54aa21d888。
工程候选：True；双模式发布：False。
本包保持完整应用。26101722四拍补齐的实板对照已完成12480字比较零错误，含192个相邻保护字；其单字写故障修正已集成，但完整应用的TF缓存、HDMI、音频和实体按键仍需本包烧录后分别验证。旧16同图案KEY1通过记录存在残留同图案盲点，不能用来证明有效写入。

本包内每份bit均由最终全角时序、资源、约束健康、源码字节一致性及当前113正向/41严格负向测试门禁通过的冻结route.db生成。另有14项补充契约测试。BASE工程候选即使先于HD完成，也没有放宽BASE任何门禁；仅当two_mode_release=true才可声称两种模式离线构建均通过。

source/保留该bit批准时的精确构建输入和功能证据。运行verify_payload.py可核对全部载荷哈希、冻结源码/证明字节、113/41主门禁、14项补充契约及原始STA。该校验不替代新一次布局布线或实体板测；后续HD参数调试不得改写本包冻结源或证据。旧B测试输出格式和长媒体监视超时的独立原始日志审计及确定性输入复现说明保存在current_gate/independent_reassessment中。

在D:/Safe_Vision_FPGA_2026/artifacts/board_repair/repair_26101723_1062946/选择BASE位流，由官方BitWriter命令行通过JTAG下载SRAM，先校验SHA并先打开串口，不写Flash。串口COM6为115200/8N1，保持供电，不按CONFIG1（会重新加载Flash旧程序）。本位流保留完整HDMI应用；故障未解除时仍可能显示EMERGENCY EXIT。不要凭显示该安全画面就认定TF图片已经通过。

先读取DIAG=0核对26101723，DIAG10/11/12/13仅bit0表示物理读/客户端读/源/写命令首行窗口是否观察到非零数据，DIAG14/15打包四个320字计数，须按docs/v3/memory_flags_26101718.md及冻结解释工具解释；再核对CACHE=F、FAULT=0、INTEGRITY=0、PRESENTATION=0、RECOVERY=0；这些只代表内部状态，实际画面、声音、物理按键及长稳需要实物记录。坏WAV可能按规定使用ROM后备音。

release.index.json给出全部载荷SHA-256，approval.index.json给出批准时的逐文件源码和完整功能证据指纹。各模式reports保留原始STA、健康、例外命中、网表、参数和冻结数据库。包含绝对运行路径的原始文件保持原样，不能把搬运后的路径差异当作新一次构建。

按用户要求，本包只保存至本地，不上传GitHub。
