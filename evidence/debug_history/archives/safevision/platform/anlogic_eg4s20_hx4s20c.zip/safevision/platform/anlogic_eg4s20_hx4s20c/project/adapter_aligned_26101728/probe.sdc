create_clock -name board_clk -period 20.000 [get_ports {clk}]
derive_clocks
set_input_delay -clock board_clk -max 5.000 [get_ports {rst_n}]
set_input_delay -clock board_clk -min 0.000 [get_ports {rst_n}]
set_output_delay -clock board_clk -max 5.000 [get_ports {uart_txd led[*]}]
set_output_delay -clock board_clk -min -5.000 [get_ports {uart_txd led[*]}]
# External asynchronous reset assertion; synchronized release remains timed.
set_false_path -from [get_ports {rst_n}] -to [get_pins {*.sr */*.sr}]
set_false_path -through [get_nets {probe_common_rst_n}] -to [get_pins {*.sr */*.sr}]
