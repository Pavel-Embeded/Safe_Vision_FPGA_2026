// Diagnostic26101728: crossed production adapter with first-write telemetry.
// Odd 1-based rounds: slow singleton adapter writes, direct aligned reads.
// Even rounds: direct16-beat writes, adapter FAST/PREFETCH aligned reads.
// Each path reports independently. Six patterns,12 rounds,16 poisoned guard words.
// Uses the production4beat adapter. Write rows descend, burst lengths vary,
// and1ms host pauses exercise quiescent/refresh transitions. DQM unchanged.
// A model checks our control/report logic, not encrypted controller silicon.
`define SAFEVISION_SDRAM_CLK_HZ 50000000
`define SAFEVISION_REFRESH_ROWS 4096
module sv_v3_adapter_aligned_trace #(
    parameter integer CLK_FREQ      = 50_000_000,   // 板载晶振
    parameter integer MEM_CLK_FREQ  = 50_000_000,  // sv_system_pll C1，uart 也用这个
    parameter integer BAUD          = 115200,

    parameter [23:0]  POWERUP_CYC   = 24'd2_500_000,  // 上电等待 @50MHz
    parameter [23:0]  INIT_TO_CYC   = 24'd2_000_000,  // 等 Sdr_init_done 的超时 @50MHz

    parameter [20:0]  BASE_ADDR     = 21'd0,          // 起始 word 地址
    parameter [20:0]  TEST_WORDS    = 21'd3840,       // **每轮**测试 word 数
    parameter integer ADDR_SHIFT    = 0,             // 步长高位：1 << ADDR_SHIFT
    parameter integer ADDR_LOWSTEP  = 0,              // 步长低位：0 或 1（1 = 让低位地址位也变）
    parameter [31:0]  ROUNDS        = 32'd12,          // ★ soak：跑多少轮（1 = 单轮 = 原来的行为）

    parameter integer TEST_COLUMNS  = 320, // descending rows, ascending pixels
    parameter integer LONG_GAP_LOG2 = 7,
    parameter integer LONG_GAP_CYC  = 50000, //1ms at native50MHz
    parameter integer HOST_GAP      = 512, // >48 clocks forces singleton flushes
    parameter integer BURST_N       = 16,            // 一次突发多少个 word
    parameter integer BURST_GAP     = 16,             // 突发之间空多少拍

    parameter [15:0]  WR_DRAIN_CYC  = 16'd512,        // 写完后等写落地
    parameter [19:0]  RD_WAIT_TO_CYC= 20'd200_000     // 等读回收齐的超时 @50MHz
)(
    // ---- 板级引脚（引脚号见同目录 ../constraints/pin.adc）----
    input  wire        clk,        // R7   FPGA_GCLK  50 MHz
    input  wire        rst_n,      // A2   KEY_1       低有效按键
    output wire        uart_txd,   // D12  USB-UART 发送（板载 CH340G，115200 8N1）
    output wire [3:0]  led         // A4/A3/C10/B12 = LED0..LED3，高电平点亮
);

    // ------------------------------------------------------------------------
    // 上电复位：按键（异步、带抖动）先同步到 50 MHz，再与 PLL 锁定相与，
    //           最后在 50 MHz 域做同步释放。每一个目标时钟域单独例化。
    // ------------------------------------------------------------------------
    wire rst_ref_n;          // 50 MHz 域
    wire pll_locked;
    wire rst_mem_n;          // 50 MHz 域
    wire rst_mem;            // SDRAM IP 要的是【高有效】Rst

    reset_sync u_rst_ref (
        .clk        (clk),
        .async_rst_n(rst_n),
        .rst_n      (rst_ref_n)
    );

    // ------------------------------------------------------------------------
    // 时钟：50 MHz -> sv_v3_memory_pll（100M / 50M / 50M+8ns）
    //   C0 外部端口不接业务负载；wrapper 内的 NORMAL 反馈始终连接。
    // ------------------------------------------------------------------------
    wire ext_mem_clk;
    wire ext_mem_clk_sft;

    sv_v3_memory_pll u_sys_pll (
        .refclk   (clk),
        .reset    (1'b0),
        .extlock  (pll_locked),
        .clk0_out (),
        .clk1_out (ext_mem_clk),
        .clk2_out (ext_mem_clk_sft)
    );

    (* keep="true" *) wire probe_common_rst_n=rst_ref_n & pll_locked;
    reset_sync #(.RELEASE_FALLING(1)) u_rst_mem (
        .clk        (ext_mem_clk),
        .async_rst_n(probe_common_rst_n),
        .rst_n      (rst_mem_n)
    );

    reg controller_boot_release;
    assign rst_mem = ~controller_boot_release;

    // ------------------------------------------------------------------------
    // SDRAM 控制器（厂商加密 IP 的外壳，见 ../ip/sdram/）
    // ------------------------------------------------------------------------
    wire        sdr_init_done;
    wire        sdr_init_ref_vld;   // 例程里是纯直通、不参与判断，这里只留给 ChipWatcher
    wire        sdr_busy;           // 同上
    wire        app_wr_en;
    wire [20:0] app_wr_addr;
    wire [31:0] app_wr_din;
    wire [3:0]  app_wr_dm;
    wire        app_rd_en;
    wire [20:0] app_rd_addr;
    wire        sdr_rd_en;
    wire [31:0] sdr_rd_dout;
    reg [31:0] physical_read_previous;

    // UART 握手（uart_tx 例化在文件末尾，这里先声明，避免前向引用）
    wire        uart_tx_ready;
    wire        uart_tx_valid;
    wire [7:0]  uart_tx_data;

    // ------------------------------------------------------------------------
    // 顶层状态机（50 MHz 域，全程单时钟域）
    // ------------------------------------------------------------------------
    localparam [3:0] ST_POWER    = 4'd0,
                     ST_INITWAIT = 4'd1,
                     ST_WRITE    = 4'd2,
                     ST_DRAIN    = 4'd3,
                     ST_READ     = 4'd4,
                     ST_RDWAIT   = 4'd5,
                     ST_ROUND    = 4'd9,    // ★ 轮次边界：只停一拍，让各计数块自己清零（避免多驱动）
                     ST_REPORT   = 4'd6,
                     ST_OK       = 4'd7,
                     ST_ERR      = 4'd8,
                     ST_GUARD_WRITE=4'd10, ST_GUARD_DRAIN=4'd11;

    // 突发周期 = 突发长度 + 间隔（编译期常数）
    localparam integer PERIOD = BURST_N + BURST_GAP;

    // 报告长度（15 + 17 + 30 + 29 + 33 + 16 + 44 + 6 = 190 Byte，定长）
    localparam integer RPT_LEN  = 231;
    localparam [7:0]   RPT_LAST = RPT_LEN - 1;     // 189（倒计数起点）

    // 配置字的两个字段（integer parameter 不能直接位选，先落到定宽 localparam）
    localparam [7:0] SHIFT_BYTE  = ADDR_SHIFT;     // 0..20
    wire [3:0] LOWSTEP_NIB; // diagnostic path bits, assigned after declarations
    // 步长低位开关（编译期常数 ⇒ 工具会把未选中的那一路折叠掉）
    localparam       LOWSTEP_EN  = (ADDR_LOWSTEP != 0);

    localparam [20:0] READ_WORDS=TEST_WORDS+21'd16;
    wire [3:0] ad_wr_dm;
    reg [4:0] guard_i;
    reg [5:0] guard_wait;
    reg  [3:0]  st;
    always @(posedge ext_mem_clk or negedge rst_mem_n)begin
      if(!rst_mem_n)begin guard_i<=0;guard_wait<=0;end
      else begin
        if(st==ST_ROUND)begin guard_i<=0;guard_wait<=0;end
        else begin
          if(st==ST_GUARD_WRITE&&guard_i<16)guard_i<=guard_i+1'b1;
          if(st==ST_GUARD_DRAIN&&guard_wait<63)guard_wait<=guard_wait+1'b1;
        end
      end
    end

    // Hold the controller itself in reset while the existing power timer runs.
    // Global asynchronous assertion uses the existing common reset root;
    // controller release is falling MEM, retaining real recovery/removal STA.
    always @(negedge ext_mem_clk or negedge probe_common_rst_n)begin
      if(!probe_common_rst_n)controller_boot_release<=0;
      else if(!rst_mem_n)controller_boot_release<=0;
      else controller_boot_release<=(st!=ST_POWER);
    end

    reg  [23:0] pwr_cnt;
    reg  [23:0] init_to_cnt;
    reg  [15:0] drain_cnt;
    reg  [19:0] rdwait_to_cnt;
    reg  [7:0]  err_code;
    reg  [7:0]  rpt_idx;       // 8 位**倒计数**：RPT_LAST .. 0
    reg         rpt_run;       // 报告发射中
    reg  [8*44-1:0] rpt_line_q; // 两级报告选择的第一级：当前报告行
    reg  [5:0]  rpt_byte_pos_q; // 当前字节在行内的反向索引
    reg         rpt_line_valid;
    reg  [7:0]  rpt_byte_q;     // 两级报告选择的第二级：UART 待发字节
    reg         rpt_byte_valid;
    reg  [7:0]  t_wr;
    reg  [7:0]  t_rd;
    reg [20:0] wr_physical;
    reg [8:0] wr_column;
    reg [4:0] write_quota,write_remaining;
    reg [15:0] read_host_gap;
    reg  [20:0] wr_i;          // 本轮已写 word 数
    reg  [20:0] rd_i;          // 本轮已发读命令数
    reg  [20:0] cap_cnt;       // 本轮已收到返回 word 数
    reg  [15:0] bad_cnt;       // **本轮**比对不符 word 数（每轮清零，配合 fail-fast）

    // ---- soak：轮次 / 图案模式 / 累计搬运量 ----
    reg  [31:0] rnd;           // 当前轮（0-based；报告里显示 rnd+1）
    reg  [2:0]  pat_mode;      // 本轮图案模式 0..5（逐轮循环，见 sdr_pat_gen.v 头注）
    reg  [39:0] tot_cnt;       // 累计比对字数（**不重置**）⇒ 报告 TOT = 实际搬运量

    // ---- 回读四级流水（压短 cap_cnt → sdr_pat_gen → 比较器 → BAD0 CE 的路径）----
    //   sample_* : 延迟应答到来时锁住地址/数据/模式；期望图案下一拍算。
    //   expect_* : 锁存图案、地址、数据；下一拍做 32bit 比较。
    //   cmp_*    : 锁存比较结果；下一拍提交 checked_cnt / bad_cnt / BAD0。
    //   checked_cnt 是"比较流水已提交"数，ST_RDWAIT 必须等它而不是仅看 cap_cnt。
    reg         sample_v;
    reg  [20:0] sample_addr;
    reg  [31:0] sample_data;
    reg  [2:0]  sample_mode;
    reg         expect_v;
    reg  [20:0] expect_addr;
    reg  [31:0] expect_data;
    reg  [31:0] expect_pat;
    reg         cmp_v;
    reg  [3:0]  cmp_bad_bytes;
    reg  [20:0] cmp_addr;
    reg  [31:0] cmp_exp;
    reg  [31:0] cmp_act;
    reg  [20:0] checked_cnt;

    // ---- 首个不符点（诊断用；bad0_set=0 表示"全对"）----
    reg         bad0_set;
    reg  [31:0] bad0_rnd;      // 首个不符发生在**第几轮**（1-based，与报告口径一致）
    reg  [20:0] bad0_addr;     // 首个不符的地址
    reg  [31:0] bad0_exp;      // 该地址的期望值
    reg  [31:0] bad0_act;      // 该地址实际读回的值

    // 地址 = BASE_ADDR + index * STRIDE，其中 STRIDE = (1 << ADDR_SHIFT) + ADDR_LOWSTEP
    //   ★ 必须写在 wr_i / rd_i / cap_cnt 声明**之后**，否则 Verilog 会先建 1 bit 隐式网线
    wire [20:0] wr_addr=wr_physical;
    wire [20:0] rd_addr  = BASE_ADDR + (rd_i    << ADDR_SHIFT) + (LOWSTEP_EN ? rd_i    : 21'd0);
    wire [20:0] cap_addr = BASE_ADDR + (cap_cnt << ADDR_SHIFT) + (LOWSTEP_EN ? cap_cnt : 21'd0);

    // ---- 测试图案：由可仿真的 `sdr_pat_gen` 产生（写侧 / 读侧期望值各一个实例）----
    //   ★ 读侧从 sample_addr 寄存器计算，不能直接由 cap_cnt 的加法器驱动比较器。
    //   ★ 两侧必须用**同一个** pat_mode；流水排空后才允许进入下一轮。
    wire [31:0] pat_wr;
    wire [31:0] pat_rd;
    sdr_pat_gen u_pat_wr ( .addr(wr_addr),     .mode(pat_mode),   .pat(pat_wr) );
    sdr_pat_gen u_pat_rd ( .addr(sample_addr), .mode(sample_mode), .pat(pat_rd) );

    // A falling-edge release gives the adapter reset a timed half cycle.
    // Only adapter state is cleared between rounds. SDRAM contents persist.
    reg adapter_rst_n;
    always @(negedge ext_mem_clk or negedge rst_mem_n)
      if(!rst_mem_n)adapter_rst_n<=0;
      else adapter_rst_n<=(st!=ST_ROUND);
    wire write_via_adapter=~rnd[0];
    wire read_via_adapter=rnd[0];
    reg [15:0] host_gap;
    reg [23:0] operation_cycles;
    reg [6:0] physical_quiet;
    reg first_command_seen,first_input_seen;
    reg [31:0] first_command_data,first_input_data;
    reg [3:0] first_command_dm;
    reg [15:0] unmasked_write_words;
    reg any_error;
    wire host_write=(st==ST_WRITE)&&write_via_adapter&&(wr_i<TEST_WORDS)&&(host_gap==0);
    wire host_read=(st==ST_READ)&&read_via_adapter&&(rd_i<READ_WORDS)&&(read_host_gap==0);
    wire adapter_req=host_write||host_read;
    wire adapter_ready,adapter_init,adapter_valid,adapter_write_idle,adapter_fault;
    assign LOWSTEP_NIB={1'b0,adapter_fault,read_via_adapter,write_via_adapter};
    wire [31:0] adapter_rdata;
    wire ad_wr_en,ad_rd_en;
    wire [20:0] ad_wr_addr,ad_rd_addr;
    wire [31:0] ad_wr_data;
    wire direct_write=(st==ST_WRITE)&&!write_via_adapter&&(t_wr<BURST_N)&&(wr_i<TEST_WORDS);
    wire direct_read=(st==ST_READ)&&!read_via_adapter&&(t_rd<BURST_N)&&(rd_i<READ_WORDS);
    wire write_accepted=write_via_adapter?(host_write&&adapter_ready):direct_write;
    wire read_accepted=read_via_adapter?(host_read&&adapter_ready):direct_read;
    sdram_app_adapter_aligned4 #(.FAST_READ(1),.PREFETCH_READ(1),.READ_DATA_LEADS_VALID(1)) u_adapter (
      .clk(ext_mem_clk),.rst_n(adapter_rst_n),.req(adapter_req),.wr(host_write),
      .addr(host_write?{11'b0,wr_addr}:{11'b0,rd_addr}),.wdata(pat_wr),.wstrb(4'hf),
      .rdata(adapter_rdata),.rdata_valid(adapter_valid),.ready(adapter_ready),.init_done(adapter_init),
      .Sdr_init_done(sdr_init_done),.Sdr_init_ref_vld(sdr_init_ref_vld),.Sdr_busy(sdr_busy),
      .App_wr_en(ad_wr_en),.App_wr_addr(ad_wr_addr),.App_wr_dm(ad_wr_dm),.App_wr_din(ad_wr_data),
      .App_rd_en(ad_rd_en),.App_rd_addr(ad_rd_addr),.Sdr_rd_en(sdr_rd_en),.Sdr_rd_dout(sdr_rd_dout),
      .write_idle(adapter_write_idle),.protocol_fault(adapter_fault));
    wire guard_write=(st==ST_GUARD_WRITE)&&(guard_i<16);
    wire [20:0] guard_addr=BASE_ADDR+TEST_WORDS+guard_i;
    wire [31:0] guard_data=32'h5A5AA5A5^{11'b0,guard_addr};
    assign app_wr_en=guard_write||(write_via_adapter?ad_wr_en:direct_write);
    assign app_wr_addr=guard_write?guard_addr:(write_via_adapter?ad_wr_addr:wr_addr);
    assign app_wr_din=guard_write?guard_data:(write_via_adapter?ad_wr_data:pat_wr);
    assign app_wr_dm=guard_write?4'h0:(write_via_adapter?ad_wr_dm:4'h0);
    assign app_rd_en=read_via_adapter?ad_rd_en:direct_read;
    assign app_rd_addr=read_via_adapter?ad_rd_addr:rd_addr;
    // All request/address changes follow actual acceptance. Entire host
    // requests remain stable through adapter backpressure.
    always @(posedge ext_mem_clk or negedge rst_mem_n)begin
      if(!rst_mem_n)begin
        wr_physical<=BASE_ADDR+TEST_WORDS-TEST_COLUMNS;wr_column<=0;
        write_quota<=1;write_remaining<=1;read_host_gap<=0;
      end else if(st==ST_ROUND)begin
        wr_physical<=BASE_ADDR+TEST_WORDS-TEST_COLUMNS;wr_column<=0;
        write_quota<=1;write_remaining<=1;read_host_gap<=0;
      end else begin
        if(write_accepted)begin
          if(wr_column==TEST_COLUMNS-1)begin
            wr_column<=0;wr_physical<=wr_physical-(2*TEST_COLUMNS-1);
          end else begin wr_column<=wr_column+1'b1;wr_physical<=wr_physical+1'b1;end
          if(write_remaining==1)begin
            write_quota<=(write_quota==16)?1:write_quota+1'b1;
            write_remaining<=(write_quota==16)?1:write_quota+1'b1;
          end else write_remaining<=write_remaining-1'b1;
        end
        if(st!=ST_READ)read_host_gap<=0;
        else if(read_accepted)begin
          if(&rd_i[LONG_GAP_LOG2-1:0])read_host_gap<=LONG_GAP_CYC;
          else if(rd_i[3:0]==7)read_host_gap<=7;
        end else if(read_host_gap!=0)read_host_gap<=read_host_gap-1'b1;
      end
    end

    always @(posedge ext_mem_clk or negedge rst_mem_n)begin
      if(!rst_mem_n)begin host_gap<=0;operation_cycles<=0;physical_quiet<=0;end
      else begin
        if(app_wr_en||app_rd_en||sdr_rd_en)physical_quiet<=0;
        else if(physical_quiet<127)physical_quiet<=physical_quiet+1'b1;
        if(st!=ST_WRITE)host_gap<=0;
        else if(write_accepted)begin
          if(&wr_i[LONG_GAP_LOG2-1:0])host_gap<=LONG_GAP_CYC;
          else if(write_remaining==1)host_gap<=HOST_GAP;
          else host_gap<=0;
        end
        else if(host_gap!=0)host_gap<=host_gap-1'b1;
        if(st!=ST_WRITE&&st!=ST_READ)operation_cycles<=0;
        else if(operation_cycles<24'd4000000)operation_cycles<=operation_cycles+1'b1;
      end
    end

    // Independent passive pipeline on the ACTUAL App acceptance edge.
    // Full-mask target commands are checked; guard and masked padding excluded.
    // Zero mismatch alone does not prove addresses, masks or physical writes.
    reg cmd_v0,cmd_v1,cmd_v2;
    reg [20:0] cmd_addr0;
    reg [2:0] cmd_mode0;
    reg [31:0] cmd_data0,cmd_data1,cmd_pat1,cmd_actual2,cmd_expected2;
    reg [3:0] cmd_bad_bytes;
    reg bad_write_seen;
    reg [31:0] bad_write_actual,bad_write_expected;
    wire [31:0] cmd_pattern;
    sdr_pat_gen u_pat_command(.addr(cmd_addr0),.mode(cmd_mode0),.pat(cmd_pattern));
    always @(posedge ext_mem_clk or negedge rst_mem_n)begin
      if(!rst_mem_n)begin
        cmd_v0<=0;cmd_v1<=0;cmd_v2<=0;cmd_addr0<=0;cmd_mode0<=0;
        cmd_data0<=0;cmd_data1<=0;cmd_pat1<=0;cmd_actual2<=0;cmd_expected2<=0;cmd_bad_bytes<=0;
        bad_write_seen<=0;bad_write_actual<=0;bad_write_expected<=0;
      end else if(st==ST_ROUND)begin
        cmd_v0<=0;cmd_v1<=0;cmd_v2<=0;cmd_bad_bytes<=0;
        bad_write_seen<=0;bad_write_actual<=0;bad_write_expected<=0;
      end else begin
        cmd_v0<=app_wr_en&&app_wr_dm==0&&app_wr_addr>=BASE_ADDR&&app_wr_addr<BASE_ADDR+TEST_WORDS;
        cmd_v1<=cmd_v0;cmd_v2<=cmd_v1;
        if(app_wr_en)begin cmd_addr0<=app_wr_addr;cmd_mode0<=pat_mode;cmd_data0<=app_wr_din;end
        if(cmd_v0)begin cmd_data1<=cmd_data0;cmd_pat1<=cmd_pattern;end
        if(cmd_v1)begin
          cmd_actual2<=cmd_data1;cmd_expected2<=cmd_pat1;
          cmd_bad_bytes<={(cmd_data1[31:24]!=cmd_pat1[31:24]),(cmd_data1[23:16]!=cmd_pat1[23:16]),
                         (cmd_data1[15:8]!=cmd_pat1[15:8]),(cmd_data1[7:0]!=cmd_pat1[7:0])};
        end
        if(cmd_v2 && |cmd_bad_bytes)begin
          if(!bad_write_seen)begin bad_write_actual<=cmd_actual2;bad_write_expected<=cmd_expected2;end
          bad_write_seen<=1;
        end
      end
    end

    // Observe both sides of the unchanged adapter at actual acceptance edges.
    always @(posedge ext_mem_clk or negedge rst_mem_n)begin
      if(!rst_mem_n)begin
        first_command_seen<=0;first_input_seen<=0;first_command_data<=0;
        first_input_data<=0;first_command_dm<=15;unmasked_write_words<=0;
      end else if(st==ST_ROUND)begin
        first_command_seen<=0;first_input_seen<=0;first_command_data<=0;
        first_input_data<=0;first_command_dm<=15;unmasked_write_words<=0;
      end else begin
        if(write_accepted&&!first_input_seen)begin first_input_seen<=1;first_input_data<=pat_wr;end
        if(app_wr_en)begin
          if(!first_command_seen)begin
            first_command_seen<=1;first_command_data<=app_wr_din;first_command_dm<=app_wr_dm;
          end
          if(app_wr_dm==0)unmasked_write_words<=unmasked_write_words+1'b1;
        end
      end
    end

    // ---- 写侧计数：只随 app_wr_en 前进 ----
    always @(posedge ext_mem_clk or negedge rst_mem_n) begin
        if (!rst_mem_n) begin
            t_wr <= 8'd0;
            wr_i <= 21'd0;
        end else if (st == ST_ROUND) begin          // ★ 轮次边界：本轮写计数清零
            t_wr <= 8'd0;
            wr_i <= 21'd0;
        end else if (st == ST_WRITE) begin
            if (t_wr == PERIOD - 1) t_wr <= 8'd0;
            else                    t_wr <= t_wr + 8'd1;
            if (write_accepted)     wr_i <= wr_i + 21'd1;
        end
    end

    // ---- 读侧计数：只随 app_rd_en 前进 ----
    always @(posedge ext_mem_clk or negedge rst_mem_n) begin
        if (!rst_mem_n) begin
            t_rd <= 8'd0;
            rd_i <= 21'd0;
        end else if (st == ST_ROUND) begin          // ★ 轮次边界：本轮读计数清零
            t_rd <= 8'd0;
            rd_i <= 21'd0;
        end else if (st == ST_READ) begin
            if (t_rd == PERIOD - 1) t_rd <= 8'd0;
            else                    t_rd <= t_rd + 8'd1;
            if (read_accepted)      rd_i <= rd_i + 21'd1;
        end
    end

    // ---- 收数 + 期望图案 + 分字节比较 + 提交：四级流水 ----
    //   sdr_rd_en 才是取数时刻（读侧是延迟应答式）；第 k 个返回对应第 k 个读命令。
    //   ★ 2026-10-04 11:16 的布线报告抓到真问题：
    //       cap_cnt → 地址加法 → mode1 xorshift/mux → 32bit 比较 → bad0_* CE
    //       Logic Level 8 / 11.311ns / SWNS -3.591ns / 90 endpoints。
    //     把这条组合路径拆成 4 拍：响应采样 → 图案计算 → 比较 → 错误提交。
    //   ★ ST_RDWAIT 必须等 `checked_cnt`（已提交比较数），不能只看 `cap_cnt`（已收数据数），
    //     否则状态机会在比较流水排空前切换 pat_mode / 发报告。
    wire rd_capture = (read_via_adapter?adapter_valid:sdr_rd_en) && ((st == ST_READ) || (st == ST_RDWAIT)) &&
                      (cap_cnt < READ_WORDS);

    always @(posedge ext_mem_clk or negedge rst_mem_n) begin
        if (!rst_mem_n) begin
            cap_cnt       <= 21'd0;
            checked_cnt   <= 21'd0;
            bad_cnt       <= 16'd0;
            tot_cnt       <= 40'd0;
            bad0_set      <= 1'b0;
            bad0_rnd      <= 32'd0;
            bad0_addr     <= 21'd0;
            bad0_exp      <= 32'd0;
            bad0_act      <= 32'd0;
            sample_v      <= 1'b0;
            sample_addr   <= 21'd0;
            sample_data   <= 32'd0;
            sample_mode   <= 3'd0;
            expect_v      <= 1'b0;
            expect_addr   <= 21'd0;
            expect_data   <= 32'd0;
            expect_pat    <= 32'd0;
            cmp_v         <= 1'b0;
            cmp_bad_bytes <= 4'b0000;
            cmp_addr      <= 21'd0;
            cmp_exp       <= 32'd0;
            cmp_act       <= 32'd0;
        end else if (st == ST_ROUND) begin
            // ★ 轮次边界：清本轮计数与流水 valid；累计 TOT / 全局首错不清
            bad0_set<=0;bad0_rnd<=0;bad0_addr<=0;bad0_exp<=0;bad0_act<=0;
            cap_cnt       <= 21'd0;
            checked_cnt   <= 21'd0;
            bad_cnt       <= 16'd0;
            sample_v      <= 1'b0;
            expect_v      <= 1'b0;
            cmp_v         <= 1'b0;
            cmp_bad_bytes <= 4'b0000;
        end else begin
            // valid 每拍前推，空拍自然冲刷
            sample_v <= rd_capture;
            expect_v <= sample_v;
            cmp_v    <= expect_v;

            // Stage 0：收 SDRAM 响应，锁存它对应的地址、模式和数据
            if (rd_capture) begin
                cap_cnt     <= cap_cnt + 21'd1;
                tot_cnt     <= tot_cnt + 40'd1;       // 累计量不随轮次重置
                sample_addr <= cap_addr;
                sample_mode <= pat_mode;
                sample_data <= read_via_adapter?adapter_rdata:physical_read_previous;
            end

            // Stage 1：地址派生 / LFSR / walking 等图案组合计算的输出在本拍寄存
            if (sample_v) begin
                expect_addr <= sample_addr;
                expect_data <= sample_data;
                expect_pat <= (sample_addr>=BASE_ADDR+TEST_WORDS)?(32'h5A5AA5A5^{11'b0,sample_addr}):pat_rd;
            end

            // Stage 2：32 位比较与诊断数据一起寄存
            if (expect_v) begin
                cmp_addr <= expect_addr;
                cmp_exp  <= expect_pat;
                cmp_act  <= expect_data;
                cmp_bad_bytes <= {
                    (expect_data[31:24] != expect_pat[31:24]),
                    (expect_data[23:16] != expect_pat[23:16]),
                    (expect_data[15:8]  != expect_pat[15:8]),
                    (expect_data[7:0]   != expect_pat[7:0])
                };
            end

            // Stage 3：只从已寄存的比较结果提交计数 / 首错（短 CE 路径）
            if (cmp_v) begin
                checked_cnt <= checked_cnt + 21'd1;
                if (|cmp_bad_bytes) begin
                    bad_cnt <= bad_cnt + 16'd1;
                    if (!bad0_set) begin
                        bad0_rnd  <= rnd + 32'd1;     // 报告口径 1-based
                        bad0_addr <= cmp_addr;
                        bad0_exp  <= cmp_exp;
                        bad0_act  <= cmp_act;
                        bad0_set  <= 1'b1;
                    end
                end
            end
        end
    end

    // Observed26101701 MEM50/+8ns interface: data precedes valid by one edge.
    // Sampling unconditionally also retains the first pre-valid word.
    always @(posedge ext_mem_clk or negedge rst_mem_n)
      if(!rst_mem_n)physical_read_previous<=0;
      else physical_read_previous<=sdr_rd_dout;

    // ---- 主序列 ----
    always @(posedge ext_mem_clk or negedge rst_mem_n) begin
        if (!rst_mem_n) begin
            st            <= ST_POWER;
            pwr_cnt       <= 24'd0;
            init_to_cnt   <= 24'd0;
            drain_cnt     <= 16'd0;
            rdwait_to_cnt <= 20'd0;
            err_code      <= 8'h00;
            rpt_idx       <= RPT_LAST;
            rpt_run       <= 1'b0;
            rnd           <= 32'd0;
            pat_mode      <= 3'd0;
            any_error<=0;
        end else begin
            if(st==ST_REPORT&&(bad_cnt!=0||err_code!=0))any_error<=1;
            case (st)
            // 上电等待：等板级电源与 PLL 稳定
            ST_POWER: begin
                if (pwr_cnt >= POWERUP_CYC) st <= ST_INITWAIT;
                else                        pwr_cnt <= pwr_cnt + 24'd1;
            end
            // 等 SDRAM IP 初始化完成 —— 独立超时出口
            ST_INITWAIT: begin
                if (sdr_init_done)                 st <= ST_GUARD_WRITE;
                else if (init_to_cnt >= INIT_TO_CYC) begin
                    err_code <= 8'h01;
                    st       <= ST_REPORT;
                end else init_to_cnt <= init_to_cnt + 24'd1;
            end
            // Poison a complete burst beyond the target before EVERY round.
            // Dense target writes cannot hide damage to this final neighbour.
            ST_GUARD_WRITE: if(guard_i>=16)st<=ST_GUARD_DRAIN;
            ST_GUARD_DRAIN: if(guard_wait>=32)st<=ST_WRITE;
            // 写图案（分突发，靠 t_wr 计数）
            ST_WRITE: begin
                if (wr_i >= TEST_WORDS) st <= ST_DRAIN;
                if(adapter_fault||operation_cycles>=24'd4000000)begin err_code<=8'h04;st<=ST_REPORT;end
            end
            // 等写落地，再换方向（读写突发不允许重叠）
            ST_DRAIN: begin
                if (drain_cnt >= WR_DRAIN_CYC && (!write_via_adapter||adapter_write_idle)) st <= ST_READ;
                else if(drain_cnt!=16'hffff)drain_cnt <= drain_cnt + 16'd1;
                if(adapter_fault||drain_cnt==16'hffff)begin err_code<=8'h04;st<=ST_REPORT;end
            end
            // 发读命令（分突发）
            ST_READ: begin
                if (rd_i >= READ_WORDS) begin
                    rdwait_to_cnt <= 20'd0;
                    st            <= ST_RDWAIT;
                end
                if(adapter_fault||operation_cycles>=24'd4000000)begin err_code<=8'h05;st<=ST_REPORT;end
            end
            // 等读回收齐 —— 独立超时出口
            ST_RDWAIT: begin
                // Drain speculative reads before resetting the adapter or
                // changing physical bus ownership for the next round.
                if (checked_cnt >= READ_WORDS && physical_quiet>=32 &&
                    (!read_via_adapter||adapter_write_idle)) begin
                    // Each path reports even after failure; run the next path too.
                    st<=ST_REPORT;
                end else if (rdwait_to_cnt >= RD_WAIT_TO_CYC) begin
                    err_code <= 8'h02;
                    st       <= ST_REPORT;
                end else rdwait_to_cnt <= rdwait_to_cnt + 20'd1;
            end
            // ★ 轮次边界（只停一拍）：轮次 +1、图案模式 0..5 循环、清落地计时；
            //   各计数块（wr_i/rd_i/cap_cnt/bad_cnt）在**它们自己的 always 块**里看到
            //   `st == ST_ROUND` 时清零 —— 绝不能在这里写它们（一个 reg 只能有一个驱动源）
            ST_ROUND: begin
                rnd        <= rnd + 32'd1;
                err_code<=0;
                if(rnd[0])pat_mode <= (pat_mode == 3'd5) ? 3'd0 : (pat_mode + 3'd1);
                drain_cnt  <= 16'd0;
                st <= ST_GUARD_WRITE;
            end
            // 发报告（逐字节，uart 背压；索引**倒计数**，理由见文件头）
            ST_REPORT: begin
                if (!rpt_run) begin
                    rpt_run <= 1'b1;          // 装索引（只做一次），下一拍起预取字节
                    rpt_idx <= RPT_LAST;
                end else if (rpt_byte_valid && uart_tx_ready) begin
                    if (rpt_idx == 8'd0) begin
                        rpt_run <= 1'b0;
                        if(rnd+1<ROUNDS)st<=ST_ROUND;
                        else if(bad_cnt!=0||any_error||err_code!=0)begin
                          if(err_code==0)err_code<=8'h03;
                          st<=ST_ERR;
                        end else st<=ST_OK;
                    end else rpt_idx <= rpt_idx - 8'd1;
                end
            end
            ST_OK : st <= ST_OK;      // 停住，LED 保持 8
            ST_ERR: st <= ST_ERR;     // 停住，LED 显示错误主码低 4 位
            default: st <= ST_POWER;
            endcase
        end
    end

    // ------------------------------------------------------------------------
    // LED 状态码（组合，纯观察用）
    // ------------------------------------------------------------------------
    reg [3:0] led_code;
    always @(*) begin
        case (st)
            ST_POWER   : led_code = 4'h1;
            ST_INITWAIT: led_code = 4'h2;
            ST_WRITE   : led_code = 4'h3;
            ST_DRAIN   : led_code = 4'h4;
            ST_READ    : led_code = 4'h5;
            ST_RDWAIT  : led_code = 4'h6;
            ST_ROUND   : led_code = 4'h3;    // 与 ST_WRITE 同码（轮次边界只停一拍，看不出差别）
            ST_REPORT  : led_code = 4'h7;
            ST_OK      : led_code = 4'h8;
            default    : led_code = err_code[3:0];   // ST_ERR：01/02/03
        endcase
    end

    assign led = led_code;

    // ------------------------------------------------------------------------
    // UART 报告：定长 190 Byte 纯 ASCII，行尾显式写 8'h0D / 8'h0A
    //   （★ 不要写 "\r\n"：Verilog-2001 的转义表里没有 \r，会编成字母 r）
    // ------------------------------------------------------------------------
    // 一个 nibble -> ASCII 大写十六进制
    function [7:0] hx;
        input [3:0] n;
        begin
            hx = (n < 4'd10) ? (8'h30 + {4'b0, n}) : (8'h37 + {4'b0, n});
        end
    endfunction

    function [15:0] hex8;
        input [7:0] v;
        begin
            hex8 = { hx(v[7:4]), hx(v[3:0]) };
        end
    endfunction

    function [31:0] hex16;
        input [15:0] v;
        begin
            hex16 = { hx(v[15:12]), hx(v[11:8]), hx(v[7:4]), hx(v[3:0]) };
        end
    endfunction

    function [47:0] hex24;
        input [23:0] v;
        begin
            hex24 = { hx(v[23:20]), hx(v[19:16]), hx(v[15:12]),
                      hx(v[11:8]),  hx(v[7:4]),   hx(v[3:0]) };
        end
    endfunction

    function [63:0] hex32;
        input [31:0] v;
        begin
            hex32 = { hx(v[31:28]), hx(v[27:24]), hx(v[23:20]), hx(v[19:16]),
                      hx(v[15:12]), hx(v[11:8]),  hx(v[7:4]),   hx(v[3:0]) };
        end
    endfunction

    function [79:0] hex40;                 // 40 bit = 10 个 hex 字符
        input [39:0] v;
        begin
            hex40 = { hx(v[39:36]), hx(v[35:32]), hx(v[31:28]), hx(v[27:24]), hx(v[23:20]),
                      hx(v[19:16]), hx(v[15:12]), hx(v[11:8]),  hx(v[7:4]),   hx(v[3:0]) };
        end
    endfunction

    // 报告用字段：配置 + 轮次/图案 + 首个错点
    //   全对时用哨兵：BAD0 地址 = 0xFFFFFF（地址最大 0x1FFFFF）、轮次 = 0xFFFFFFFF
    wire [23:0] base24   = { 3'b0, BASE_ADDR  };
    wire [23:0] n24      = { 3'b0, TEST_WORDS };
    wire [23:0] bad0_rep = bad0_set ? { 3'b0, bad0_addr } : 24'hFFFFFF;
    wire [31:0] exp_rep  = bad0_set ? bad0_exp : 32'd0;
    wire [31:0] act_rep  = bad0_set ? bad0_act : 32'd0;
    wire [31:0] rnd_rep  = bad0_set ? bad0_rnd : 32'hFFFFFFFF;   // 无错 ⇒ FFFFFFFF
    wire [31:0] rnd_cur  = rnd + 32'd1;                          // 报告口径 1-based

    // 逐段长度：L1 15 / L2 17 / L3 30 / L4 29 / L5 33 / L6 16 / L7 44 / L8 6 ⇒ 合计 190
    wire [8*15-1:0] rpt_l1 = { "SVADP26101728", 8'h0D, 8'h0A };
    wire [8*17-1:0] rpt_l2 = { "INIT=", hex8({7'b0, sdr_init_done}),
                               " LOCK=", hex8({7'b0, pll_locked}), 8'h0D, 8'h0A };
    // L3 = "CFG=" 4 + 2 + 1 + " BASE=" 6 + 6 + " N=" 3 + 6 = 28，+CRLF = 30
    wire [8*30-1:0] rpt_l3 = { "CFG=", hex8(SHIFT_BYTE), hx(LOWSTEP_NIB),
                               " BASE=", hex24(base24), " N=", hex24(n24), 8'h0D, 8'h0A };
    // L4 = "RND=" 4+8 + "/" 1+8 + " PAT=" 5+1 = 27，+CRLF = 29
    wire [8*29-1:0] rpt_l4 = { "RND=", hex32(rnd_cur), "/", hex32(ROUNDS),
                               " PAT=", hx(pat_mode), 8'h0D, 8'h0A };
    // L5 = "W=" 2+4 + " R=" 3+4 + " CAP=" 5+4 + " BAD=" 5+4 = 31，+CRLF = 33
    wire [8*33-1:0] rpt_l5 = { "W=",   hex16(wr_i[15:0]),
                               " R=",  hex16(rd_i[15:0]),
                               " CAP=",hex16(cap_cnt[15:0]),
                               " BAD=",hex16(bad_cnt),      8'h0D, 8'h0A };
    // L6 = "TOT=" 4+10 = 14，+CRLF = 16
    wire [8*16-1:0] rpt_l6 = { "TOT=", hex40(tot_cnt), 8'h0D, 8'h0A };
    // L7 = "BAD0=" 5+8 + ":" 1+6 + " E=" 3+8 + " A=" 3+8 = 42，+CRLF = 44
    wire [8*44-1:0] rpt_l7 = { "BAD0=", hex32(rnd_rep), ":", hex24(bad0_rep),
                               " E=",   hex32(exp_rep),
                               " A=",   hex32(act_rep),     8'h0D, 8'h0A };
    wire [8*41-1:0] rpt_trace={"TX=",hex32(bad_write_actual),
      " INPT=",hex32(bad_write_expected)," DM=",hx({2'b00,(unmasked_write_words!=TEST_WORDS+16),bad_write_seen}),
      " CNT=",hex16(unmasked_write_words),8'h0D,8'h0A};
    wire [8*6-1:0]  rpt_l8 = { "DONE", 8'h0D, 8'h0A };

    // ★ 两级倒计数选字节：先用 rpt_idx 选报告行，再从该行选字节。
    //   rpt_idx 从 RPT_LAST 递减；每段区间对应一行，字节顺序仍为 MSB→LSB。
    //   把 190:1 的宽选择拆开，避免 BAD0 数据经十六进制编码后再穿过整份报告 mux。
    reg [8*44-1:0] rpt_line_sel;
    reg [5:0]      rpt_byte_pos;
    always @* begin
        rpt_line_sel = { {(44-6){8'h00}}, rpt_l8 };
        rpt_byte_pos = rpt_idx[5:0];
        if (rpt_idx >= 8'd216) begin
            rpt_line_sel = rpt_l1;
            rpt_byte_pos = rpt_idx - 8'd216;
        end else if (rpt_idx >= 8'd199) begin
            rpt_line_sel = rpt_l2;
            rpt_byte_pos = rpt_idx - 8'd199;
        end else if (rpt_idx >= 8'd169) begin
            rpt_line_sel = rpt_l3;
            rpt_byte_pos = rpt_idx - 8'd169;
        end else if (rpt_idx >= 8'd140) begin
            rpt_line_sel = rpt_l4;
            rpt_byte_pos = rpt_idx - 8'd140;
        end else if (rpt_idx >= 8'd107) begin
            rpt_line_sel = rpt_l5;
            rpt_byte_pos = rpt_idx - 8'd107;
        end else if (rpt_idx >= 8'd91) begin
            rpt_line_sel = rpt_l6;
            rpt_byte_pos = rpt_idx - 8'd91;
        end else if (rpt_idx >= 8'd47) begin
            rpt_line_sel = rpt_l7;
            rpt_byte_pos = rpt_idx - 8'd47;
        end else if (rpt_idx >= 8'd6) begin
            rpt_line_sel = rpt_trace;
            rpt_byte_pos = rpt_idx - 8'd6;
        end
    end

    // 第一拍寄存整行，第二拍只从 44 Byte 行内选目标字节；
    // UART 按字节握手期间保持 rpt_byte_q，不改变 190 Byte 报告协议。
    always @(posedge ext_mem_clk or negedge rst_mem_n) begin
        if (!rst_mem_n) begin
            rpt_line_q     <= {(8*44){1'b0}};
            rpt_byte_pos_q <= 6'd0;
            rpt_line_valid <= 1'b0;
            rpt_byte_q     <= 8'd0;
            rpt_byte_valid <= 1'b0;
        end else if (st != ST_REPORT || !rpt_run) begin
            rpt_line_valid <= 1'b0;
            rpt_byte_valid <= 1'b0;
        end else if (!rpt_byte_valid && !rpt_line_valid && (rpt_idx < RPT_LEN)) begin
            rpt_line_q     <= rpt_line_sel;
            rpt_byte_pos_q <= rpt_byte_pos;
            rpt_line_valid <= 1'b1;
        end else if (!rpt_byte_valid && rpt_line_valid) begin
            rpt_byte_q     <= rpt_line_q[{rpt_byte_pos_q, 3'b000} +: 8];
            rpt_byte_valid <= 1'b1;
            rpt_line_valid <= 1'b0;
        end else if (rpt_byte_valid && uart_tx_ready) begin
            rpt_byte_valid <= 1'b0;
        end
    end

    assign uart_tx_valid = (st == ST_REPORT) && rpt_run && rpt_byte_valid;
    assign uart_tx_data  = rpt_byte_q;

    // ------------------------------------------------------------------------
    // 例化：厂商 SDRAM 控制器
    // ------------------------------------------------------------------------
    sdram u_sdram (
        .Clk              (ext_mem_clk),
        .Clk_sft          (ext_mem_clk_sft),
        .Rst              (rst_mem),
        .Sdr_init_done    (sdr_init_done),
        .Sdr_init_ref_vld (sdr_init_ref_vld),
        .Sdr_busy         (sdr_busy),
        .App_wr_en        (app_wr_en),
        .App_wr_addr      (app_wr_addr),
        .App_wr_dm        (app_wr_dm),
        .App_wr_din       (app_wr_din),
        .App_rd_en        (app_rd_en),
        .App_rd_addr      (app_rd_addr),
        .Sdr_rd_en        (sdr_rd_en),
        .Sdr_rd_dout      (sdr_rd_dout)
    );

    // ------------------------------------------------------------------------
    // 例化：UART 发送（50 MHz 域，115200 8N1）
    // ------------------------------------------------------------------------
    uart_tx #(
        .CLK_FREQ (MEM_CLK_FREQ),
        .BAUD     (BAUD)
    ) u_uart_tx (
        .clk       (ext_mem_clk),
        .rst_n     (rst_mem_n),
        .tx_valid  (uart_tx_valid),
        .tx_data   (uart_tx_data),
        .tx_ready  (uart_tx_ready),
        .txd       (uart_txd)
    );

endmodule
