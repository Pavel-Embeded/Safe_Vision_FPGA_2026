# Read-only V3 board queries; no reset, recovery request, or setting changes.
# Raw RX bytes and a timestamped TX/RX journal are preserved even on failure.
param(
    [string]$Port,
    [ValidateRange(0,300)][int]$WaitSeconds = 0,
    [ValidateRange(200,10000)][int]$ReplyTimeoutMs = 2000,
    [switch]$Diagnostics,
    [uint32]$ExpectedDiagnosticId = 0x26101714,
    [string]$OutDir
)
$ErrorActionPreference = 'Stop'
if (-not $OutDir) {
    $repo = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
    $OutDir = Join-Path $repo ('outputs\uart_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
}
if (Test-Path -LiteralPath $OutDir) { throw 'Use a new output directory; captures must not be overwritten.' }
$null = New-Item -ItemType Directory -Path $OutDir
$OutDir = (Resolve-Path -LiteralPath $OutDir).Path
$utf8 = New-Object System.Text.UTF8Encoding($false)
$journal = New-Object System.IO.StreamWriter((Join-Path $OutDir 'capture.jsonl'), $false, $utf8)
$raw = [IO.File]::Open((Join-Path $OutDir 'rx.bin'), [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
$timer = [Diagnostics.Stopwatch]::StartNew()
$sp = $null
$script:rxCount = 0
$script:queryBytes = New-Object 'System.Collections.Generic.List[byte]'
$resultCode = 2
function Save-Event([string]$kind, [hashtable]$fields) {
    $fields.kind = $kind
    $fields.elapsed_ms = $timer.ElapsedMilliseconds
    $fields.utc = [DateTime]::UtcNow.ToString('o')
    $journal.WriteLine(($fields | ConvertTo-Json -Compress -Depth 5))
    $journal.Flush()
}
function Drain-Rx {
    while ($sp.BytesToRead -gt 0) {
        $count = [Math]::Min($sp.BytesToRead,4096)
        $buf = New-Object byte[] $count
        $n = $sp.Read($buf,0,$count)
        if ($n -le 0) { break }
        if ($n -ne $buf.Length) { $buf = [byte[]]$buf[0..($n-1)] }
        $raw.Write($buf,0,$n); $raw.Flush()
        $script:queryBytes.AddRange($buf)
        $script:rxCount += $n
        $hex = [BitConverter]::ToString($buf).Replace('-','')
        Save-Event 'rx' @{hex=$hex; text=[Text.Encoding]::ASCII.GetString($buf)}
    }
}
function Get-ValidAck {
    $text = [Text.Encoding]::ASCII.GetString($script:queryBytes.ToArray())
    foreach ($match in [regex]::Matches($text,'\$(C:ACK=[0-9A-F]{2},[0-9A-F]{8})\*([0-9A-F]{2})\r\n')) {
        $sum = 0
        foreach ($byte in [Text.Encoding]::ASCII.GetBytes($match.Groups[1].Value)) { $sum = $sum -bxor $byte }
        if ($sum -eq [Convert]::ToInt32($match.Groups[2].Value,16)) { return $match.Value.TrimEnd("`r","`n") }
    }
    return $null
}
try {
    $deadline = [DateTime]::UtcNow.AddSeconds($WaitSeconds)
    do {
        if ($Port) {
            if ([IO.Ports.SerialPort]::GetPortNames() -contains $Port) { break }
        } else {
            $found = @(Get-PnpDevice -Class Ports -PresentOnly | Where-Object { $_.InstanceId -match '^USB\\VID_1A86&' })
            if ($found.Count -gt 1) { throw 'Multiple WCH USB serial ports found. Specify -Port COMx.' }
            if ($found.Count -eq 1 -and $found[0].FriendlyName -match '\((COM[0-9]+)\)') { $Port=$Matches[1]; break }
        }
        if ([DateTime]::UtcNow -ge $deadline) { throw 'No board USB-UART port found. Bluetooth serial ports and Anlogic JTAG are not board UART.' }
        Write-Output 'Waiting for board USB-UART...'
        Start-Sleep -Seconds 2
    } while ($true)
    if ($Port -notmatch '^COM[0-9]+$') { throw 'Expected a COM port name.' }
    $sp = New-Object IO.Ports.SerialPort($Port,115200,([IO.Ports.Parity]::None),8,([IO.Ports.StopBits]::One))
    $sp.Handshake=[IO.Ports.Handshake]::None
    $sp.DtrEnable=$false; $sp.RtsEnable=$false
    $sp.ReadTimeout=200; $sp.WriteTimeout=1000
    $sp.Open()
    Save-Event 'opened' @{port=$Port;baud=115200;data_bits=8;parity='None';stop_bits=1;dtr=$false;rts=$false;firmware_identified=$false}
    Write-Output ("Opened {0} at 115200 8N1. No reset or recovery commands will be sent." -f $Port)
    $listen = [Diagnostics.Stopwatch]::StartNew()
    while ($listen.ElapsedMilliseconds -lt 1500) { Drain-Rx; Start-Sleep -Milliseconds 10 }
    $queries = @('STATUS','CACHE','FAULT','LEVEL','INTEGRITY','PRESENTATION','RECOVERY','RETRIES',
        'REJECTED','BADERROR','BADID','IDLOW','IDHIGH','WAVFALLBACK','VUNDERFLOW','UNDERFLOW',
        'OVERFLOW','EVENTDROP','UARTREJECT','UARTFRAME','UARTOVERRUN','UARTDROP')
    if ($Diagnostics) { $queries += @(0..15 | ForEach-Object { 'DIAG{0:D2}' -f $_ }) }
    foreach ($name in $queries) {
        Drain-Rx
        $script:queryBytes.Clear()
        $body = 'B:' + $name + '?'
        if ($name -match '^DIAG([0-9]{2})$') { $body='B:DIAG='+[int]$Matches[1] }
        $sum = 0
        foreach ($byte in [Text.Encoding]::ASCII.GetBytes($body)) { $sum = $sum -bxor $byte }
        $frame = '$' + $body + ('*{0:X2}' -f $sum) + "`r`n"
        $wire = [Text.Encoding]::ASCII.GetBytes($frame)
        Save-Event 'tx' @{query=$name; hex=[BitConverter]::ToString($wire).Replace('-',''); text=$frame}
        $sp.Write($wire,0,$wire.Length)
        $replyClock = [Diagnostics.Stopwatch]::StartNew()
        $ack = $null
        while ($replyClock.ElapsedMilliseconds -lt $ReplyTimeoutMs) {
            Drain-Rx
            $ack=Get-ValidAck
            if ($ack) { break }
            Start-Sleep -Milliseconds 5
        }
        if (-not $ack) {
            Save-Event 'timeout' @{query=$name;timeout_ms=$ReplyTimeoutMs}
            throw ("No checksum-valid ACK for {0}; stopped to avoid attributing a late ACK to the next query." -f $name)
        }
        Save-Event 'ack' @{query=$name; frame=$ack}
        Write-Output ("{0}: {1}" -f $name,$ack)
        $expectedIdentityPattern = '^\$C:ACK=00,{0:X8}\*' -f $ExpectedDiagnosticId
        if ($name -eq 'DIAG00' -and $ack -notmatch $expectedIdentityPattern) {
            throw 'Unexpected reported diagnostic build ID; stopped before interpreting its register map.'
        }
        Start-Sleep -Milliseconds 30
    }
    $listen.Restart()
    while ($listen.ElapsedMilliseconds -lt 1000) { Drain-Rx; Start-Sleep -Milliseconds 10 }
    $resultCode=0
} catch {
    Save-Event 'error' @{message=$_.Exception.Message}
    Write-Output ("CAPTURE INCOMPLETE: " + $_.Exception.Message)
} finally {
    if ($sp) { if ($sp.IsOpen) { $sp.Close() }; $sp.Dispose() }
    Save-Event 'closed' @{exit_code=$resultCode;rx_bytes=$script:rxCount;github_upload_performed=$false}
    $raw.Dispose(); $journal.Dispose()
}
Write-Output ("Saved capture: " + $OutDir)
exit $resultCode
