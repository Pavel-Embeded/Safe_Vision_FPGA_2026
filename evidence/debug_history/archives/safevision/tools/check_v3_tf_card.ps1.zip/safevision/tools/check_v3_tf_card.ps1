param([string]$CardRoot)
$ErrorActionPreference = 'Stop'
if (-not $CardRoot) { $CardRoot = Read-Host 'Enter TF card drive root, for example E:\' }
$projectRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$runtime = Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
if (-not (Test-Path -LiteralPath $runtime)) {
    $runtime = (Get-Command python.exe -ErrorAction Stop).Source
}
$report = Join-Path $projectRoot ('outputs/tf_preflight_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.json')
& $runtime (Join-Path $PSScriptRoot 'check_v3_tf_files.py') --root $CardRoot --output $report --require-card
$result = $LASTEXITCODE
Write-Host ('Report (card was not modified): ' + $report)
exit $result
