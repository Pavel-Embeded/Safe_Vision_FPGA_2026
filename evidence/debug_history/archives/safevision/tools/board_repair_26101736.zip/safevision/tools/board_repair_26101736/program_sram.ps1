param([Parameter(Mandatory=$true)][string]$OutDir)
$ErrorActionPreference='Stop'
$package='D:\Safe_Vision_FPGA_2026\artifacts\board_repair\repair_26101736_674c62e'
$python='C:\Users\曲梓铭\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$exe='D:\Anlogic\TD_6.2.1_Engineer_6.2.168.116\bin\bw_commands_prompt.exe'
if(Test-Path -LiteralPath $OutDir){throw 'Use fresh programming evidence directory'}
& $python -B (Join-Path $package 'verify_payload.py')
if($LASTEXITCODE -ne 0){throw 'Transferred release payload verification failed; no download attempted'}
$index=Get-Content -LiteralPath (Join-Path $package 'release.index.json') -Raw | ConvertFrom-Json
$modes=@($index.modes | Where-Object {$_.mode -eq 'base'})
if($modes.Count -ne 1){throw 'Expected one strictly approved BASE candidate'}
$bit=Join-Path $package $modes[0].bitstream
if((Get-FileHash -LiteralPath $bit -Algorithm SHA256).Hash.ToLowerInvariant() -ne $modes[0].bit_sha256){throw 'Bit identity mismatch'}
$null=New-Item -ItemType Directory -Path $OutDir
$OutDir=(Resolve-Path -LiteralPath $OutDir).Path
$scriptPath=Join-Path $OutDir 'download_full36_sram_only.tcl'
$tcl=@'
set candidate {D:/Safe_Vision_FPGA_2026/artifacts/board_repair/repair_26101736_674c62e/SafeVision_BASE_674c62e.bit}
if {![file isfile $candidate]} {error "Missing approved complete BASE candidate"}
puts "BW_SRAM_FULL36_BEGIN"
if {[catch {download -bit $candidate -mode jtag -spd 7 -cable 0} err]} {
 puts stderr "BW_SRAM_FULL36_FAILED: $err"
 exit 1
}
puts "BW_SRAM_FULL36_COMMAND_COMPLETED"
exit 0
'@
[IO.File]::WriteAllText($scriptPath,$tcl,[Text.Encoding]::ASCII)
$console=Join-Path $OutDir 'download.console.log'
$started=[DateTime]::UtcNow.ToString('o')
& $exe ($scriptPath.Replace('\','/')) *> $console
$code=$LASTEXITCODE
$output=[IO.File]::ReadAllText($console)
$okay=$code -eq 0 -and $output -match 'Chip\s*validation success: EG4S20BG256' -and $output -match 'BW_SRAM_FULL36_COMMAND_COMPLETED' -and $output -notmatch 'BW_SRAM_FULL36_FAILED'
@{program_sram_command_succeeded=$okay;process_exit=$code;bitstream=$bit;bit_sha256=$modes[0].bit_sha256;expected_firmware_id='26101736';started_at_utc=$started;ended_at_utc=[DateTime]::UtcNow.ToString('o');console_sha256=(Get-FileHash -LiteralPath $console -Algorithm SHA256).Hash.ToLowerInvariant();flash_written=$false;hardware_function_verified=$false;github_uploaded=$false} | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $OutDir 'programming.json') -Encoding utf8
if(-not $okay){Get-Content -LiteralPath $console -Tail 15;throw 'SRAM command not confirmed; inspect preserved log'}
Write-Output 'Official SRAM programming command confirmed; actual firmware and behavior still require UART verification.'
