`timescale 1ns/1ps
module tb_v3_board_diagnostics;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0;reg[11:0] x=0,y=0;reg de=1;reg safe=1;
 reg[255:0] diag=0;reg[95:0] cfg=0;
 wire[15:0] rgb_base,rgb_hd;
 v3_status_layers #(.BOARD_DIAGNOSTICS(1),.HD(0),.COMPACT_FONT_FILE("font8x16_compact.mem"),.TEXT_FILE("v3_status_text.mem")) base(
 .pixel_clk(clk),.pixel_rst_n(rst_n),.raw_x(x),.raw_y(y),.raw_de(de),.frame_start(1'b0),.cfg_data(cfg),.board_diag(diag),
 .cache_valid(4'd0),.underflows(32'd0),.active_slot(2'd0),.generation(8'd0),.busy(1'b0),.safety_active(safe),
 .osd_rgb565(),.emergency_rgb565(),.hud_rgb565(),.safe_rgb565(rgb_base),.osd_alpha(),.emergency_alpha(),.hud_alpha());
 v3_status_layers #(.BOARD_DIAGNOSTICS(1),.HD(1),.COMPACT_FONT_FILE("font8x16_compact.mem"),.TEXT_FILE("v3_status_text.mem")) hd(
 .pixel_clk(clk),.pixel_rst_n(rst_n),.raw_x(x),.raw_y(y),.raw_de(de),.frame_start(1'b0),.cfg_data(cfg),.board_diag(diag),
 .cache_valid(4'd0),.underflows(32'd0),.active_slot(2'd0),.generation(8'd0),.busy(1'b0),.safety_active(safe),
 .osd_rgb565(),.emergency_rgb565(),.hud_rgb565(),.safe_rgb565(rgb_hd),.osd_alpha(),.emergency_alpha(),.hud_alpha());
 reg[7:0] font[0:4095];integer errors=0,comparisons=0,m,l,c,r,b,yy;
 string expected[0:3];bit dot;reg[15:0] actual;
 task check(input bit good,input string msg);begin comparisons++;if(!good)begin if(errors<12)$display("[FAIL] %s mode=%0d line=%0d col=%0d x=%0d y=%0d",msg,m,l,c,x,y);errors++;end end endtask
 task point(input integer xx,yyy);begin @(negedge clk);x=xx;y=yyy;repeat(4)@(posedge clk);#1;end endtask
 initial begin
  $readmemh("font8x16.mem",font);
  // Independent fixture values: state8/stage7, player E3/42, sink4/F3,
  // flagsE, cache3/1, CMD58/R1=01, manual0, recovery4/attempt2.
  diag={32'h26101610,32'he3428737,32'h4f3e1802,32'h12345678,
        32'ha3082580,32'h000a0500,32'h01234567,32'h89abcdef};
  cfg[47:40]=8'h04;
  expected[0]="ID 26101610 P 8/7 E E3/42 F 04";
  expected[1]="SD 4 R1 01 M E S 4/F3 C 3/1 K 0 R 4 T 2";
  expected[2]="RX 12345678 W 02580 ROW 0C2";
  expected[3]="BAD 000A0500 EXP 01234567 GOT 89ABCDEF";
  repeat(5)@(negedge clk);rst_n=1;
  for(m=0;m<2;m++)for(l=0;l<4;l++)begin
   yy=l==0?8:l==1?24:l==2?40:(m?720:480)-80;
   for(c=0;c<expected[l].len();c++)for(r=0;r<16;r++)for(b=0;b<8;b++)begin
    dot=font[expected[l][c]*16+r][7-b];point(8+c*8+b,yy+r);actual=m?rgb_hd:rgb_base;
    check(actual==(dot?16'hffff:16'h1800),"independent diagnostic text glyph and field order");
   end
  end
  de=0;repeat(4)@(posedge clk);#1;check(rgb_base==0 && rgb_hd==0,"blanking masks diagnostics");
  $display("[PASS] BASE/HD diagnostic glyphs, field order, four-clock pipeline and blanking");
  $display("PASS tb_v3_board_diagnostics comparisons=%0d errors=%0d",comparisons,errors);$finish;
 end
 initial begin #3000000;$fatal(1,"diagnostic test timeout");end
endmodule
