`timescale 1ns/1ps
module tb_v3_frame_snapshot;
 reg src=0,dst=0,rst=0;always #5 src=~src;always #6.734 dst=~dst;
 reg[255:0] input_data=0;wire[255:0] output_data;wire ready,valid;
 integer phase=0,source_count=0,captures=0,comparisons=0,errors=0;
 wire accept_frame=phase==0;
 reg[255:0] expected_payload=0,previous_output=0,expected_edge=0;
 video_cdc_mailbox #(.WIDTH(256),.CAPTURE_AT_ACCEPT(1)) dut(
 .src_clk(src),.src_rst_n(rst),.src_data(input_data),.src_valid(1'b1),.src_ready(ready),
 .dst_clk(dst),.dst_rst_n(rst),.dst_data(output_data),.dst_valid(valid),.dst_ready(accept_frame));
 task check(input bit good,input string msg);begin comparisons++;if(!good)begin if(errors<8)$display("[FAIL] %s t=%t",msg,$time);errors++;end end endtask
 always @(negedge src)if(rst)begin input_data<={8{32'hca500000+source_count}};source_count<=source_count+1;end
 always @(posedge src)if(rst && ready)expected_payload=input_data;
 always @(posedge dst)begin
  if(!rst)begin phase<=0;previous_output=0;end
  else begin
   phase<=phase==96?0:phase+1;
   expected_edge=(valid && accept_frame)?expected_payload:previous_output;
   if(valid && accept_frame)captures++;
   #1;check(output_data===expected_edge,"capture only at frame boundary; all256 bits equal accepted source epoch");
   previous_output=output_data;
  end
 end
 initial begin
  repeat(8)@(negedge src);rst=1;
  wait(captures==1000);@(negedge src);rst=0;#1;
  check(output_data===0,"common reset clears the diagnostic epoch");
  repeat(8)@(negedge src);rst=1;wait(captures==1100);@(negedge src);
  $display("[PASS] 1100 atomic frame snapshots across asynchronous SYS/PIX clocks and reset");
  $display("PASS tb_v3_frame_snapshot comparisons=%0d errors=%0d",comparisons,errors);$finish;
 end
 initial begin #3000000;$fatal(1,"frame snapshot timeout");end
endmodule
