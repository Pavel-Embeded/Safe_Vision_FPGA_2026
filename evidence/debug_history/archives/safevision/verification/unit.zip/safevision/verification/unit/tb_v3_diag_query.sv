`timescale 1ns/1ps
module tb_v3_diag_query;
 reg sys_clk=0,mem_clk=0,sys_rst_n=0,mem_rst_n=0;
 always #5 sys_clk=~sys_clk;always #8.5 mem_clk=~mem_clk;
 reg request=0;reg[3:0] selector=0;wire ready,reply,ok;wire[3:0] mem_selector;wire[31:0] value;
 reg[31:0] epoch=32'h572190a3;wire[31:0] mem_value=(epoch^{mem_selector,24'hcf3917,mem_selector});
 v3_diag_query dut(.sys_clk(sys_clk),.sys_rst_n(sys_rst_n),.mem_clk(mem_clk),.mem_rst_n(mem_rst_n),
 .request_valid(request),.request_selector(selector),.request_ready(ready),.mem_selector(mem_selector),
 .mem_value(mem_value),.reply_valid(reply),.reply_ok(ok),.reply_value(value));
 integer errors=0,comparisons=0,replies=0,samples=0,i,timeout;
 reg[31:0] expected;reg expected_valid=0;
 task ck(input bit condition,input string message);begin comparisons++;
  if(!condition)begin errors++;if(errors<9)$display("[FAIL] %s t=%t",message,$time);end
 end endtask
 always @(posedge mem_clk)if(mem_rst_n)begin
  epoch<=epoch+32'h09281753;
  if(dut.mem_request && dut.response_src_ready)begin expected=mem_value;expected_valid=1;samples++;end
 end
 always @(posedge sys_clk)if(sys_rst_n && reply)begin
  ck(ok && expected_valid && value===expected,"tag and32-bit word equal the MEM acceptance snapshot");
  expected_valid=0;replies++;
 end
 task reset_epoch;begin
  @(negedge sys_clk);sys_rst_n=0;mem_rst_n=0;request=0;expected_valid=0;
  #37;@(negedge sys_clk);sys_rst_n=1;@(negedge mem_clk);mem_rst_n=1;
  repeat(20)@(negedge sys_clk);ck(!reply && ready,"reset cancels old telemetry and returns ready");
 end endtask
 initial begin
  reset_epoch();
  for(i=0;i<1024;i++)begin
   timeout=0;while(!ready && timeout<100)begin @(negedge sys_clk);timeout++;end
   ck(ready,"request bridge remains live");selector=i%16;request=1;
   @(negedge sys_clk);request=0;selector=~selector;
   timeout=0;while(!reply && timeout<100)begin @(negedge sys_clk);timeout++;end
   ck(reply,"each accepted request has a bounded response");
   @(negedge sys_clk);repeat(i%4)@(negedge sys_clk);
   if(i%97==0)reset_epoch();
  end
  repeat(20)@(negedge sys_clk);
  ck(replies==1024 && samples==1024,"exactly one response per query across1024 varying selectors");
  // Abandon a query in flight, then establish a new common reset epoch.
  selector=7;request=1;@(negedge sys_clk);request=0;reset_epoch();
  repeat(30)@(negedge sys_clk);ck(!reply,"abandoned response cannot leak into the next epoch");
  if(errors==0)$display("[PASS] on-demand MEM telemetry, asynchronous clocks, tags and common reset");
  $display("[TB] tb_v3_diag_query done errors=%0d comparisons=%0d",errors,comparisons);$finish;
 end
 initial begin #1000000;$display("[FAIL] diag bridge watchdog errors=1");$finish;end
endmodule
