// Independent pin-UART oracle and raw data comparison; ideal alignment model.
// Does not simulate encrypted IP, BRAM implementation or real SDRAM physics.
`timescale 1ns/1ps
module tb_v3_adapter_path_probe;
  reg clk=0,rst_n=0;always #10 clk=~clk;
  wire tx;wire[3:0]led;
  sv_v3_adapter_path_probe #(.POWERUP_CYC(200),.INIT_TO_CYC(2000),
    .RD_WAIT_TO_CYC(20000),.TEST_WORDS(64),.HOST_GAP(55),
    .ROUNDS(12),.BAUD(1000000)) u_top(.clk(clk),.rst_n(rst_n),.uart_txd(tx),.led(led));
  localparam DIV=50;
  reg[7:0]rx[0:1023],expected[0:569];reg[31:0]patterns[0:383];
  integer rx_n=0,b,errors=0,scenario=0,i,n,base=0;
  reg[7:0]v;
  integer good_words=0,bad_words=0,rounds_seen=0,singleton_bursts=0;
  integer by_mode[0:5][0:1];
  integer burst_beats=0,burst_real=0;
  reg old_wr=0;
  reg hold_req=0,old_req_wr;reg[31:0]old_addr,old_data;
  task check(input bit cond,input string message);
    if(cond)$display("[PASS] %s",message);
    else begin $display("[FAIL] %s",message);errors=errors+1;end
  endtask
  initial begin
    $readmemh("adapter_path_patterns.hex",patterns);
    $readmemh("adapter_path_reports.hex",expected);
    for(i=0;i<6;i=i+1)begin by_mode[i][0]=0;by_mode[i][1]=0;end
    forever begin
      @(negedge tx);
      repeat(DIV+DIV/2)@(posedge u_top.ext_mem_clk);
      for(b=0;b<8;b=b+1)begin
        v[b]=tx;
        if(b!=7)repeat(DIV)@(posedge u_top.ext_mem_clk);
      end
      if(rx_n<1024)begin rx[rx_n]=v;rx_n=rx_n+1;end
      repeat(DIV/2)@(posedge u_top.ext_mem_clk);
    end
  end
  // Independent oracle compares each collected word to precomputed addresses.
  // Negative cases must have exactly one bad word; positive covers all modes.
  always @(posedge u_top.ext_mem_clk)begin
    if(u_top.rst_mem_n)begin
      if(u_top.rd_capture)begin
        if((u_top.read_via_adapter?u_top.adapter_rdata:u_top.physical_read_previous)
            !==patterns[u_top.pat_mode*64+u_top.cap_cnt])bad_words=bad_words+1;
        else good_words=good_words+1;
        if(scenario==0)by_mode[u_top.pat_mode][u_top.read_via_adapter]=
          by_mode[u_top.pat_mode][u_top.read_via_adapter]+1;
      end
      if(u_top.st==9)rounds_seen=rounds_seen+1;
      if(u_top.write_via_adapter&&u_top.app_wr_en)begin
        burst_beats=burst_beats+1;
        if(u_top.app_wr_dm==0)burst_real=burst_real+1;
      end
      if(old_wr&&!u_top.app_wr_en&&u_top.write_via_adapter)begin
        if(burst_beats!=2||burst_real!=1)begin
          $display("[FAIL] singleton burst real=%0d total=%0d",burst_real,burst_beats);errors=errors+1;
        end
        singleton_bursts=singleton_bursts+1;burst_beats=0;burst_real=0;
      end
      old_wr=u_top.app_wr_en;
      if(hold_req&&(!u_top.adapter_req||u_top.host_write!=old_req_wr||
          (u_top.host_write?{11'b0,u_top.wr_addr}:{11'b0,u_top.rd_addr})!==old_addr||
          (old_req_wr&&u_top.pat_wr!==old_data)))begin
        $display("[FAIL] host changed a stalled request");errors=errors+1;
      end
      hold_req=u_top.adapter_req&&!u_top.adapter_ready;
      old_req_wr=u_top.host_write;
      old_addr=u_top.host_write?{11'b0,u_top.wr_addr}:{11'b0,u_top.rd_addr};old_data=u_top.pat_wr;
    end else begin hold_req=0;old_wr=0;burst_beats=0;burst_real=0;end
  end
  task begin_scenario(input integer s);
    begin
      scenario=s;rst_n=0;u_top.u_sdram.valid_lag=1;
      u_top.u_sdram.err_mask=0;good_words=0;bad_words=0;
      rounds_seen=0;singleton_bursts=0;
      #200;rst_n=1;
    end
  endtask
  task check_report(input integer number,input integer success);
    begin
      wait(rx_n>=base+190);#2000;
      check(rx_n==base+190,"one complete 190-byte UART frame");
      n=0;
      for(i=0;i<190;i=i+1)if(rx[base+i]!==expected[number*190+i])begin
        if(n<8)$display("byte%0d actual=%02h expected=%02h",i,rx[base+i],expected[number*190+i]);n=n+1;
      end
      check(n==0,"all UART bytes match independent oracle");
      check(led== (success?4'h8:4'h3),"terminal status matches data verdict");
      base=rx_n;
    end
  endtask
  initial begin
    #1;begin_scenario(0);check_report(0,1);
    check(good_words==768&&bad_words==0,"all 768 positive words match independent patterns");
    check(rounds_seen==11,"all 12 rounds completed");
    check(singleton_bursts==384,"all 384 slow writes used one word plus masked padding");
    for(i=0;i<6;i=i+1)begin
      check(by_mode[i][0]==64,"six patterns: adapter write/direct read coverage");
      check(by_mode[i][1]==64,"six patterns: direct write/adapter read coverage");
    end
    begin_scenario(1);
    wait(u_top.rnd==0&&u_top.st==3);
    u_top.u_sdram.err_address=5;u_top.u_sdram.err_mask=1;
    check_report(1,0);
    check(bad_words==1&&good_words==63,"odd path detects exactly the injected error");
    check(rounds_seen==0,"odd path stops on first failing round");
    begin_scenario(2);
    wait(u_top.rnd==1&&u_top.st==3);
    u_top.u_sdram.err_address=5;u_top.u_sdram.err_mask=1;
    check_report(2,0);
    check(bad_words==1&&good_words==127,"even path detects exactly the injected error");
    check(rounds_seen==1,"even path preserves one preceding good round");
    $display("[TB] tb_v3_adapter_path_probe done, errors=%0d comparisons=960",errors);$finish;
  end
  initial begin #50000000;$display("[FAIL] watchdog rx=%0d st=%0d",rx_n,u_top.st);$finish;end
endmodule
