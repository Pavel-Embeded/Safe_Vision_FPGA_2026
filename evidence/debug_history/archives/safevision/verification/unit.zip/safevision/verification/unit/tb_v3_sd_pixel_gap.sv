`timescale 1ns/1ps
// 50MHz MEM, real 640x480 writer. A legal card may wait >4ms before
// returning a sector. Both writers see exactly the same data and stalls.
module tb_v3_sd_pixel_gap;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,start=0,valid=0;reg[15:0] pixel=0;
 wire ready,req,done,ok,err,old_error;wire[31:0] address,data;
 wire[3:0] slots;wire[18:0] count;integer errors=0,comparisons=0,words=0,i,guard;
 reg old_failed=0;
 frame_writer #(.GAP_TIMEOUT(25000000)) dut(.clk(clk),.rst_n(rst_n),.start(start),.slot_sel(2'd0),.slot_base(32'd0),
 .din(pixel),.din_valid(valid),.din_ready(ready),.wr_req(req),.wr_addr(address),.wr_data(data),.wr_len(),.wr_ready(1'b1),
 .wr_done(done),.slot_valid(slots),.crc_ok(ok),.crc_value(),.px_cnt(count),.wr_error(err),.err_code(),.err_detail());
 frame_writer #(.GAP_TIMEOUT(200000)) old_budget(.clk(clk),.rst_n(rst_n),.start(start),.slot_sel(2'd0),.slot_base(32'd0),
 .din(pixel),.din_valid(valid),.din_ready(),.wr_req(),.wr_addr(),.wr_data(),.wr_len(),.wr_ready(1'b1),
 .wr_done(),.slot_valid(),.crc_ok(),.crc_value(),.px_cnt(),.wr_error(old_error),.err_code(),.err_detail());
 function[15:0] pattern(input integer n);pattern=(n*17)^16'h6a35;endfunction
 task check(input bit good,input string msg);begin comparisons++;if(!good)begin if(errors<8)$display("[FAIL] %s t=%t",msg,$time);errors++;end end endtask
 always @(posedge clk)if(rst_n)begin
  if(old_error)old_failed<=1;
  if(req)begin
   check(address==words*4,"accepted address matches independent raster word index");
   check(data=={pattern(words*2+1),pattern(words*2)},"word packing/data exact after long card stalls");
   words++;
  end
 end
 initial begin
  repeat(5)@(negedge clk);rst_n=1;repeat(3)@(negedge clk);start=1;@(negedge clk);start=0;
  // 8ms before first sector payload; no SIM_FAST_TO shortening.
  repeat(400000)@(negedge clk);
  check(old_failed && !err,"old 4ms budget rejects 8ms card wait; repaired writer stays ready");
  for(i=0;i<307200;i++)begin
   if(i==640)begin valid=0;repeat(1500000)@(negedge clk);check(!err,"30ms FAT/sector gap remains legal");end
   pixel=pattern(i);valid=1;
   do begin @(posedge clk);end while(!ready);
   @(negedge clk);
  end
  valid=0;guard=0;while(!done && guard<50)begin @(negedge clk);guard++;end
  check(done && ok && slots[0] && count==307200 && words==153600 && !err,"complete frame published only after every accepted word");
  // The repair must retain a real, reachable failure boundary, including the
  // widened25-bit timer. This is500ms of production MEM50 clock edges.
  @(negedge clk);rst_n=0;repeat(4)@(negedge clk);rst_n=1;
  repeat(3)@(negedge clk);start=1;@(negedge clk);start=0;
  repeat(25000010)@(negedge clk);
  check(err && !ok && slots==0,"production500ms no-progress bound still fails closed and never publishes a partial frame");
  $display("[PASS] physical-time SD stall counterexample and full-frame writer");
  $display("PASS tb_v3_sd_pixel_gap comparisons=%0d errors=%0d",comparisons,errors);$finish;
 end
 initial begin #700000000;$fatal(1,"pixel gap test timeout");end
endmodule
