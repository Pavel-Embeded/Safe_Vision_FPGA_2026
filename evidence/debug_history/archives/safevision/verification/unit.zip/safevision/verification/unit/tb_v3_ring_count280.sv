`timescale 1ns/1ps
module tb_v3_ring_count280;
 reg clk=0,rst=0,ack=0,busy=0,rv=0;integer errors=0,comparisons=0,v,d,k;reg[14:0]value,expected;
 v3_pcm_ring dut(.clk(clk),.rst_n(rst),.in_data(128'd0),.in_valid(4'd0),.commit_valid(1'b0),.commit_slot(2'd0),.commit_generation(8'd0),.fallback(4'd0),.out_ready(1'b0),.output_level(10'd0),.ack(ack),.busy(busy),.rdata(32'd0),.rvalid(rv));
 initial begin #1;rst=1;
  for(d=0;d<2;d++)begin
   dut.state=d?1:2;dut.reading=d;ack=1;rv=d;
   for(v=0;v<32768;v++)begin
    dut.count[0]=15'(v+0*83);
    dut.count[1]=15'(v+1*83);
    dut.count[2]=15'(v+2*83);
    dut.count[3]=15'(v+3*83);
    #1;
    value=15'(v+0*83);expected=d?(value-15'd1):(value+15'd1);comparisons++;if(dut.parallel_pointers[0].count_next!==expected)begin errors++;if(errors<6)$display("[FAIL] count full-domain slot0 seed%0d dec%0d",v,d);end
    value=15'(v+1*83);expected=d?(value-15'd1):(value+15'd1);comparisons++;if(dut.parallel_pointers[1].count_next!==expected)begin errors++;if(errors<6)$display("[FAIL] count full-domain slot1 seed%0d dec%0d",v,d);end
    value=15'(v+2*83);expected=d?(value-15'd1):(value+15'd1);comparisons++;if(dut.parallel_pointers[2].count_next!==expected)begin errors++;if(errors<6)$display("[FAIL] count full-domain slot2 seed%0d dec%0d",v,d);end
    value=15'(v+3*83);expected=d?(value-15'd1):(value+15'd1);comparisons++;if(dut.parallel_pointers[3].count_next!==expected)begin errors++;if(errors<6)$display("[FAIL] count full-domain slot3 seed%0d dec%0d",v,d);end
   end
  end
  if(!errors)$display("[PASS] actual four ring counters:every15-bit state,increment/decrement,wrap/underflow,262144 comparisons");
  $display("[TB] tb_v3_ring_count280 done errors=%0d comparisons=%0d",errors,comparisons);$finish;
 end
endmodule
