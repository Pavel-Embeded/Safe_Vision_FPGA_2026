`timescale 1ns/1ps
module tb_v3_adapter_read64_probe;
 reg clk=0,rst=0;always #10 clk=~clk;wire tx;wire[3:0]led;
 sv_v3_adapter_read64_probe #(.POWERUP_CYC(200),.INIT_TO_CYC(2000),.RD_WAIT_TO_CYC(20000),.TEST_WORDS(128),.ROUNDS(6),.WR_DRAIN_CYC(1024),.BAUD(1000000)) dut(clk,rst,tx,led);
 reg[31:0]gold[0:767];reg[7:0]report[0:1385];integer errors=0,comparisons=0,received=0,i,b;reg[7:0]v;
 initial begin $readmemh("adapter_read64_patterns.hex",gold);$readmemh("adapter_read64_reports.hex",report);#1;dut.u_sdram.valid_lag=1;#99;rst=1;end
 always @(posedge dut.ext_mem_clk)if(dut.rd_capture)begin
  comparisons++;if(dut.adapter_rdata!==gold[dut.pat_mode*128+dut.cap_cnt])begin errors++;if(errors<5)$display("[FAIL] independent word pattern differs");end
 end
 initial forever begin
  @(negedge tx);repeat(75)@(posedge dut.ext_mem_clk);
  for(b=0;b<8;b++)begin v[b]=tx;if(b<7)repeat(50)@(posedge dut.ext_mem_clk);end
  if(received<1386)begin comparisons++;if(v!==report[received])begin errors++;if(errors<5)$display("[FAIL] pin UART byte=%0d got=%h expected=%h",received,v,report[received]);end end
  received++;repeat(25)@(posedge dut.ext_mem_clk);
 end
 initial begin wait(received==1386);repeat(100)@(posedge clk);
  if(dut.st!=7||dut.any_error||dut.adapter_fault||dut.checked_cnt!=128||dut.bad_cnt!=0)begin errors++;$display("[FAIL] terminal completion status differs");end
  if(comparisons!=2154)begin errors++;$display("[FAIL] missing word or UART comparisons %0d",comparisons);end
  if(errors==0)$display("[PASS] six128-word patterns plus1386 UART bytes independent reference");
  $display("[TB] tb_v3_adapter_read64_probe done comparisons=%0d errors=%0d",comparisons,errors);$finish;
 end
 initial begin #50000000;errors++;$display("[FAIL] bounded probe timeout");$display("[TB] tb_v3_adapter_read64_probe done comparisons=%0d errors=%0d",comparisons,errors);$finish;end
endmodule
