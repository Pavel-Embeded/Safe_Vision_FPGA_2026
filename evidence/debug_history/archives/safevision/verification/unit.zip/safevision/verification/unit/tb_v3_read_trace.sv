`timescale 1ns/1ps
module tb_v3_read_trace;
 reg clk=0;always #10 clk=~clk;reg rst_n=0;wire tx;wire[3:0]led;
 sv_v3_read_trace #(.BAUD(1000000),.POWERUP_CYC(200),.INIT_TO_CYC(2000),.ROUNDS(1))dut(clk,rst_n,tx,led);
 integer errors=0,checks=0,rx_n=0,base=0,i,j,lag,scenario;reg[7:0]rx[0:4095];reg[7:0]v;
 initial forever begin
  @(negedge tx);repeat(75)@(posedge dut.ext_mem_clk);
  for(integer b=0;b<8;b=b+1)begin v[b]=tx;if(b!=7)repeat(50)@(posedge dut.ext_mem_clk);end
  rx[rx_n]=v;rx_n=rx_n+1;repeat(25)@(posedge dut.ext_mem_clk);
 end
 task check(input ok,input string name);begin
  checks=checks+1;
  if(ok)$display("[PASS] %s",name);else begin errors=errors+1;$display("[FAIL] %s",name);end
 end endtask
 function[31:0]sig(input integer n);
  reg[20:0]a;reg[7:0]b0,b1,b2,b3;
  begin a=n*2049;b0=8'hc3^{a[4:0],a[7:5]};b1=8'h3c^a[7:0];
   b2=8'h5a^a[7:0]^a[12:5];b3=8'ha5^a[7:0]^a[20:13];sig={b3,b2,b1,b0};end
 endfunction
 function string hex4(input integer n);begin hex4=$sformatf("%04X",n&65535);end endfunction
 string expect_report,line,head,align_line;string eol="\015\012";integer prev_expected,cur_expected,next_expected;
 integer tracesrc,validbit;reg[31:0]tracedata;
 initial begin
  for(scenario=0;scenario<4;scenario=scenario+1)begin
   lag=(scenario==3)?0:scenario-1;
   rst_n=0;#200;dut.u_sdram.valid_lag=lag;
   dut.u_sdram.err_address=21'h1fffff;dut.u_sdram.err_mask=0;
   if(scenario==3)begin dut.u_sdram.err_address=5*2049;dut.u_sdram.err_mask=1;end
   base=rx_n;rst_n=1;
   wait(rx_n>=base+694);#100000;
   check(rx_n==base+694,"complete bounded694-byte UART report");
   prev_expected=(lag==1)?0:1024;
   cur_expected=(lag==0)?0:((lag==1)?960:1024);
   next_expected=(lag==-1)?0:960;
   if(scenario==3)cur_expected=1;
   check(dut.prev_bad==prev_expected,"independent previous-cycle mismatch count");
   check(dut.bad_cnt==cur_expected,"independent current-cycle mismatch count");
   check(dut.next_bad==next_expected,"independent next-cycle mismatch count");
   check(led==((cur_expected==0)?8:3),"current-path success/error LED status preserved");
   head="SV3-M50P8-TRACE ID=26101701\015\012INIT=01 LOCK=01\015\012CFG=0B1 BASE=000000 N=000400\015\012RND=00000001/00000001 PAT=0\015\012";
   expect_report={head,"W=0400 R=0400 CAP=0400 BAD=",hex4(cur_expected),"\015\012TOT=0000000400\015\012"};
   if(cur_expected==0)expect_report={expect_report,"BAD0=FFFFFFFF:FFFFFF E=00000000 A=00000000\015\012"};
   else if(scenario==3)expect_report={expect_report,$sformatf("BAD0=00000001:002805 E=%08X A=%08X",sig(5),sig(5)^1),eol};
   else expect_report={expect_report,$sformatf("BAD0=00000001:000000 E=%08X A=%08X",sig(0),(lag==1)?sig(1):32'd0),eol};
   expect_report={expect_report,"ALIGN P=",hex4(prev_expected)," C=",hex4(cur_expected)," N=",hex4(next_expected),"\015\012"};
   for(j=0;j<22;j=j+1)begin
    tracesrc=j-2+lag;validbit=j>=2&&j<18;
    if(tracesrc<0)tracedata=0;else tracedata=sig((tracesrc>15)?15:tracesrc);
    if(scenario==3&&tracesrc==5)tracedata=tracedata^1;
    expect_report={expect_report,$sformatf("T=%02X V=%1X D=%08X",j,validbit,tracedata),eol};
   end
   expect_report={expect_report,"DONE\015\012"};
   expect_report=expect_report.toupper();
   check(expect_report.len()==694,"independent report length");
   for(i=0;i<694;i=i+1)if(rx[base+i]!==expect_report[i])begin
    errors=errors+1;$display("[FAIL] serial byte scenario%0d index%0d got%02x expected%02x",scenario,i,rx[base+i],expect_report[i]);
   end
   check(errors==0,"every serial byte matches independent oracle");
  end
  $display("[TB] tb_v3_read_trace done, errors=%0d checks=%0d",errors,checks);$finish;
 end
 initial begin #100000000;$display("[FAIL] watchdog errors=1");$finish;end
endmodule
