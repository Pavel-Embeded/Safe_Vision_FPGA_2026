# BASE 26102801 Flash 安装包

本包用于 EG4S20BG256 / HX4S20C 的固化和旧版恢复。当前位流为 SafeVision_BASE_75b34e6.bit，SHA-256：

`1a0cf8cccdb1487b34f70e20eaa333dc106826dbc1d821be99b6a828b80b4083`

新版已完成 Flash 写入、厂商校验、两次完整读回和重载检查。用户确认完全断电重接后图片、声音、字幕、UP 计时和频谱正常，后续只读串口回读通过。原始命令、备份和回执保存在 flash 目录；实体断电按用户反馈登记。

## 安装

把整个 ZIP 解压到英文路径，连接 JTAG USB-B、Type-C、TF 卡和 HDMI。在解压目录打开 PowerShell，先预览：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\flash\tools\program_flash.ps1 -Image Latest
```

确认选择后执行。OutDir 使用新的英文目录，脚本保留当时的两次完整 Flash 备份，再写入、校验、读回和重载。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\flash\tools\program_flash.ps1 -Image Latest -Apply -OutDir D:\Codex\SafeVision_Flash_Run
```

默认 BitWriter 路径为 D:\Anlogic\TD_6.2.1_Engineer_6.2.168.116\bin\bw_commands_prompt.exe。可通过 -ToolPath 指定相同工具的其他安装路径；脚本核对工具和位流校验值，并确认器件与 EF4015 Flash。

## 恢复

选择 Previous 可恢复包内保留的成功 BASE 26102301：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\flash\tools\program_flash.ps1 -Image Previous -Apply -OutDir D:\Codex\SafeVision_Flash_Rollback
```

Previous 使用 flash/recovery/SafeVision_BASE_6a957b0.bit。安装前原始 Flash 内容另存为 before_flash_a.bin 和 before_flash_b.bin，其内容按实际读出保留，不指定固件版本。

## 使用与复查

TF 卡使用 FAT32，根目录至少放四张有效的 24 位或 32 位 BI_RGB BMP，可使用中文长文件名和不同尺寸。伴音 WAV 为 48 kHz、双声道、16 位 PCM。默认五秒轮播，KEY2 换图，KEY3 切换自动轮播，KEY2+KEY3 长按约两秒进入菜单。

串口为 115200、8N1，固件 ID 为 26102801，稳定播放时 STATUS=7、CACHE=15。完整源码、功能和时序归档、串口检查及安装验收入口保存在项目仓库与完整项目备份；本 ZIP 只包含安装和恢复所需文件及相关原件。package.index.json 列出本包文件的 SHA-256，release.index.json 保留烧录前批准身份。
