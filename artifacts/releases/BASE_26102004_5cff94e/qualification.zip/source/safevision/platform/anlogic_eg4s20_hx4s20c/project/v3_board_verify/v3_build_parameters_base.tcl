# BASE strategy2: only EG4 parameters confirmed in native registered tables.
set_param place pr_strategy 5

set_param place post_place_opt medium
set_param place hfn_opt_effort low

set_param place seed 0

# Target measured SYS100 watchdog route using documented setup-margin mode.
set_param route timing greedy
