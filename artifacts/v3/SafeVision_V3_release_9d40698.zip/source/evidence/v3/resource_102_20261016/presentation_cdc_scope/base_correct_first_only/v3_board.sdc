# All time values in ns. No clock-group or SDRAM-boundary false paths.
# SWUG200 (TD 6.2), sections 3.3, 3.8, 3.9 and 3.12 are the command syntax.
create_clock -name board_clk -period 20.000 -waveform {0 10} [get_ports {clk}]
derive_clocks

# SPI mode 0, CLK_DIV_FAST=1 and CLK_DIV_INIT=249 in safevision_v3_top.
# The generated clocks model the enabled parts of bursts; clock stops between
# bytes do not create a faster electrical edge. Both legal operating modes are
# represented, rather than applying the 14ns transfer limit during startup.
create_generated_clock -name sd_fast -source [get_ports {clk}] -master_clock [get_clocks {board_clk}] -divide_by 4 [get_ports {sd_dclk}]
create_generated_clock -name sd_ident -source [get_ports {clk}] -master_clock [get_clocks {board_clk}] -divide_by 500 -add [get_ports {sd_dclk}]

# UD INFO SDC-09UG V1.2, printed p31 section 6.4.1:
# tODLY transfer=0..14ns, identification=0..50ns, setup/hold=5ns.
# Two ns each way is a declared PCB design allowance, NOT a measurement.
# Launch reference is the forwarded SCLK falling edge at the FPGA output.
set_input_delay -clock [get_clocks sd_fast] -clock_fall -max 18.000 [get_ports {sd_miso}]
set_input_delay -clock [get_clocks sd_fast] -clock_fall -min 0.000 [get_ports {sd_miso}]
set_input_delay -clock [get_clocks sd_ident] -clock_fall -max 54.000 -add_delay [get_ports {sd_miso}]
set_input_delay -clock [get_clocks sd_ident] -clock_fall -min 0.000 -add_delay [get_ports {sd_miso}]
# TD's partial-delay check also requires the other launch edge. Keep every
# physical falling-SCLK constraint above and additionally check a conservative
# hypothetical rising-SCLK change with the same bounds. This only adds checks;
# real mode-0 MISO still launches at SCLK falling. Detailed witnesses must retain
# that physical falling source for setup AND hold, under both operating modes.
set_input_delay -clock [get_clocks sd_fast] -max 18.000 -add_delay [get_ports {sd_miso}]
set_input_delay -clock [get_clocks sd_fast] -min 0.000 -add_delay [get_ports {sd_miso}]
set_input_delay -clock [get_clocks sd_ident] -max 54.000 -add_delay [get_ports {sd_miso}]
set_input_delay -clock [get_clocks sd_ident] -min 0.000 -add_delay [get_ports {sd_miso}]
set_output_delay -clock [get_clocks sd_fast] -max 7.000 [get_ports {sd_mosi sd_ncs}]
set_output_delay -clock [get_clocks sd_fast] -min -7.000 [get_ports {sd_mosi sd_ncs}]
set_output_delay -clock [get_clocks sd_ident] -max 7.000 -add_delay [get_ports {sd_mosi sd_ncs}]
set_output_delay -clock [get_clocks sd_ident] -min -7.000 -add_delay [get_ports {sd_mosi sd_ncs}]

# These are literal SPI receive enables, not timing optimization waivers:
# fast: fall -> TWO board edges -> next enabled rise;
# identification: fall -> 250 board edges -> next enabled rise.
# MISO's first sample can be packed into the input PAD; the remaining seven
# rx_sr shift registers are not PI capture endpoints. Bind the actual input.
# tb_v3_spi_budget verifies the
# edge spacing, MOSI setup/hold, and the two legal card response-delay limits.
set_multicycle_path -setup -from [get_clocks sd_fast] -to [get_pins {sd_miso_syn_*.ipad}] 2
set_multicycle_path -hold -end -from [get_clocks sd_fast] -to [get_pins {sd_miso_syn_*.ipad}] 1
set_multicycle_path -setup -from [get_clocks sd_ident] -to [get_pins {sd_miso_syn_*.ipad}] 250
set_multicycle_path -hold -end -from [get_clocks sd_ident] -to [get_pins {sd_miso_syn_*.ipad}] 249

# MOSI changes at SCLK falling. CS is separately registered on falling REF,
# with a complete quiet interval and TX ready/valid guard; it retains ordinary
# setup/hold IO timing and receives no SPI enable MCP. The
# enabled launch lies half a serial period before the capturing rising edge,
# and the next allowed change is half a period after it. With REF20ns this is
# setup-start N=2/250, hold-start 2*N-1=3/499. The actual 7ns card/trace limits
# above remain unchanged. Exact detailed native setup/hold edge witnesses for
# both SD modes and both output ports are mandatory, including negative tests.
set_multicycle_path -setup -start -from [get_clocks board_clk] -through [get_ports {sd_mosi}] -to [get_clocks sd_fast] 2
set_multicycle_path -hold -start -from [get_clocks board_clk] -through [get_ports {sd_mosi}] -to [get_clocks sd_fast] 3
set_multicycle_path -setup -start -from [get_clocks board_clk] -through [get_ports {sd_mosi}] -to [get_clocks sd_ident] 250
set_multicycle_path -hold -start -from [get_clocks board_clk] -through [get_ports {sd_mosi}] -to [get_clocks sd_ident] 499

# UART/status and DDC SCL have no synchronous external receiver. Bound actual
# output flight, without inventing a board_clk capture edge for PIX outputs.
set_max_delay -datapath_only -to [get_ports {uart_txd led* HDMI_DDC_SCL}] 5.000
# Current fixed-mode vendor SDA is open-drain TOFF, data=0, with no live DI
# consumer. The checker must prove this exact mapped PAD shape; its internal
# TS/CE paths retain normal STA. OE propagation/pull-up behavior is a declared
# vendor/electrical boundary pending hardware, not a fictitious 5ns data path.

# Raw reset, buttons and UART have no phase relationship with board_clk.
# Each port's only sequential fanout is its asynchronous assertion/synchronizer
# first stage. Stage-to-stage paths retain ordinary STA.
set_false_path -from [get_ports {rst_n btn_next btn_auto btn_emergency uart_rxd}]
# TMDS pins and SCLK are forwarded/serialized vendor boundaries, not a fictive
# parallel-video capture bus. See io_budget.json for their explicit scope.
