> ⚠️ 本文写于 2026-10-11 仓库收敛之前。文中提到的 `evidence/ab_multiround_*`、`releases/ab_multiround_*`、`top_stage10_framebuffer`、`safevision_loopback.al`、`prepare_board_project.*` 等文件已在收敛中删除（**历史提交全部保留**）；取回方式与收敛清单见 [仓库收敛说明](仓库收敛说明_20261011.md仓库收敛说明_20261011.md)。

# B 链 · 待办与硬件验证清单

> 用途：板子还没到，把"现在就能做"和"板到之后必须做"分开列清楚，避免到货后手忙脚乱。
> 维护：每完成一项打勾，并注明日期与实测数据。
> 关联文档：[../README.md](../README.md)（仓库总览）、[interface_spec.md](interface_spec.md)（接口冻结依据）、[B链-原理讲解-入门版.md](B链-原理讲解-入门版.md)、**[B链-SDRAM接口与PLL时序核查.md](B链-SDRAM接口与PLL时序核查.md)（★ 两条遗留时序项的核查与判定口径）**

> ★ **本文件属于"文档三件套"，改代码后必须同步**：阶段状态、回归断言数、已知未完成项
> 有任何变化，都要回来改这里（触发条件表见 [interface_spec.md](interface_spec.md) 的
> 「文档同步义务」）。开发功能以《赛题一对标学习与开发手册_V2.0.pdf》为准（工作区根目录、
> 不进仓库）；**目录结构以本仓库 [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) 为准**。

---

## 零、当前状态总览

> **2026-10-04 板级报告复核**：用户提供的 `Serial Debug 2026-10-04 205523.txt` 解码为完整 190 Byte，`INIT=01 LOCK=01`、`CFG=0B1 BASE=000000 N=000400`、`RND=00000001/00000001 PAT=0`、`W=R=CAP=0400 BAD=0000`、`TOT=0000000400`、`BAD0=FFFFFFFF:FFFFFF`、`DONE`，字段自洽、该轮无数据错误。**报告只证明一轮 × 1024 个稀疏样本的功能回环，不证明 10 分钟/1 小时 soak**：UART payload 自报 `ROUNDS=1`，不包含墙钟耗时、build ID 或位流 hash；因此“等待约一小时”不能由这份报文单独核实。单轮报告已存入 `evidence/board/` 并登记于 `INDEX.md`。此前 LED `07` 仍解读为 `ST_REPORT`，不是错误码；190 Byte 报告在 115200 8N1 下约 17 ms。ModelSim 10.7 新增真实 115200 场景后，190/190 字节、190 次握手和有界退出均通过（七场景，编译 0 error/0 warning）；这只验证应用层，不代替板级长 soak 或 STA。磁盘旧构建 `safevision_Runs/phy_1/safevision.bit`（20:40:10，SHA-256 `72b9135ef8fcd4c6b8710c7b537feaf2e788431ec07839aaf9efa66469922a8d`）与本次下载的对应关系未知。**若要完成 10 分钟 soak，构建报告需显示 `ROUNDS=019BFCC0`（十进制 27,000,000），再从上电/复位开始运行并持续采集 UART；通过条件为 `RND=019BFCC0/019BFCC0`、`BAD=0000`、`TOT=066FF30000`、无错哨兵及 `DONE`。**

| 项 | 状态 |
|---|---|
| 阶段 1（SPI 地基） | 已完成并仿真通过 |
| 阶段 2（SPI 主机） | 已完成并仿真通过 |
| 阶段 3（SD 初始化 CMD0/CMD8/ACMD41/CMD58） | 已完成并仿真通过 |
| 阶段 4（每态独立超时） | 已完成并仿真通过 |
| 阶段 5（CMD17 单扇区读 + CRC16） | **仿真通过，且上板实测通过**（M-9：512/512 逐字节一致，见 evidence/board 的 M-9-PASS） |
| 阶段 6 首块（FAT32 挂载与 BPB 解析 `fat32_boot_parser`） | 已完成并仿真通过 |
| 阶段 6 第二块（根目录遍历 `fat32_directory_scanner`） | 已完成并仿真通过 |
| 阶段 7 第一块（簇链跟踪 `fat32_cluster_walker`） | 已完成并仿真通过（v1.7 起有专属 TB，此前只随编译） |
| 阶段 7 第二块（字节流 `file_streamer`） | 已完成并仿真通过 |
| 阶段 7 第三块（BMP 头校验 `bmp_parser`） | 已完成并仿真通过 |
| 阶段 6 剩余（编号扫描 + 索引表 `file_index`） | 已完成并仿真通过 |
| 阶段 8（FIFO 水位 / 切分缓冲 / 健康度统计） | 已完成并仿真通过 |
| 阶段 9（SDRAM wrapper `mem_ctrl` + 行为模型） | 已完成并仿真通过（真实 PHY 用官方 IP，见 §三） |
| 阶段 10（帧缓存地址映射 + 帧写入 `frame_writer`） | 已完成并仿真通过 |
| 阶段 11（突发传输策略） | 已完成并仿真通过 |
| 阶段 12（带宽与 FIFO 水位实测计数器） | 已完成并仿真通过 |
| 阶段 13（仲裁器 `memory_arbiter`，含防饥饿） | 已完成并仿真通过 |
| 阶段 14（双缓冲与槽所有权 `frame_buffer_manager`） | 已完成并仿真通过 |
| 阶段 15（帧交换握手 `frame_swap_ctrl` + `frame_swap_cdc`） | 已完成并仿真通过 |
| 阶段 16（错误上报 `error_report`） | 已完成并仿真通过（五类故障注入待整机） |
| **目录树与命名已按本项目结构核对完成** | **已完成**（v1.7 逐项核对收尾：修掉最后 4 处重命名 + 补 2 个头文件与 2 个 CRC 通用件；v1.8 引入队友的目录骨架。见 interface_spec「命名迁移表」）。另修掉"同一个常量在 4 个模块各存一份副本"的结构性问题（改地址现在只改 `rtl/include/pixel_format_defs.vh`） |
| 媒体格式层（`bmp_unpack` BGR→RGB565 / `wav_parser`） | 已完成并仿真通过 |
| 目录骨架与管理文档（`.github/` + `docs/` 子目录 + `evidence/` + `platform/` 等） | **已建立骨架**（v1.8 引入队友的项目管理覆盖包）。只有 README 占位与命名计划，**无功能代码**；落点规则见 [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) |
| 目录自检脚本 `safevision/tools/check_repo.ps1` | 已接入（不需要 ModelSim，输出 `LAYOUT PASS` 才算过） |
| 板级 TD 工程 `platform/anlogic_eg4s20_hx4s20c/project/safevision.al` | **全流程已跑通**（器件 EG4S20BG256；设计文件全为相对路径；`constraint_1` 已挂 `pin.adc` + `timing.sdc`）。阶段 5 那次：**综合 → 布局 → 布线 → 位流一次通过**，Setup WNS **+11.297 ns**、Hold WNS **+0.046 ns**、**违反端点 0**（906 端点 / 3480 路径），50 MHz 约束下报告 Fmax **114.9 MHz**；资源 IO 11/188、LUT 814/19600、REG 434/19600、BRAM/DSP 0。原始报告留证在 [evidence/reports/INDEX.md](../evidence/reports/INDEX.md)（TC-Q-STA）。★ **当前 `TOP_MODULE = top_stage10_framebuffer`**（2026-10-03 切，本行上面的数字是阶段 5 顶层的，不是它的） |
| 板级顶层 `platform/anlogic_eg4s20_hx4s20c/rtl/top_stage5_sector_rd.v`（阶段 5 最小验证） | **已写、仿真通过、且上板跑通**（`tb_top_stage5_sector_rd` 5 项断言；板上 LED = `8` 成功，M-9 通过） |
| 引脚约束 `pin.adc` / 时序约束 `timing.sdc` | **已写并核对**（引脚来源：开发板手册的串口/LED/按键引脚表 + `2_FPGA.pdf` / `6_EX_DEVICE.pdf` + 厂商同器件例程，三处一致；`timing.sdc` 为单一 50 MHz 时钟域第一版）。`uart_txd = D12` **已确认为 FPGA 发送脚**（板载 CH340G，无需外接 USB-TTL） |
| 整机集成（`safevision_core` / `safevision_top`） | 未开始（A 负责） |
| 厂商 IP 落库（阶段 9 前置） | **已落地**（2026-10-02）：`ip/sdram/`（应用级 `sdram.v` + `global_def.v` + 三个安路加密 `sdr_*.enc.v` + `sdram.ipc`）、`ip/pll/`（`sv_system_pll` / `sv_video_*_pll` / `sv_audio_pll`）。**加密件按用户决定随仓库提交**，版权与来源见该目录 `README.md`。★ 例程里有两个同名 `sdram` 模块，本仓库只保留被顶层例化的应用级那个 |
| 板级顶层 `platform/anlogic_eg4s20_hx4s20c/rtl/top_sdram_loopback.v`（阶段 9 第一步 / 手册 7.9） | ★★ **已写、已综合（位流 22:01:24）、且上板通过（2026-10-02）**：报告 `INIT=01 / LOCK=01 / W=1000 R=1000 CAP=1000 BAD=0000 / DONE`（71 Byte，条目 **M-11-PASS**）。★ 无 TB、进不了回归（控制器是加密 IP，不可仿真）—— 上板步骤见 §2.4.2。★ **2026-10-03 PLL 去重后已于去重版位流复测通过**：报文与 M-11 逐字节相同（`INIT=01 LOCK=01 / W=1000 R=1000 CAP=1000 BAD=0000 / DONE`），证据条目 **M-11-PASS-2** |
| **上板实测** | **阶段 1–7 与阶段 9 第一步均已通过**：M-9（512/512 逐字节）、M-10（卷基址/BPB/目录）、**M-6（连读 100 次）**、M-8a（无卡有界退出）、**M-11（SDRAM 回环 `BAD=0000`）**、**★ M-11-PASS-3（SDRAM 全片稀疏扫描，2026-10-04：步长 2049 × 1024 点铺满 2M word，136 Byte 报告逐字节一致、`BAD=0000`）**；另已完成板级 10 分钟及约 60 分钟 soak（2026-10-04），三档测试均 `BAD=0000`。**★ 阶段 10 帧缓存回环已上板验收通过（2026-10-03）**：整帧 307200 像素**逐像素零错**（`WR=RD=04B000`、`BAD=000000`），三个地址斜坡探针全对（`AM=FFFFFFFF`、`C0..C3=1004..1007`、`B0..B3=1035..1038`）；定位过程与 STA 记分见 §2.5。★ **阶段 10 顶层的时序已决定"收手"**（report19 自研组 −0.218 ns / 3 违例端点；它是 bring-up 自测顶层、不是交付顶层 —— 理由见 §2.5 的"决策"，时序债留到整机集成后在 A 的顶层重跑 STA）。待做：M-5（可用 ChipWatcher 复核 SCLK）、**M-7（3 张不同品牌卡）**、**M-8「连读中途拔卡」**、M-10 精确拍数、阶段 11–16 板级项（须等 A 的整机） |

仿真回归：`safevision\tools\run_sim.ps1`，**618 项断言全部 PASS**（24 个 testbench）：

| testbench | 覆盖 | 断言数 |
|---|---|---|
| `tb_sd_sector_reader.sv` | SD 初始化 + CMD17 单扇区读 + 逐字节比对 | 13 |
| `tb_mbr_parser.sv` | **MBR 分区表 / 卷基址**：有效 MBR（起始 8192 小端）/ 无 0x55AA 签名 / 空表项 / 起始 LBA=0 | 7 |
| `tb_sd_initializer.sv` | 慢卡 / v1.x 卡 / 拔卡 / 恢复 | 20 |
| `tb_fat32_boot_parser.sv` | BPB 解析 + 3 个负向分支 | 26 |
| `tb_fat32_directory_scanner.sv` | 跳过规则 + 跨簇 + 判环 + 越界 + 反压 | 57 |
| `tb_fat32_cluster_walker.sv` | 正常跳簇 / EOC 边界（0x0FFFFFF8 与 0x0FFFFFF7）/ 越界 / **跨 FAT 扇区寻址** / 判环 / SD 错透传 / 读超时 / done 单拍 | 33 |
| `tb_file_streamer.sv` | 簇链→字节流 + 跨簇 + 成环 + 越界 + 反压 + 空文件 | 49 |
| `tb_bmp_parser.sv` | BMP 头 5 类校验 + 调色板跳过 + top-down + 反压 | 41 |
| `tb_file_index.sv` | 乱序→升序 / 只留最小 4 幅 / 不足 4 幅 / 非法名 / WAV 配对与串号 | 60 |
| `tb_common_fifo.sv` | skid 反压保持 / FIFO 水位与 almost_full / 最低水位 / underflow / 带宽 / 错误不丢 | 58 |
| `tb_crc.sv` | CRC16 XMODEM 标准向量与 4 级级联等价 / **CRC7 反推 CMD0=0x4A、CMD8=0x43 并与宏对照** | 12 |
| `tb_bmp_unpack.sv` | BMP BGR→RGB565 纯色与邻色 / 行填充 / 双向方向 / 反压 / 像素数不足与超限 | 44 |
| `tb_wav_parser.sv` | WAV 未知块跳过 / 样本打包顺序 / 四类拒收 | 31 |
| `tb_frame_writer.sv` | 一帧写入 + 四个角与中点地址抽查 / 多一个少一个 / slot_valid 时序 / 越界 | 28 |
| `tb_memory_arbiter.sv` | 仲裁最坏场景与防饥饿 / 单次占用上限 / 三类 starvation 计数为 0 | 7 |
| `tb_frame_swap_ctrl.sv` | 帧交换四态 / 两类超时进 SAFE / 原子切换 / CDC mailbox 预稳定 | 23 |
| `tb_top_stage5_sector_rd.sv` | **板级 bring-up 顶层**：自动初始化序列 / CMD17 参数 1000 / 512 Byte 经 UART 逐字节与卡模型一致 / 顶层进成功态 | 5 |
| `tb_top_stage6_fat32_mount.sv` | **阶段 6–7 板级顶层**：★ 卷基址只加一次（FAT32 层的 LBA 0 必须落到卡 LBA = 分区基址）/ MBR 分区表 / BPB 几何 / 目录项（名称·属性·大小）/ UART 纯 ASCII 报告内容（含**字节数、无前导 `0x00`、每行 CRLF** 三条 Task-1 回归）/ **连读汇总 `RPT=`**（健康卡 `OK=total BAD=0`）/ **拔卡场景**（有限时间内进 `ST_ERR`、末行 `ERR=02`、LED=错误主码低 4 位）/ 顶层进成功态 | 26 |
| `tb_framebuffer_loopback_core.sv` | **阶段 10 帧缓存回环核心**：整帧 640×480 写 → 整帧读回 → 逐像素零错（LFSR 覆盖全 16 位）/ 抽样 CRC / `slot_valid` / **定长 208 Byte 报告逐字节** / **地址斜坡探针：写值 = 字地址（36 word）** / **探针段内写地址严格连续且两段基址 = 0x1000 / 0x1035** | 11 |
| `tb_sdram_app_adapter.sv` | **板级突发桥适配器**（含 TB 内建的"厂商 app 口模型"）：写 32 连续字 → 读 32 连续字（**跨两次预取**）逐字相等 / **写突发与读突发期间地址必须每拍 +1**（旧版适配器过不了）/ 非 16 对齐基址写 4 读 4 / **缓冲没排空时跳变地址（D7）** / 等 ready、等数据零超时 | 7 |
| `tb_sdr_pat_gen.sv` | **SDRAM 测试图案生成器**（`rtl/memory/sdr_pat_gen.v`，从不可仿真的 SDRAM 顶层里抽出来）：稀疏扫描（步长 2049）1024 点**两两不同** / 连续扫描 1024 点两两不同 / 稀疏扫描时 **4 个字节各自都取到 ≥2 个值** / **21 位地址每一位单独翻转都改图案（无死位）** / mode 0 的 5 个已知值 / 地址 0 图案非 0（mode 0/1/2）/ **反向对照：旧公式在稀疏扫描下只有 2 种图案（证明判据抓得到）** / **mode 1（LFSR）也是单射** / **mode 2/3/4/5 的 8 个已知值**（walking-1 / walking-0 / 全0全1 / 相邻位交替） | 22 |
| `tb_top_sdram_loopback.sv` | **板级 SDRAM 回环顶层（带桩仿真）** —— 用 `models/vendor_ip_stub.sv`（理想存储器）顶掉两个编译不了的单元后，把该顶层**第一次拉进回归**：自建 125 MHz 采样 UART 8N1 接收模型；**阶段 1**（`ROUNDS=3` 三轮全过）：报告**恰好 190 Byte** / **逐字节一致**（含 `RND=00000003/00000003 PAT=2` —— 证明 **soak 轮次与图案模式轮换真的生效**）/ `led=8`；**阶段 2**（在 `0x2805` 注入 1 bit 错）：**只跑 1 轮就出报告**（fail-fast）/ `BAD=0001` / **`BAD0=00000001:002805 E=88002805 A=88002804`**（轮次:地址 精确定位）/ `led=3`。★ **只验我们自己的逻辑**（状态机 / soak / 报告 / 地址 / 图案），**不验 SDRAM 协议与数据完整性**（桩是理想存储器，`BAD=0000` 是构造保证的） | 8 |
| `tb_ab_storage_contract.sv` | **A↔B 存储侧接口的契约守门**（依据 `docs/B链-整机集成-存储侧接线表.md`）：`rd_len` 恒为契约值 64 / `rd_ack` 单拍 / 每突发 `rd_data_valid` 计数 == `rd_len` / `data_valid` 只在 `busy` 期间 / 突发内 `mem_addr` 每次 **+4**（字节地址）/ 突发数不多不少；**★ CDC 往返"恰好一次"**（5 次换帧 ⇒ A 侧恰好 5 次 req、5 次 ack、B 侧 5 次提交、`swap_req` 5 次翻转；两个 evt 单拍）；**★ 无效 CRC 不提交不 ACK**。★ 补现有 TB 的真空：`tb_frame_swap_ctrl` 里 `wr_crc` 恒为 1，CRC 分支从没跑过。★ **本机可跑**（ModelSim）；A 的端到端 TB 在 XSim 上、本机没装 Vivado ⇒ 两者互补 | 16 |
| `tb_b_frame_memory.sv` | ★ **B 链帧缓存内容集成测试**（把阶段 8 + 10 + 11 + 13 串起来）：TB 生成**真 BMP 字节流**（54 B 头 + 640×480×24bit，自底向上）→ `bmp_parser` → `bmp_unpack`（BGR→RGB565 + 翻转）→ `frame_writer`（2 像素/word + CRC）→ `memory_arbiter` 写通道 → 真存真取存储模型 → **`memory_arbiter` 读通道**（A 的显示核心就是从这读的）→ 按 A 的读契约读回并**逐字比对**。断言：BMP 头 640×480 校验 / 整帧 307200 像素写完 / CRC 通过 / `slot_valid` 置位 / **★ 153600 个 word 逐字 0 错（`wok=153600 wbad=0`）** / 读突发 2400 次 ack / `rd_ack` 单拍 / `rd_data_valid` 只在 `rd_busy` 期间。★ 补真空：`bmp_unpack` 的 TB 只看像素流、`frame_writer` 的 TB 用合成图案，**没人验过"真 BMP → 帧缓存内容"** | 14 |
| **合计** | | **618** |

> v1.7 的 4 处拆分类改动（`tb_frame_swap`→2 个、`tb_media`→2 个）**只搬位置、不改断言**，
> 拆分前后断言数逐项守恒（30→7+23，75→44+31）。

---

## 一、现在就能做（不需要板子）

### 1.1 先把器材备齐

- [ ] **TF 卡**：建议准备 **≥2 张不同品牌**（金士顿 / 闪迪 / 杂牌各一），容量 4–32 GB。
      理由：SD 卡兼容性是现场最容易翻车的点，手册也要求"至少两台带声显示设备"这种兼容性留证思路。
- [ ] **读卡器**（能插电脑，用于写测试素材 + 事后比对）
- [ ] **HDMI 线 + 带喇叭的显示器/电视**（B04 要用；阶段 5 还用不到，但迟早要买，越早确认越好）
- [ ] ~~**USB 转串口模块**（CH340 / CP2102 均可）~~ **不需要了**：板上自带 USB-UART（CH340G，位号 U41），
      插一根 USB 线即可（见 §2.2「上板步骤」）。若手边已有外接模块，也可以留着当备用。
- [ ] **杜邦线**若干（板载 SD 卡座若已焊好可省）

### 1.2 TF 卡测试素材准备

- [ ] 把 TF 卡格式化成 **FAT32**（不要 exFAT，不要 NTFS）
- [ ] 用 `7_lab_ex_2026_nosoft\example\lab_ex4_tf\doc\convert\convert_images_to_bmp.py`
      把几张图转成 **640×480、24bit、非压缩 BMP**
- [ ] 准备 4 张 + 1 张故意做坏的图（比如把 BMP 头改几个字节），用于验证"坏图跳过不中断扫描"
- [x] **电脑侧参考扇区已读出并保存**（2026-10-02 完成）：`evidence/board/lba8192_pc_20261002.bin`
      （512 B，SHA-256 `E4704165…C426EEE`）。
      ★ **原计划的 LBA 1000 要换掉**：实测这张 TF 卡的分区从**物理扇区 8192**（4 MB）开始，
      所以 **LBA 1000 落在"MBR 之后、分区之前"的空隙里，读出来是 512 个 0x00** ——
      两边都全零的话"逐字节比对"几乎证明不了数据通路（数据通路坏成常数 0 也会"通过"）。
      因此改用 **LBA 8192 = 分区首扇区 = FAT32 引导扇区（DBR）**：内容非零且可识别
      （开头 `eb 58 90 "MSDOS5.0"`、第 11–12 字节 `00 02` = 512 B/扇区、结尾 `55 aa`）。
      `top_stage5_sector_rd.v` 的 `TARGET_LBA` 默认值已相应改为 `32'd8192`。
      ★ **读法（重要）**：Windows 的**卷句柄偏移是从分区开头算的**，所以物理 LBA 8192 正好
      等于**卷 `G:` 的偏移 0**，不需要管理员权限；反过来，用 `\\.\G:` 偏移 512000 读到的
      **不是** LBA 1000（那是分区内的另一个位置）。若要按原计划读物理 LBA 1000，得用
      HxD「打开物理磁盘」或管理员权限，但因为预计全 0，不作为主基准。

### 1.3 做引脚规划（查原理图，不写代码）

**2026-10-02 已完成**。引脚逐个核对，来源按权威性排序：
① **开发板手册**《HX4S20开发板手册-HDL版2410.pdf》的官方引脚表（串口表 `RXD=F12`/`TXD=D12`、
独立 LED 表 `LED1..4 = A4/A3/C10/B12`、独立按键表 `KEY1=A2`）；
② 原理图 `2_FPGA.pdf`（引脚号 ↔ 网络名）、`6_EX_DEVICE.pdf`（SD 卡座 / LED / 按键页）；
③ 厂商同器件（EG4S20BG256）例程 `7_lab_ex_2026_nosoft/example/lab_ex4_tf` 的 `pin.adc`。
三者对 `clk` / `sd_*` 完全一致。结果已写入
`safevision/platform/anlogic_eg4s20_hx4s20c/constraints/pin.adc`：

| 端口 | FPGA 引脚 | 原理图网络名 | 依据 | 说明 |
|---|---|---|---|---|
| `clk` | **R7** | `FPGA_GCLK` | `2_FPGA.pdf` | 板载 50 MHz 晶振；bring-up 不接 PLL |
| `rst_n` | **A2** | `KEY_1` | `2_FPGA.pdf` + `6_EX_DEVICE.pdf` | 独立按键，低有效；板上已有 10K 上拉，约束里再加内部 PULLUP |
| `sd_dclk` | **A14** | `FPGA_SD_CLK` | 两张图一致 | SPI SCLK |
| `sd_mosi` | **A13** | `FPGA_SD_CMD` | 两张图一致 | SPI MOSI |
| `sd_miso` | **B14** | `FPGA_SD_D0` | 两张图一致 | SPI MISO；**外部上拉情况未在可读的原理图文本中确认**，暂按厂商例程取 `PULLTYPE = NONE` |
| `sd_ncs` | **A12** | `FPGA_SD_D3` | 两张图一致 | CD/DAT3 当 SPI 片选（低有效） |
| `led[3:0]` | **A4 / A3 / C10 / B12** | `LED0`…`LED3` | `2_FPGA.pdf` + `6_EX_DEVICE.pdf` | 显示顶层状态码 |
| `uart_txd` | **D12**（已确认） | `TXD` | 开发板手册串口引脚表 + 图2-10 CH340G 原理图 | ★ **已确认是 FPGA 的发送脚**：板载 USB-UART（CH340G，位号 U41），手册串口引脚表给出 `RXD=F12` / `TXD=D12`；图2-10 显示 CH340G 的 pin2（芯片 TXD）接网络 `RXD`、pin3（芯片 RXD）接网络 `TXD`，**两线交叉**→网络名按 FPGA 视角命名，故 `TXD`(D12) 是 FPGA 输出、驱动 CH340 的输入，**不存在双向争用**。上板只需插 USB 线，开 COM 口 115200 8N1，**不需要外接 USB-TTL 模块** |

**为什么现在做**：引脚资源紧张（BG256 封装，最多 193 个用户 IO），事后硬塞容易冲突。
表已填好，`pin.adc` 是照抄结果。

### 1.4 复习手册的过关自测（建议逐条打勾）

这几条是你自己判断"我真的会了没有"的标准，别跳：

- [ ] 阶段 1：能默写 `sreg <= {sreg[6:0], miso_d}`，说清为什么 8 拍后先到的比特在 bit7
- [ ] 阶段 2：能画出 `spi_master` 状态图，说出每一位在哪个沿被采样
- [ ] 阶段 3：能默画初始化流程，解释 CMD0 / ACMD41 / CMD17 各自为什么不可省
- [ ] 阶段 4：能说出为什么"每个等待态要独立超时出口"，而不是全模块共用一个计数器
- [ ] 阶段 5：能解释"数据令牌 0xFE"和"CRC 的 2 个字节"分别在哪一步，漏了会怎样

### 1.5 和队友对齐（趁没板子，先把接口吵清楚）

- [ ] 把 [interface_spec.md](interface_spec.md) 发给 A、C 各读一遍，重点看 §3.1（SD 总线）、§4（A/B 边界）、§5（地址表）、§6（错误码）
- [ ] 确认 A 的像素 FIFO 选 **FWFT**（决策 D-2）没有异议
- [ ] 确认 C 的 UART 命令/日志要不要复用我们的 `uart_tx`（目前只有发送，收要另加）
- [ ] 一起定掉这几个待确认项（越早越好，改起来越便宜）：
      - O-1 `bmp_unpack` 的 RGB565 转换是**舍入**还是**截断**
      - O-3 `mem_arbiter` 突发长度（建议 16 或 32 word）
      - O-7 音频链路的 `track_id` 编号规则（SV0001.BMP ↔ SV0001.WAV）

---

## 二、板子到了之后必须做

### 2.1 工具链打通（第一天就会卡住的地方）

- [ ] 按 `1_安路开发工具和常用软件\必须看！！重要！安装前必看！\安路TD开发工具软件安装教程.docx` 装 TD
- [ ] 装 license（`Anlogic.lic`），确认 TD 能识别 EG4S20BG256
- [ ] **驱动签名问题**：Win10/11 要按 `Win10、Win11解决驱动签名问题.pdf` 处理，
      否则下载器认不到 FPGA，会白白浪费半天
- [ ] 下载器能识别到器件（这一步过了再往下走）

### 2.2 建第一块可下载的工程（阶段 5 最小验证）

- [x] **工程已建好并配好第一版**：`safevision/platform/anlogic_eg4s20_hx4s20c/project/safevision.al`
      （TD 6.2，器件 **EG4S20BG256**，`IncludeDir = ../../../rtl/include`）。
      35 条设计文件已加入（含板级顶层与 `reset_sync.v`），**全部是相对路径**（`../../../rtl/...`），
      队友 clone 后直接可用，不需要重新添加文件；`TOP_MODULE = top_stage5_sector_rd`，
      `constraint_1` 已挂 `pin.adc` + `timing.sdc`。
- [x] ★ **确认 TOP_MODULE 指向板级顶层**（2026-10-02 已在 `.al` 里写入）。工程刚建时顶层默认落在 `crc7` 上，
      TD 做依赖分析时把其余 32 个模块全标了 `AutoExcluded`——**这时候点综合只会综合出一个 8 行的 CRC 模块**。
      **仍需在 TD GUI 里点一次依赖分析/自动包含，确认 `spi_master` / `sd_initializer` / `sd_sector_reader` /
      `uart_tx` / `crc7` / `crc16_ccitt` / `reset_sync` 都没有被标成 `AutoExcluded`**。
      → **2026-10-02 已核对**：`safevision_Runs/syn_1/run.log` 里 `elaborate -top top_stage5_sector_rd`
      依次 elaborate 了 `top_stage5_sector_rd` / `reset_sync` / `sd_initializer` / `sd_sector_reader` /
      `crc16_ccitt` / `spi_master(CLK_FREQ=50000000)` / `uart_tx(CLK_FREQ=50000000)`，闭包完整，
      **没有被误排除**（`.al` 里 `spi_master.v` 仍留着 `AutoExcluded` 标记，但 TD 实际 elaborate 了它，
      标记与实际不一致属 TD 记账问题，不影响综合；想让它一致就再点一次全量依赖分析）。
      唯一需要 `crc7.v` 的地方是 `tb_crc`，bring-up 顶层用不到它，被排除是对的。
- [x] **把约束文件加进 FileSet `constraint_1`（ConstrainFiles）**：`pin.adc` + `timing.sdc`（2026-10-02 已在 `.al` 里登记）。
      源文件放 `safevision/platform/anlogic_eg4s20_hx4s20c/constraints/`。加进去之前，
      综合/布线是不带任何引脚与时序约束的。
- [x] **综合 + 布局布线，看报告**（2026-10-02 完成）：时序是否收敛、有无多驱动/未约束端口警告。
      → **时序收敛**：Setup WNS **+11.297 ns** / Hold WNS **+0.046 ns**，**违反端点 0**（906 端点 / 3480 路径），
      50 MHz 约束下报告 **Fmax 114.9 MHz**；资源 IO 11/188、LUT 814/19600、REG 434/19600、BRAM/DSP 0。
      → **无多驱动报错**（首轮的 `HDL-8007` 已随修复消失，`syn_1/run.log` 里再无 `black box`）；
      未约束端口只有**故意留空的 I/O 路径**（`sd_dclk`/`sd_mosi`/`sd_ncs`/`uart_txd`/`sd_miso`，STA 覆盖率 99.53%）。
      → **位流 `safevision.bit` 已生成**。原始报告（STA 原文、布线/布局 QoR、综合日志、资源）已复制到
      `evidence/reports/`，索引见 [evidence/reports/INDEX.md](../evidence/reports/INDEX.md)（条目 TC-Q-STA）。
      → **注意**：Hold（removal）余量只有 **0.046 ns**，为正但很薄，来源是 `reset_sync` 输出的复位树；
      以后在复位域里加寄存器或提频要重测。

#### 上板步骤（位流已就绪，2026-10-02）

1. 插好 TF 卡。参考值**已经读好了**：`evidence/board/lba8192_pc_20261002.bin`
   （物理 **LBA 8192** = 卷 `G:` 偏移 0 = FAT32 引导扇区，512 B，SHA-256 `E4704165…C426EEE`）。
2. 下载器接好、TD 能识别到器件（§2.1）。
3. **先重新综合**（`TARGET_LBA` 默认值刚从 `1000` 改成 `8192`，现有的
   `safevision_Runs/best_result/safevision.bit` 还是旧值那次构建的产物，不能直接用）：
   syn_1 → phy_1 → 生成位流，然后在 TD 里下载。
4. **先看板上 4 个 LED**（`led[3:0]` 的状态码，按 A4/A3/C10/B12 = LED1..LED4）：
   `1` 上电等待 → `2` 发初始化 → `3` 等 `init_done` → `4` 发读请求 → `5` 传输中 → `8` 成功。
   其它值＝失败，显示的是**错误主码低 4 位**，排查见 §2.6 第 12 条。
5. **插 USB 线 → 这里最容易卡住**：板上有**两个** USB 口 —— 下载位流用的是 **USB-JTAG**（AL-LINK），
   收数据要用**另一个标着 `USB-UART` 的 Type-C 口**（板载 CH340G）。**两个口都要插线**，
   而且顺序有讲究：先把 USB-UART 线插好、确认 COM 口出现，再（必要时）重新下载位流，
   最后才跑采集脚本 + 按复位键（插拔线可能让 JTAG 下载的位流掉电丢失）。
   怎么确认是哪个口：电脑上应该多出一个 `USB-SERIAL CH340 (COMx)`：
   ```powershell
   Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match 'CH340|USB-SERIAL' } | Select-Object Name, Status
   ```
   **只看到一堆"蓝牙链接上的标准串行 (COMx)"就说明 UART 那根线还没插**（蓝牙串口不是板子）。
   没出现 CH340 → 装 CH340 驱动（厂家包里有）；带黄色感叹号 → 按 `Win10、Win11解决驱动签名问题.pdf` 处理。
6. **采集 512 字节：用现成脚本 `safevision/verification/board/capture_uart_512.ps1`**
   ```powershell
   powershell -ExecutionPolicy Bypass -File .\safevision\verification\board\capture_uart_512.ps1 -Port COM5
   ```
   它会：列端口 → 打开 **115200 8N1 无流控** → 清掉残留字节 → 提示你按复位键 →
   收满 512 字节 → 存成**原始二进制**（默认 `evidence/board/uart_capture_<时间戳>.bin`）→
   与参考值逐字节比对，全对打印 `PASS` 并返回 0。
   ★ **顺序很重要**：512 字节只在**复位后**发一次、约 45 ms 就发完（115200）。LED 停在 `8`
   就说明那一轮早就结束了。所以**先让脚本开始等，再按复位键**（KEY_1 = A2）。
   ★ **不要用"串口助手 + 文本模式另存"**：那会把字节变成文本，且**不可逆**。
   2026-10-02 真实踩坑：Serial Debug 存成 `.txt` 后，凡是 `≥0x80` 的字节全被替换成
   **`EF BF BD`**（U+FFFD 的 UTF-8 编码），512 字节变成 **740 字节**，高位字节**再也无法还原**。
   要么用本脚本，要么在工具里选 **HEX / 二进制导出**。
7. 与 `evidence/board/lba8192_pc_20261002.bin` **逐字节比对**（512 B，SHA-256 `E4704165…C426EEE`），
   一个字节都不能差（M-9 = 阶段 5 验收）。脚本会自动做这件事；第一眼也可以自己认：
   开头 `eb 58 90` + `MSDOS5.0` 文本，结尾 `55 aa`。
8. 想再跑一轮：**按复位键**（KEY_1 = A2）。本顶层跑一轮就停在成功/失败态，不会循环。

#### LED 状态码速查（★ 高电平点亮：引脚高 = 灯亮，见原理图「4 bit LED」= 引脚→1K→LED 阳极→GND）

| LED4 LED3 LED2 LED1 | 码 | 含义 |
|---|---|---|
| **亮 . . .** | `1000` = 8 | **成功**（初始化 → 读扇区 → 512 Byte 经 UART 发完，CRC16 也对上） |
| . 亮 . 亮 | `0101` = 5 | 传输中（512 Byte 正在发） |
| . 亮 . . | `0100` = 4 | 已发读请求 |
| . . 亮 亮 | `0011` = 3 | 等 `init_done` |
| . . 亮 . | `0010` = 2 | 发初始化请求 |
| . . . 亮 | `0001` = 1 | 上电等待 |
| 其它 | — | 失败，显示**错误主码低 4 位**：`1`=SD 初始化失败、`2`=读超时/CRC 错、`3`=媒体非法、`7`=WAV |

> `1`/`2`/`3`/`4`/`5` 都是**低位**亮（LED1~LED3 那侧），只有 `8` 是**最高位**亮（**单独 LED4**）。
> 所以"只有 LED4 亮"就是成功。（位序：`led[3]`→LED4，`led[2]`→LED3，`led[1]`→LED2，`led[0]`→LED1。）

> UART 一个字节都没收到时，先看 LED 有没有到 `8`：到了 `8` 说明 SD 那一侧已经没问题，
> 问题在串口侧（选错 COM 口 / 被别的程序占用 / 波特率不是 115200 8N1）。

> 路径按本项目结构（[PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md)）：头文件在 `rtl/include/`，
> SPI/SD/FAT 在 `rtl/storage/`；**板级顶层、约束、IP、TD 工程统一归
> `safevision/platform/anlogic_eg4s20_hx4s20c/`**（其下 `rtl/` / `constraints/` / `ip/` / `project/`）。
> 只有**不带引脚的可移植 core** 才放 `rtl/top/`。
> 旧文档里的 `rtl/sd/`、`rtl/common/safevision_defs.vh`、`rtl/top/top_stage5_sector_rd.v`
> 都是引入新结构之前的路径，**已作废**。
>
> ★ 工程文件（`.al`）是**源文件**、必须版本管理：`.gitignore` 早先误把 `*.al` 当生成物忽略，
> 会让整个工程文件静默进不了仓库，现已修正。TD 的运行期垃圾（`*.lock.f`、`log/`、`td_*.logw`）
> 已单独忽略。

### 2.3 还没写的东西（板到之前最好补上）

- [x] **板级顶层** `safevision/platform/anlogic_eg4s20_hx4s20c/rtl/top_stage5_sector_rd.v`
      ——阶段 5 最小验证专用（**2026-10-02 已写**），功能：
      - 上电延时 → 拉高 `init_start` → 等 `init_done`
      - `init_done` 后自动发起一次 `rd_en`，`rd_addr = TARGET_LBA`（默认 `32'd8192` = 分区首扇区/FAT32 DBR）
      - 把 512 字节按顺序灌进 `uart_tx`（115200）
      - 状态码输出到 LED（`led[3:0]`：1/2/3/4/5/8，失败显示错误主码低 4 位）
      > 它直接接引脚、不属产品链，所以放 `platform/.../rtl/`（这里才是板级层）。
      > 产品顶层是 A 侧的 `platform/.../rtl/safevision_top.v`；不带引脚的可移植 core
      > 才是 `rtl/top/safevision_core.v`。
      > ★ 它**不接 PLL**，全部逻辑跑板载 50 MHz（bring-up 先排除 IP 变量）；取舍见
      > [interface_spec.md](interface_spec.md) §3.7。
- [x] 写完后在仿真里先跑通（把 UART 输出接到一个 UART 接收模型，确认 512 字节顺序正确）
      ——**2026-10-02 已做**：`tb_top_stage5_sector_rd.sv`（T1 完整命令序列 / T2 CMD17 参数 1000 /
      T3 512 Byte 经 UART 逐字节与卡模型一致 / T4 顶层进成功态），5 项断言全通过。

### 2.4 必做的实测项（每一项都要回填到 [interface_spec.md](interface_spec.md)）

| 编号 | 测什么 | 怎么测 | 回填到 |
|---|---|---|---|
| M-1 | **正常路径最大耗时** | 在 `M_RESP` 等待态埋计数器，用 ChipWatcher 抓若干次操作的最大值，× 裕量系数 | `safevision_defs.vh` 的 `SD_TO_RESP`、O-4 |
| M-2 | 数据令牌等待耗时 | 同上，抓 `S_TOKEN` 状态的计数值 | `SD_TO_DATA`、O-4 |
| M-3 | ACMD41 轮询总时长 | 抓从第一次 ACMD41 到 ready 的拍数（不同品牌卡差异很大） | `SD_TO_ACMD41`、O-4 |
| M-4 | 上电到 `init_done` 的时间 | 示波器或 LED 翻转计时 | 启动速度留证（E04） |
| M-5 | 实际 SCLK 频率 | 示波器量 `sd_dclk`。★ 注意 bring-up 版跑 50 MHz（不接 PLL），所以**初始化段应为 200 kHz、数据段 12.5 MHz**（= `safevision_defs.vh` 里按 100 MHz 推导的 400 kHz / 25 MHz 的**一半**；`SD_DIV_INIT=124` / `SD_DIV_FAST=1`）。整机接 PLL 后再按 400 kHz / 25 MHz 复核。★ **没有示波器也能间接确认晶振频率**：`uart_tx` 的分频是按 50 MHz 算的（`DIV = 50M/115200 = 434`），本次 512 字节在电脑侧按 115200 8N1 **完整无误地收到**（M-9 通过），说明实际时钟频率落在 **±2% 内就是 50 MHz**（否则字节会错位）。`sd_dclk` 的精确频率建议以后用 TD 的 ChipWatcher 抓 `div_cnt`/`sclk_r` 复核，不必强求示波器 | 接口文档备注 |
| M-6 | **连读 100 次** | ★ 顶层已内置**连读阶段**（`RPT_N`，默认 100）：挂载 + 扫目录后自动对同一 LBA（根目录扇区）连读 100 次，每次由 `sd_sector_reader` 的 CRC16 判好坏，报告出一行 `RPT=0064 OK=0064 BAD=0000`。步骤见 §2.4.1 | 手册 7.5 过关标准；证据回填 `evidence/board/` |
| M-7 | **多卡兼容** | 至少 3 张不同品牌/容量的卡各跑一轮，电脑侧先独立解析每张卡的分区表与 DBR 作基准；报告里的**几何行本就应逐卡不同**——"三张卡报告一模一样"反而是失败。步骤见 §2.4.1 | 兼容性留证 |
| M-8 | 拔卡 / 坏卡行为 | 运行中拔卡：LED 显示错误主码低 4 位（应为 `2`），报告末行 `ERR=02`，且**有限时间内**停住不挂死；按复位键重插后能重跑。★ 仿真已在 TB 里覆盖（连读中拔卡 → 进 `ST_ERR`、`ERR=02`、`RPT BAD=100`）。步骤见 §2.4.1 | 手册 7.4 过关标准 |
| M-9 | 单扇区读 + 电脑侧比对 | ★★ **通过（2026-10-02）**：工具改用 **HEX 文本导出**（无 `EF BF BD`），解码后 512 字节与 `evidence/board/lba8192_pc_20261002.bin` **SHA-256 完全相同**（`e470416567d512c0…`），非零字节 372 个也一致。证据见 `evidence/board/INDEX.md` 条目 **M-9-PASS** | 阶段 5 验收 ✅ |

> **M-3 特别提醒**：不同品牌卡的 ACMD41 轮询时长差异可达几十倍，这也是为什么
> 现在的超时值只是"推导 + 裕量"，必须实测后才敢冻结。

### 2.4.1 M-6 / M-7 / M-8 上板操作步骤（连读 / 多卡 / 拔卡）

前提：位流用的是 `top_stage6_fat32_mount`（TD 工程 `TOP_MODULE` 已指向它），串口按
§2.2 第 5–6 步接好（板载 USB-UART，**115200 8N1**）；采集用
`safevision/verification/board/capture_uart_512.ps1`，或串口工具里选 **HEX / 二进制导出**
（**不要用文本模式**，见 §2.6 第 14 条）。健康卡整份报告固定 **476 Byte**
（`183 + 5×52 + 27 + 6`），末行 `DONE`。

**M-6（同一 LBA 连读 100 次）**

1. 插卡 → 重新综合下载 → 按复位键（KEY_1 = A2）。
2. 收整份报告，等 `DONE`。看最后两行：
   - 健康：`RPT=0064 OK=0064 BAD=0000` + `DONE`。`OK == total` ⇒ 100 次连读**每一次**
     的 CRC16 都通过。
   - 有 `BAD != 0`（末行会变成 `ERR=02`）⇒ 出现了偶发读错，按 §2.6 第 4–6 条查。
3. 留证：原始报告存 `evidence/board/`，在 `INDEX.md` 记一条（`RPT=` 行值 + SHA-256 +
   板上 LED 码 + 日期）。
4. 结论口径（手册 7.5）：**"同一 LBA 连续 100 次 CMD17，CRC16 全部通过，OK=100 BAD=0"**。

**M-7（≥3 张不同品牌的卡）**

1. 准备 ≥3 张卡（如金士顿 / 闪迪 / 杂牌各一），**都格式化成 FAT32**，每张都放 4–5 个
   `SV000x.BMP`（否则 `ENT=` 会不同——那也要记录，但先分清是"卡不同"还是"内容不同"）。
2. ★ **每张卡先在电脑侧独立解析一遍**：`Get-Partition` 看分区起始扇区，再把该物理扇区的
   512 Byte 存成参考二进制，据此算出这一张卡的
   `BASE / SECS / BPS / SPC / NFAT / FATLBA / DATALBA / ROOTLBA / TOTSEC / TOTCLUS` 基准。
3. 逐卡：插卡 → 复位 → 收 476 Byte 报告 → 与**该卡自己的**电脑侧基准逐字段对账。
4. ★ **重点**：几何行**本来就应当逐卡不同**（分区起始 / 簇大小 / FAT 大小都不一样）。
   "三张卡报告一模一样"反而说明读的是旧值或路径被写死了，是**失败**。跨卡唯一应相同的，
   是格式（长度 / 行数 / CRLF 行尾）与末行的 `RPT OK=total BAD=0` / `DONE`。
5. 留证：每张卡一份报告 + 对应电脑侧基准，各自在 `INDEX.md` 记一条（注明品牌 / 容量）。

**M-8（拔卡 / 坏卡）**

1. 先跑一轮正常（M-6）确认健康。
2. **在连读阶段进行中拔卡**（LED 停在 `9` 时拔；也可以直接用一张认不到的坏卡上电）。
   要点是"运行中失去卡"，不是插拔本身。
3. 期望（**有限时间内**，不挂死）——因为 reader 每个等待态都有自己的超时
   （`SD_TO_RESP` / `SD_TO_DATA`），连读的**每一次读独立计时**，顶层还有兜底超时：
   - 报告 `RPT=` 行的 `BAD` 等于拔卡后失败的那几次，末行显示 `ERR=02`；
   - 板上 `led[3:0]` 显示**错误主码低 4 位 = 2**（不是成功态的 `8`）；
   - 不会永远停在某个中间码上。
4. 拔卡后插回，**按复位键**，应能重新完整跑通一轮（回到 `DONE`，LED = `8`）。
5. 留证：把"拔卡那一轮"的报告与 LED 码记进 `INDEX.md`——这是手册 7.4 的过关证据。

### 2.4.2 SDRAM 官方 Demo 回环上板步骤（阶段 9 第一步 / 手册 7.9，2026-10-02）

对应顶层：`platform/anlogic_eg4s20_hx4s20c/rtl/top_sdram_loopback.v`（接口见
[interface_spec.md](interface_spec.md) §3.9）。当前集成版：A `d6f40a6` 的完整 21-bit 图案签名、byte-lane compare pipeline、UART 预取；B 的六模式、soak、四级 BAD0 流水与 190 Byte 报告。

> **仿真边界**：加密 SDRAM 控制器与物理 DQ/AC 时序没有 ModelSim/XSim 兼容模型。B `tb_top_sdram_loopback.sv` + `vendor_ip_stub.sv` 验证 6 模式 soak/fail-fast/BAD0 报告；A `tb_sdram_loopback.sv` 用独立应用侧行为模型验证全 21-bit 签名反解、地址混叠/数据位故障、初始化/读返回超时与 UART。两入口必须分开运行，两个仿真模型不得同库编译。它们都不证明真实控制器协议、刷新/CAS、物理 DQ 或 AC 时序。旧 B 构建的板级报告不自动验收当前集成版。**当前 A/B 集成版 TD Routed STA 已完成**：全局 setup `−6.826 ns / −296.534 ns`（65 个 setup 端点）、hold `+0.054 ns / 0`；自研 C1 报告路径另有 `−0.094 ns`（1 个端点）。故仍不收敛，暂不烧位流；先处理时序/TD 检查告警，再重新布线并用匹配位流上板验收。详细数字与路径见 [核查修正版 §7.2](B链-SDRAM接口与PLL时序核查.md)。

> ★★ **2026-10-02 已通过（条目 M-11-PASS）**。位流 22:01:24 下载后收 **71 Byte**：
> `SV-SDRAM-LOOP` / `INIT=01 LOCK=01` / **`W=1000 R=1000 CAP=1000 BAD=0000`** / `DONE`，
> **与设计值一字不差**。⇒ 阶段 9 的"先证明厂商硬核能用"在实物上完成。
> 下面是**重跑/复现**用的步骤（换参数、重做验证时照走）。
>
> **历史 B soak 配置**（此参数来自合并前版本；集成版已采用 A 的 21-bit 图案签名，报告长度仍为 190 Byte，需重新构建后复测）。
> 该版本默认 `ADDR_SHIFT=11`、`ADDR_LOWSTEP=1`，步长 `2049`，每轮 1024 个样本跨越 2M-word 范围；这是**地址稀疏抽样**，不是逐地址覆盖全容量，也不能单独宣称全部 bank/row/column 已完整遍历。
> `ADDR_SHIFT=0` 且 `ADDR_LOWSTEP=0` 才表示连续步长 1；B soak 旧参数与当前合并源码须按 `CFG`/build 记录区分。
> soak / 6 种模式的具体参数与报告仍见下文；它们的旧版板测不自动验收 A+B 合并版。
> **② 报告扩到 190 Byte**（自描述 + 可定位）：
> ```
> SV-SDRAM-LOOP                                    (15)
> INIT=01 LOCK=01                                  (17)
> CFG=hhx BASE=hhhhhh N=hhhhhh                     (30) ← 步长指数/低位开关 / 基址 / 每轮 word 数
> RND=hhhhhhhh/hhhhhhhh PAT=h                      (29) ← 已跑轮数 / 总轮数 / 本轮图案模式
> W=hhhh R=hhhh CAP=hhhh BAD=hhhh                  (33) ← **本轮**的计数
> TOT=hhhhhhhhhh                                   (16) ← 累计比对字数（40 bit，不重置）
> BAD0=hhhhhhhh:hhhhhh E=hhhhhhhh A=hhhhhhhh       (44) ← 首个错点：轮次 : 地址 / 期望 / 实际
> DONE                                             (6)
> ```
> `BAD0=FFFFFFFF:FFFFFF` 表示无错（地址最大 0x1FFFFF、轮次用 0xFFFFFFFF 当哨兵）。
> **③ soak（`ROUNDS` 参数）**：把「写→等落地→读→等收齐」当一轮，重复 `ROUNDS` 轮，
> **每轮换一种图案模式**（0..5 循环）。★ **出错立即停**（fail fast）—— 报告里的 `RND`
> 就是出错那一轮，不用等 soak 跑完。轮时长**实测 ≈ 22 µs**（2790 拍 @125 MHz，1024 word
> 稀疏扫描）⇒ `ROUNDS ≈ 目标秒数 × 45_000`，**60 分钟 ≈ `ROUNDS = 1.6e8`**
> （32 位参数够用，报告里 8 位 hex 显示）。★ **soak 期间"没有输出"就是好消息**。
> **④ 6 种图案模式**（`sdr_pat_gen.v`，各针对不同失效机理）：`0 ADDR`（地址派生，单射，
> 治地址译码）/ `1 LFSR`（xorshift32，双射，压数据线串扰）/ `2 WALK1`、`3 WALK0`
> （单根数据线为 1/0 在走，治线间粘连）/ `4 ALT`（全 0 全 1 交替，最坏功耗图案）/
> `5 ADJ`（相邻位反向，压相邻线耦合）。
>
> ★ 图案生成从"顶层里的一个 function"抽成了可仿真的 `rtl/memory/sdr_pat_gen.v`
>   （+ `tb_sdr_pat_gen` **22 项**断言）：**旧公式只用了 a[11:4] 与 a[7:0]，在步长 2^11 的
>   稀疏扫描下 1024 个点只有 2 种图案** ⇒ 那个"全片扫描"几乎什么都证明不了。
>   ★ 这类错误**写读自比看不出来**（两边错得一样照样 `BAD=0000`），所以必须由 TB 单独守。
>   ★ TB 还抓出一个真缺陷：**xorshift 的 0 是不动点** ⇒ 原来"用地址异或播种"会让某个地址
>   输出**全 0**（最弱图案、还会掩盖"数据线卡死在 0"）⇒ 改成**加非零常数**播种。

| 步 | 做什么 | 看什么 |
|---|---|---|
| 1 | **A/B 工程源表已合并到 `safevision.al`**：`TOP_MODULE=top_sdram_loopback`；保留 A 的 `video_pipeline` 与图形验证源、B 的阶段 10 源，并登记 `sdr_pat_gen.v`（CompileOrder 50）。当前 XML 路径解析检查：61 个 Verilog 条目全部可达、CompileOrder 1–61 无重复。★ `.al` 是快照，手改后仍须关闭 TD（保存提示选【否】）再重开；后续增加源文件时更新文件表和序号。 | 烧板前运行当前 TD `syn_1/run.log` 确认实际 `elaborate -top top_sdram_loopback` 且 `sdr_pat_gen` / `sdram` / `sv_system_pll` elaborated；不要只依据磁盘 `.al` 或 UI。 |
| 1b | ⚠⚠ **`.al` 只是"上次保存的快照"，跑综合用的是【TD 内存里的工程状态】**（2026-10-02 双向都踩过）：① 改磁盘 `.al` 而 TD 会话是从更早状态打开的 ⇒ `run.log` 里还是旧的 `elaborate -top`，磁盘文件**没被采用**；② 在 GUI 里点"保存工程"会**用内存状态覆盖磁盘 `.al`**（实测丢过 7 条登记）。⇒ **手改 `.al` 之后必须：关掉 TD（提示保存时选【否】）→ 重开**。★ 判断到底综合了哪个顶层，**只信 `safevision_Runs/syn_1/run.log` 里的 `elaborate -top <名字>`，不要信 UI**。★ 另一条：`read_adc` 是**每次 Run 都执行**的，所以改 `pin.adc` **直接重综合即可、不用关 TD**（与 `.al` 不同） | — |
| 2 | **确认 `constraints/pin.adc` 的 `[SD-ONLY]` 四条处于注释状态**（`sd_dclk`/`sd_mosi`/`sd_miso`/`sd_ncs`）。这三个顶层**没有** `sd_*` 端口，而 TD 对"约束里出现顶层不存在的端口"是**报错**：`HDL-1492 Failed to find pin sd_dclk in model top_sdram_loopback` + `USR-8168 ... is not a valid ADC command`，随即 `PRJ-5013 Run syn_1 failed`。★ **`read_adc` 是每次 Run 都执行的命令，改完 `.adc` 直接重综合即可、不用关 TD** | `pin.adc` 里那四行是 `#set_pin_assignment ...` |
| 3 | **重新综合**（这次多了 5 个 IP 文件 + `sv_system_pll` + `derive_clocks`，旧位流不含它们） | `syn_1/run.log` 里必须是 **`elaborate -top top_sdram_loopback`**（不是 stage6！）；`HDL-8007` / `black box` 必须为 0；`sv_system_pll` / `sdram` 要真的 elaborate |
| 4 | 下载位流 | — |
| 5 | 看 `led[3:0]` | `2` 等 SDRAM 初始化 → `3` 写 → `4` 等落地 → `5` 发读 → `6` 等收齐 → `7` 发报告 → **`8` = 成功** |
| 6 | 插 USB，开 COM 口 **115200 8N1**，收 **190 Byte**（★ 报告头是 `SV-SDRAM-LOOP`，不是 `SAFEVISION B STAGE6`） | 用 **HEX / 二进制**导出（★ 别用文本模式，`≥0x80` 会被换成 `EF BF BD`） |
| 7 | 对账（按本次烧录的 `CFG/BASE/N/ROUNDS` 及源码版本核验；下列字段示例是旧 B 稀疏构建） | 核对 `INIT=01 LOCK=01`、`W=R=CAP=N`、`BAD=0000`、`TOT=ROUNDS×N`、`BAD0` 无错哨兵及末行 `DONE`；旧 B 的 190 Byte 报告含 `CFG=0B1 BASE=000000 N=000400` |
| 7b | ★★ **soak 参数 / 历史结果**：旧 B 构建把 `ROUNDS` 设成下表数值后重新综合上板；当前 A+B 集成源码改动了签名/比较/报告预取，必须重新验证，不能沿用旧结果作为本版验收。每轮换一种图案模式（0..5 循环），累计搬运量看 `TOT`；**出错会立即停**，并在 `RND`（第几轮）与 `BAD0`（轮次:地址 期望 实际）给出定位。<br>★ **单轮时长已实测 = 2790 拍 @125 MHz ≈ 22 µs**（本机带桩仿真量的）⇒ `ROUNDS ≈ 目标秒数 × 45_000`：<br>　`~10 秒` → **`32'd450_000`**（★ **建议的第一次烧**：只为确认新报文/soak 循环在实物上正常，10 秒就够）<br>　`~1 分钟` → `32'd2_700_000`　　`~10 分钟` → `32'd27_000_000`　　`~60 分钟` → `32'd161_000_000`（接近手册 M-14 的"连续跑 60 分钟"口径）<br>★ **soak 期间"没有输出"就是好消息**：出错会立刻出报告，所以**没提前收到报文 = 到目前为止全对** | **`ROUNDS=32'd450_000` 的期望报文**（10 秒版）：<br>`CFG=0B1 BASE=000000 N=000400`<br>`RND=0006DDD0/0006DDD0 PAT=0`<br>`W=0400 R=0400 CAP=0400 BAD=0000`<br>`TOT=001B774000`<br>`BAD0=FFFFFFFF:FFFFFF E=00000000 A=00000000`<br>通用判据：`RND=<ROUNDS>/<ROUNDS>`、`TOT = ROUNDS × 1024`、`BAD=0000`、`PAT` = 最后一轮模式 = `ROUNDS mod 6` |
| 8 | 按复位键可重跑（整条序列从 `ST_POWER` 重来） | — |
| 9 | 留证 | 把 **190 Byte** 存 `evidence/board/` 并在 `INDEX.md` 记一条（★ **报告是自描述的**：`CFG`/`BASE`/`N`/`RND`/`PAT` 就是这次烧的参数与进度，不用另外记）；STA 报告按 `evidence/reports/` 规则记 `TC-Q-STA-4` |

> **板级 soak 已实测（2026-10-04；只在本文件保留汇总，全量 ModelSim preflight 控制台日志不入库）**：10 秒（`ROUNDS=450,000`）、10 分钟（`27,000,000`）与约 60 分钟（`161,000,000`）三档均完成；`INIT=LOCK=01`、`W=R=CAP=0400`、`BAD=0000`、`BAD0=FFFFFFFF:FFFFFF`，均正常 `DONE`。10 分钟累计 `TOT=066FF30000`（27,648,000,000 word），约 60 分钟累计 `TOT=2662A90000`（164,864,000,000 word）。每轮仍是固定的 1024 个稀疏地址点，六种模式逐轮轮换；延长时长不等于逐轮遍历全部 2M word。
>
> **同日 STA 复核（TD `report20`，Top=`top_sdram_loopback`，Routed，覆盖率 99.94%）**：自研 `clkc[1]→clkc[1]` 的旧比较长路径已消失，但仍有 1/1919 端点 `SWNS=-0.138 ns`（`Fmax=122.880 MHz`），最差路径经 UART 报告 mux 到发送移位寄存器，故自研组尚未完全收敛；全局 `SWNS=-6.826 ns / STNS=-297.812 ns` 的 SDRAM C1/C2 DQ 接口负余量仍需按厂商时序模型/约束口径继续核查。Soak 零错是板级数据证据，不等同于 STA 通过。UART 报文与 STA 文件未带共同 build ID / 位流哈希，不能仅凭报告声称密码学级构建关联。
>
> **2026-10-04 UART selector 修复续记**：将原 190 Byte 宽选择改为“报告行选择并寄存 → 行内字节选择”，保留字节顺序与 UART ready/valid 节奏。新 Routed postroute C1→C1 setup `+0.113 ns`、`STNS=0`、违例端点 `0/2517`、Fmax `126.791 MHz`；全局 setup 仍 `−6.826 ns / −298.211 ns`，hold `+0.030 ns`。独立索引脚本逐一核对 190/190 字节位置和 UART 发送顺序通过；这不等于 RTL 仿真。本轮专用仿真因本机没有 XSim 2018.3、`MSIM_BIN` 未设置而未启动，未生成位流、未上板。**待办**：在可用仿真器环境重跑 `run_sdram_loopback_sim.ps1`；然后针对当前源码生成位流，由用户烧录跑 10 分钟 soak；收齐匹配构建的 190 Byte 报告并核对后再决定 push。SDRAM DQ 负余量按本次用户范围暂不做 RTL 修改，不能写成全局时序通过。
>
> ★ 换回阶段 5/6 顶层（跑 M-7 多卡 / M-8 拔卡）时，别忘了把 `pin.adc` 那四行行首的 `#` 去掉，
> 否则 `sd_*` 会变成**未约束引脚**（TD 可能自动分配 = 位流静默错误，比报错更难查）。

**失败对照**（LED 显示错误主码低 4 位）：

| LED | 错误码 | 含义 | 先怀疑什么 |
|---|---|---|---|
| `1` | `ERR=01` | SDRAM 初始化一直不完成（`Sdr_init_done` 没来） | 检查 `pll_locked`、高有效 `Rst` 与同步释放、加密件和最终反馈路由；C0 外部端口留空不等于内部反馈断开，不能靠增加虚假业务负载判断。该超时由 LED/内部 `err_code=01` 表示，当前 RTL 不发送 UART 错误行 |
| `2` | `ERR=02` | 读命令发了但返回不齐（`CAP < W`） | 读突发节奏太密（调小 `BURST_N` 或调大 `BURST_GAP`）；或读写没真正错开（调大 `WR_DRAIN_CYC`） |
| `3` | `ERR=03` | 返回数量对但数据不对（`BAD != 0`） | **先看 `BAD0` / `E` / `A`**，定位首错轮次、地址、期望值和实际值；再分辨数据位故障、地址混叠或读返回错位。检查新版 21-bit 签名和对应参数；`ADDR_SHIFT=11` 稀疏模式只覆盖选中样本，不等于全容量逐地址测试。仍需核对 `Clk_sft` 采样相位及物理 SDRAM setup 条件，不能以一次零错板测替代 STA。 |

**★ 两个概念别搞反**：报告里的 `W` 是**我们发出的写使能拍数**、`R` 是**我们发出的读命令数**、
`CAP` 是**控制器返回的有效 word 数**。`W == R == CAP` 只说明"命令都被受理了"，
**数据对不对要看 `BAD`**。三者不等才是"控制器丢了命令"。

### 2.5 存储链的实测项（阶段 8–16，板到后按序补）

> 这些项的共同特点：**仿真里全是"理想值"，只有上板才知道真数**。手册 7.12 明确
> 规定"报告里只接受一种结论形式：用计数器统计一段时间内实际完成搬运的数据量，
> 除以时间得到控制器持续带宽，并同时给出该时段的 FIFO 最低水位"。

| 编号 | 测什么 | 怎么测 | 回填到 |
|---|---|---|---|
| M-10 | **SDRAM 初始化时间** | 上电到 `init_done` 的拍数 | ✅ **定性已通过（2026-10-02）**：`top_sdram_loopback` 报告 `INIT=01` ⇒ 在 16 ms 超时窗（`INIT_TO_CYC = 2_000_000` @125 MHz）内到齐；**精确拍数仍未测**（需 ChipWatcher 抓 `Sdr_init_done`） |
| M-11 | **SDRAM 读写回环** | 官方 Demo 写入并读回，逐字比对；按构建参数分别记录连续/稀疏/soak 配置 | ✅ **历史构建证据**：M-11-PASS（2026-10-02，4096 word 连续，`BAD=0000`）；B 本地扩展版本另完成 stride=2049、1024 点稀疏扫描，以及 10 秒 / 10 分钟 / 约 60 分钟 soak，均零错（汇总见 §2.4.2）。**注意**：这些板测来自 A 最新 `d6f40a6` 之前的 B RTL/190 Byte 报告构建，不自动验收本次合并后的 A 21-bit signature、byte compare 和 UART prefetch。合并版本须重新综合/布线、核对 STA，再至少跑短版板测后才能升级为当前版本验收；地址稀疏点不是全容量逐字测试。 |
| M-12 | **持续带宽（关键）** | `memory_bandwidth_monitor` 的 `rd_bytes_total` / `wr_bytes_total` ÷ 时间；跑 ≥10 分钟 | 手册 7.12 的"有效带宽"结论、O-4 邻近项 |
| M-13 | **FIFO 最低水位** | `fifo_health_monitor.min_level`，与上一条同时段采集 | 手册 7.12 要求成对给出；水位阈值标定 |
| M-14 | **underflow / overflow 计数** | 连续跑 60 分钟，两个计数必须都为 0 | 表 7-4 的验收门槛 |
| M-15 | **仲裁饥饿** | 构造"显示读持续请求"最坏场景，看 `starvation_cnt` 是否为 0、帧写入能否按时完成 | 阶段 13 验收 |
| M-16 | **帧交换超时行为** | 人为不给 `swap_ack`，确认 `swap_error` 拉高、**当前显示块保持不变、画面不黑** | 阶段 15 验收；`TIMEOUT_N` 按最大帧周期加裕量 |
| M-17 | **`active_slot` 只在消隐段变** | ChipWatcher 抓 `active_slot` 与 `frame_start`，确认改变只发生在消隐入口 | 阶段 15 过关自测原话 |
| M-18 | **撕裂检查** | 连续 100 次切换录屏，逐帧看有无横向错位；`tear_count` 必须为 0 | 阶段 14 过关自测 |
| M-19 | **五类故障注入** | 拔卡 / 坏图 / 坏文件系统 / FIFO 人为欠载 / SDRAM 写失败，**均不卡死** | 手册 7.16.2 过关自测 |

> **M-12/M-13 必须成对给出**，只报带宽不报水位等于没测——因为带宽够但水位贴地，
> 说明系统已经在 underflow 边缘，随机一次刷新抖动就会花屏。

### 2.6 上板调试的排查顺序（出问题时按这个顺序找）

1. **SCLK 完全没动静** → 先看 `cs_n` 有没有拉低；再看 `spi_master` 的 `tx_valid/tx_ready` 握手
2. **SCLK 有但读回全 0xFF** → 卡没进 SPI 模式，查 CMD0 是否发出、CRC 字节是否为 0x95
3. **CMD8 之后就没响应了** → 查 CMD8 的 CRC 字节是否为 0x87、参数是否为 0x000001AA
4. **能初始化但读数据全错** → 大概率是位序（MSB first）或 SCLK 相位（应该在上升沿采样）
5. **读出的数据偶发错位** → 查数据令牌 0xFE 之后有没有把 512 字节数满、CRC 的 2 字节有没有吃掉
6. **跑一会儿就卡死** → 查超时计数器有没有在进等待态时清零（手册 7.4 的经典坑）
7. **能读扇区但图片显示错位 / 斜切** → 查帧缓存地址公式：`slot_base + (y*640+x)*2`，最容易漏乘"每像素 2 字节"，或者把行步长写死成图像宽度
8. **画面整体右移或左边有黑边** → 像素 FIFO 的读出模式/预取提前量错了（手册 7.8 的技术纠错：读地址一到不等于 de 有效）
9. **画面偶发花屏、而且是跑一段时间才出现** → 先查 FIFO 最低水位是不是贴地（`fifo_health_monitor.min_level`），再查 SDRAM 刷新是否被省掉
10. **画面上下错位 / 一半旧一半新** → 帧交换没有在垂直消隐期原子切换，或者 `active_slot` 与 `slot_base` 不是同时更新的
11. **帧写入把显示读饿死** → 查仲裁的两条硬约束（单次占用上限、最长等待提升）有没有实现
12. **LED 卡住 / UART 一个字节都收不到** → 先看板上 `led[3:0]` 的状态码：
    `1` 上电等待、`2` 发初始化请求、`3` 等 `init_done`、`4` 发读请求、`5` 传输中、`8` 成功；
    其余值表示失败，显示的是**错误主码低 4 位**。
    - 卡在 `3`：SD 初始化没过 → 按上面第 1–4 条查（SCLK、CMD0 的 CRC=0x95、CMD8 的 CRC=0x87）
    - 到 `8` 但电脑收不到：先确认串口工具选的是板载 USB-UART 的那个 COM 口、**115200 8N1**，
      再看电脑侧有没有别的程序占着该串口；`uart_txd`（D12）已经确认是 FPGA 发送脚（见 §1.3）
13. ★ **TD 综合报 `net 'xxx' is constantly driven from multiple places`（HDL-8007/9007）**
    → 不是引脚问题，是 RTL 里**同一个 `reg` 被两个 `always` 块赋值**。
    **ModelSim 编译和仿真都不报错**（仿真里只是竞争，谁最后写谁赢），所以单元 TB 全绿也可能带着这个错——
    这正是"必须真跑一次 TD 综合"的理由。
    真实案例（2026-10-02）：`sd_initializer.v` / `sd_sector_reader.v` 的 `bdata` 本应只由主状态机驱动，
    但字节引擎的复位分支里多写了一次 `bdata <= 8'hFF`，TD elaborate 直接把该模块降级成黑盒。
    修法：把那个复位赋值收归主状态机（保证一个 `reg` 只有一个驱动源）。
    查法：TD 报的 "found another driver here in 文件(行)" 就是第二个 `always` 块的起始行，两边一起看。
14. ★ **收到的 512 字节里出现一堆 `EF BF BD`，文件比 512 长（例如 740）**
    → **不是 FPGA 的问题，是串口工具"文本模式"保存毁掉了高位字节**。
    `EF BF BD` 是 **U+FFFD（替换字符）的 UTF-8 编码**：工具把字节流当文本解码，凡是不是合法
    UTF-8 的字节（基本就是 `≥0x80` 那些）全被替换成它，**不可逆**。
    判定方法（也是本次的证明方式）：把参考 512 字节按"UTF-8 解码（errors=replace）再编码"
    变换一次，若结果与采集文件**逐字节相同**，就说明 FPGA 发的是对的、纯粹是保存方式的问题。
    修法：**用二进制方式采集**（`safevision/verification/board/capture_uart_512.ps1`），
    或在串口工具里选 HEX / 二进制导出。
    （2026-10-02 真实案例：512 → 740 字节，141 个 `≥0x80` 的字节被替换。）
15. ★ **`top_stage6` 的报告开头多一个 `0x00`（字节数比预期多 1）**
    → 报告头的**声明位宽比实际内容多 1 字节**：`hdr_bits` 曾写成 `[1471:0]`（184 Byte），
    而六段实际只有 `21+42+25+51+34+10 = 183` Byte，Verilog 在 **MSB 侧补零**，
    于是先发出一个 `0x00`、整份报告后移一字节（板上 450 = 1 NUL + 183 + 260 + 6）。
    修法：按**真实字节数**声明（183 → `[1463:0]`），并保留「报告各段字节数逐段相加
    = 声明字节数」的核对注释（v1.13 已修）。
16. ★ **报告每行行尾是 `72 0A`（字母 r + LF）而不是 `0D 0A`**
    → 源码里用了字符串转义 `"...\r\n"`。**ModelSim vlog 10.7 与 TD 6.2 都不把字符串里的
    `\r` 当转义**，二者都把 `"DONE\r\n"` 编成 `44 4F 4E 45 72 0A`。之所以仿真"看起来是对的"，
    是因为旧 TB 也用同一个转义、**两边错得一样**，自洽通过。
    修法：行尾**写显式字节** `8'h0D, 8'h0A`（v1.13 已改，RTL 与 TB 都是显式字节）。
    这条与项目规则 §5 第 11 条是同一类"仿真与综合不一致"。
17. ★ **`RPT=` 行的 `BAD` 不为 0 / 末行是 `ERR=02`**
    → 连读阶段有若干次 CMD17 超时或 CRC16 校验失败。正常卡（刚跑过 M-6）出现这种情况，
    优先按第 4–6 条查（位序 / SCLK 相位 / 数据令牌与 CRC 字节有没有数满、超时计数器
    有没有在进等待态时清零）。**拔卡那一轮**出现 `BAD != 0`（末行 `ERR=02`、LED=`2`）
    是**预期**行为，不是故障——那正是 M-8 要看的证据。

---

### 2.5 阶段 10 帧缓存回环 `top_stage10_framebuffer`（2026-10-03 新增；同日加「地址斜坡探针」）

> 顶层：`platform/anlogic_eg4s20_hx4s20c/rtl/top_stage10_framebuffer.v`；可仿真核心
> `rtl/memory/framebuffer_loopback_core.v`（已在 `tb_framebuffer_loopback_core` 仿真 **11 项全过**）。
> 引脚与 stage9 顶层相同：`clk`/`rst_n`/`uart_txd`/`led[3:0]`，**无 `sd_*`**。
>
> ★★★ **当前状态（2026-10-03 晚，第 4 轮）：阶段 10 帧缓存回环「板上验收通过」。**
> 208 Byte 报文（ID 211030）**全部判据一次通过**：
> ```
> INIT=01
> WR=04B000 CRC=01 SV=01        ← 整帧 307200 像素写完（CRC / slot_valid 都过）
> RD=04B000 BAD=000000          ← ★ 整帧读回逐像素零错
> W0=59C3ACE1 W1=670FB387       ← 帧前 2 个 word 与核心 LFSR 逐步推算一致
> AM=FFFFFFFF AF=FF AV=00000000 ← 探针 A：32 个回读全对（跨两次预取）
> C0=1004 C1=1005 C2=1006 C3=1007   ← 探针 C：非零偏移处全对（写侧正常）
> B0=1035 B1=1036 B2=1037 B3=1038   ← 探针 B：非 16 对齐基址全对
> BF=000000  DONE
> ```
> ⇒ 从"整帧 3/4 像素错"到"**零错**"闭环完成。**唯一未收尾的是时序**（见下）。
> ★ **STA 七版记分（自研组 `clkc[1]→clkc[1]`）**：report13（改前）**+0.030 ns / 0 违例 / 3023 端点**
> → report14（354 B 报告 + 512 回读寄存器）**−1.083 / 475 / 4445**
> → report15（208 B 报告）**−1.562 / 312 / 3691**
> → report16（适配器去加法器 + ready 寄存器化）**−0.992 / 31 / 3709**
> → report17（回读收集改"纯移位"）**−0.386 / 6 / 3676，Fmax 119.246 MHz**
> → report18（报告 mux 改两级 + 块寄存器）**−0.081 / 2 / 3948**
> → **report19（块号改寄存器 `blk_nxt`）−0.218 ns / 3 违例 / 3982 端点**。
> **第 2 刀（report17 → 18）**：把 208 Byte 报告 mux 从"1664 bit 向量 + 变址选取"改成
> **13 块 × 16 Byte 两级 mux + 一块 16 Byte 的块寄存器**（`blk_q`；逐字节等价，TB T8/T9 守住）
> ⇒ 把"大 mux → 跨芯片送 uart_tx"这条长走线**切在中间**；报告通路那 4 条违例**全消失**。
> **第 3 刀（report18 → 19）**：report18 剩的 2 条违例**都是块 mux 自己** ——
> `rpt_idx → 9 位减法器（4 级 ADDER，0.92 ns）→ rpt_dn[5]（**扇出 195**，1.73 ns）→ 块 mux`
> （那个减法器本来只给状态机算 `rpt_idx-1`，却被综合塞进了**块选择端**）。改成**把块号提前一拍
> 存进寄存器 `blk_nxt`**（恒 = `block(rpt_idx-1)`，只在"下一字节跨块"时 -1）⇒ 关键路径变成
> `blk_nxt → 块 mux → blk_q`，减法器退回成**只喂 5 个 bit** 的轻负载路径。
> ★ **这一刀本身成功了**：report19 里块 mux 路径已从 −0.081 变成 **+0.058 ns（过）**。
> ★★ **但 report19 的全局最差换到了别处**：`u_adapter` 的**突发基址 / 读命令计数**通路
> （`rfbase` / `wbase` / `addr[17]` / `rcmd_i`，见 `sdram_app_adapter.v` 44 / 106 / 124 行），
> **−0.218 ns / 数据路径 7.938 ns / net 占 69% / 扇出 51**（2 个端点）；另 1 条
> `ramp_to → ramp_addr[17].ce` **−0.029 ns**（探针地址寄存器的 CE，24 位比较器）。
> ⇒ 自研组现在有 **约 10 条路径挤在 0.25 ns 以内** —— 这是"**已经跑到预算 99%**"的典型形态：
> 修好一条，最差就换到另一条。
>
> ★★ **决策（2026-10-03 深夜）：就此收手，不再为这个顶层做 RTL 微调。** 理由：
>   ① **这个顶层不会交付** —— `top_stage10_framebuffer` 是 B 侧的 **bring-up 自测顶层**
>      （产品顶层是 A 的 `safevision_top`），`framebuffer_loopback_core` 本身也是**自测夹具**
>      而不是产品数据通路；整机集成后布局布线完全不同，在这里继续微调**转移价值很低**。
>   ② 剩下的两条路径都是"**慢逻辑**"：报告序列化（115200 波特率下**每字节隔约 8680 拍**）
>      与适配器突发基址建立 —— 都不是吞吐瓶颈。
>   ③ 收益递减：475 → 31 → 6 → 2 → 3，每轮成本 = 一次 TD + 一次全量回归 + 一轮文档同步。
>
> ★ **时序债怎么还**：**整机集成后在 A 的顶层上重跑 STA**，那时再按实际情况定 ——
>   若报告通路仍是关键路径，**合法的做法是 `set_multicycle_path`（并写明理由：该数据在几千拍内稳定），
>   而不是 `set_false_path` 刷绿**（项目规则 §7 末条）；若适配器通路仍关键，那一条是
>   **要交付的真逻辑**，值得单独优化（它是本仓唯一必须保留到产品的桥）。
>
> ★ **第 2 轮（354 Byte 版报文）探针判决**：
> `RD=04B000 BAD=038400` / `W0=59C3ACE1 W1=670FB387` / **`A0..A3` 对、`A4..AF` 重复回这 4 个值** /
> **`B0..B3=1035..1038` 全对** ⇒ **一次连续读突发里，读地址只推进 4 个字就回绕**；
> `BAD=038400` 恰为帧总 word 数 153600 的**精确 3/4**（每 4 个读回只对 1 个）与探针完全吻合。
> ⇒ 根因 = 厂商 app 口**唯一被实物验证可行**的形态是 M-11（`App_*_en` 连发 + `App_*_addr`
> **每拍自增** + 突发间静默 + 读侧 1:1 收响应），而适配器上一版把**读预取地址推进挂在
> `Sdr_rd_en` 上** ⇒ 已按 M-11 重写读引擎，并补 `tb_sdram_app_adapter.sv` 守住这条约束。
>
> ★ **第 2 轮的 STA 回归（我引入的，已修）**：354 Byte 报告（含 512 个回读寄存器）
> 把自研组 `clkc[1]→clkc[1]` 从 **+0.030 ns 打到 −1.083 ns / 475 违例端点**
> （report13 → report14）；报告瘦身到 208 Byte 后 **−1.562 ns / 但违例端点降到 312、
> 端点总数 4445 → 3691**（report15）—— **最差路径换人了**：
> 变成**适配器自己的 `rbase + rhead` 32 位加法器**（`Logic Level 7` 含 `ADDER=2`）
> 经 `ready` 一路进核内状态机（`u_core/bw[*].ce`）。⇒ 见下面「本轮」。
>
> ★★ **第 3 轮报文（208 Byte 版，ID 205358）—— 读侧修复生效、暴露出我引入的死锁**：
> ```
> AM=FFFFFFFF  AF=FF  AV=00000000        ← ✅ 32 个回读全对（还跨了两次预取）⇒ 读侧根因已修
> C0=1004 C1=1005 C2=1006 C3=1007        ← ✅ 探针 C 全对 ⇒ 写侧正常
> B0=0000 B1=0000 B2=0000 B3=0000        ← ❌ 探针 B 读到 0
> WR=000000 CRC=00 SV=00                 ← ❌ 整帧写入根本没跑（探针 B 之后的阶段全被跳过）
> ```
> ⇒ **读侧修复成功**（`AM` 32/32 对、跨两次预取！），但**我又引入了一个新 bug**：
> 探针 B 要读 `0x1035`，而那时缓冲里还留着 `0x1004..` 的 12 个字（探针 C 只取了 4 个）
> ⇒ **"跳到缓冲外的地址、但缓冲没排空"不会触发新预取**（上一版触发条件里多了 `rcnt==0`）
> ⇒ 永久死等 ⇒ 探针无进展看门狗 1e6 拍后置 `ERR=06` 直接出报告 ⇒ **B 与整帧全被跳过**。
> **同一处 bug 也会在整帧读的第一笔发作**（帧从 word 0 开始，而缓冲里还是探针区的数据）。
>
> ★★ **本轮改了三处（全在 `sdram_app_adapter.v`，都已由单元 TB 覆盖）**：
> ① **未命中就起预取**（去掉 `rcnt==0` 的条件）⇒ 修死锁；
> ② 命中判据用寄存器 `rexp`（下一个待供给字的地址）代替 `rbase + rhead` ⇒ **去掉那个 32 位加法器**；
> ③ 读侧 `ready` 改成**寄存器输出 `r_go`** ⇒ 把"适配器内部 → 核内状态机"这条长组合路径切成两段
> （写侧 ready 不经过它，**写握手时序不变**）。TB 同时新增 **D7「缓冲没排空时跳变地址」**
> ——这条用例正是上一版能过、而板上暴露的那个场景。回归 **557 → 558 项 / 20 个 TB 全 PASS**。

**下次上板要拿到的是"修复后整帧零错"**：判据是 `RD=04B000 BAD=000000`（全局），
加上探针行 `AM=FFFFFFFF`、`AF=FF`、`AV=00000000`、`C0..C3=1004/1005/1006/1007`、
`B0..B3=1035/1036/1037/1038`。（`WR=04B000 CRC=01 SV=01` 表示整帧写入这回**真的跑起来了**。）

| 步 | 做什么 | 看什么 |
|---|---|---|
| 1 | **工程文件**：`safevision.al` 已登记 4 条新文件（`mem_read_burst.v` / `framebuffer_loopback_core.v` / `sdram_app_adapter.v` / `top_stage10_framebuffer.v`）并把 `TOP_MODULE` 切到 `top_stage10_framebuffer`。★ **`.al` 是磁盘快照、TD 跑的是内存状态**：改完必须关掉 TD（提示保存选【否】）再重开，或按 §2.4.2 步 1b 在 GUI 手动添加 | 文件表里能看到那 4 条；`TOP_MODULE` = `top_stage10_framebuffer` |
| 2 | 确认 `constraints/pin.adc` 的 `[SD-ONLY]` 四条**仍处于注释状态**（本顶层无 `sd_*` 端口） | 那四行是 `#set_pin_assignment` |
| 3 | **重新综合** | `syn_1/run.log` 必须是 **`elaborate -top top_stage10_framebuffer`**；`HDL-8007`/`black box` 为 0；`sdram` / `sv_system_pll` / `framebuffer_loopback_core` 要真的 elaborate |
| 3b | ★★ **必须看 STA**：自研组 `clkc[1]→clkc[1]` 的历史是 report13 **+0.030**（0 违例 / 3023 端点）→ report14 **−1.083**（475 / 4445）→ report15 **−1.562 / 312 / 3691** → report16 **−0.992 / 31 / 3709** → report17 **−0.386 / 6 / 3676** → report18 **−0.081 / 2 / 3948** → **report19 −0.218 / 3 / 3982**。★ report19 里**块 mux 那条已被修好（+0.058 ns，过）**，最差换到了**适配器的突发基址 / 读命令计数通路**（`sdram_app_adapter.v` 的 `rfbase` / `wbase` / `rcmd_i`）。**自研组现有约 10 条路径挤在 0.25 ns 以内 ⇒ 本顶层已收手，不再做 RTL 微调**（理由见 §2.5 的"决策"）；**待整机集成后在 A 的顶层上重跑 STA**。判定口径按项目规则 §7 末条（**先按 `Logic Level` / `cell%·net%` / `Max Fanout` / 起止点判物理归属**），**别急着 `set_false_path` 刷绿** | 自研组 SWNS ≥ 0、违例端点 0。★ 全局 **−6.826 ns 落在 `clkc[1]↔clkc[2]`（SDRAM DQ 接口）**：**RTL 不可改，但不能当"正常"放过** —— 见 §三 置顶两条与 [B链-SDRAM接口与PLL时序核查.md](B链-SDRAM接口与PLL时序核查.md) |
| 4 | 下载位流 | — |
| 5 | 看 `led[3:0]` | 运行中 `1`；**`8` = 成功**；其它 = 错误主码低 4 位 |
| 6 | 插 USB，开 COM 口 **115200 8N1**，收 **208 Byte**（★ 用 HEX/二进制导出，别用文本模式） | 报文头 `SV-FB-LOOP` |
| 7 | 对账 | 期望 `INIT=01` / `WR=04B000 CRC=01 SV=01` / **`RD=04B000 BAD=000000`** / `W0=59C3ACE1 W1=670FB387` / **`AM=FFFFFFFF`** / **`AF=FF`** / **`AV=00000000`** / **`C0=1004 C1=1005 C2=1006 C3=1007`** / **`B0=1035 B1=1036 B2=1037 B3=1038`** / `BF=000000` / 末行 `DONE` |
| 8 | 按复位键可重跑 | — |
| 9 | 留证 | 存 `evidence/board/` 并在 `INDEX.md` 记一条；STA 报告按 `evidence/reports/` 记新条目 |

错误码（LED 显示低 4 位）：`01`=init 超时、`02`=写帧错误、`03`=CRC/槽有效位未过、`04`=写帧超时、
`05`=读帧超时、`06`=mem 超时（后端长时间不 ready／**探针无进展看门狗**也复用此码）、`07`=读回数据不符。

**怎么读探针结果**（`AM` 是 32 个回读的匹配位图，bit N = 第 N 个回读等于期望；`AF/AV` 是首个不符
的序号与该处实际回读值；`C/B` 是另起预取处的抽样值）：

| 现象 | 说明 | 指向 |
|---|---|---|
| `AM=FFFFFFFF`、`AF=FF` | 32 个回读全对 | 读侧已修好（配合 `BAD=000000` 即收工） |
| `AM=F0000000` 一类"只有开头一段对" | 读地址在突发内提前回绕 | **读侧仍不对**（再看 `AF/AV` 的错位量） |
| `AV=00001000`（在 `AF=04` 处） | 读第 4 个字时读回的是第 0 个字的**值** | 回绕到突发起点（正是本次现象） |
| `AV` 比期望小 1 / 大 1 | 读地址整体偏了一格 | 地址推进的起点或方向错 |
| `C0..C3=1000/1001/1002/1003`（而不是 1004..1007） | **字 0x1004..0x1007 里存的是前 4 个字的值** | **写侧**也错（写地址在突发内回绕）——本次已排除 |
| `B` 段与 `A` 段表现不同 | 与基址 16 对齐有关 | 突发边界（16 字）效应 |
| **`AM=FFFFFFFF`、`C` 全对，但 `B=0000` 且 `WR=000000`** | 读侧已好、写侧也好，却在"**跳到缓冲外地址**"处卡死（看门狗 `ERR=06` 后直接出报告，后面阶段全跳过） | **预取触发条件**（缓冲没排空时也要能重预取）—— 第 2 轮实测就是这个，已修 |
| `WR=04B000 CRC=01 SV=01` 但 `BAD!=0` | 整帧写入跑完了、读回有错 | 回到 `AV`（错位量）与 `AM`（哪几个回读对）继续定位 |

> ★ **本顶层含加密 SDRAM IP，顶层本身没有 TB**：可仿真部分（`framebuffer_loopback_core` +
> `mem_read_burst`）已由 `tb_framebuffer_loopback_core.sv` 覆盖（**11 项**）；
> **适配器 `sdram_app_adapter` 不含加密件，另有 `tb_sdram_app_adapter.sv`（7 项，含 D7「缓冲没排空时跳变地址」）覆盖**，
> 上板前请确认这两者全绿。
> ★ 探针自带**无进展看门狗**（`mem_error` 或连续 1e6 拍无 `ready`/`rdata_valid` → `ERR=06`），
> 所以探针挂住也会**有界出报告**，不会再出现"LED 停在 1、什么也收不到"。

## 三、已知的"未完成项"（别当成 bug）

> ★★ **先看这两条**（2026-10-03 新增，A 就阶段十审查指出；**不能当无害告警忽略**）：
> 完整核查（事实 / 厂商出货例程对照 / 我们的实物证据 / 候选改法）见
> **[B链-SDRAM接口与PLL时序核查.md](B链-SDRAM接口与PLL时序核查.md)**。

| 项 | 说明 | 什么时候做 |
|---|---|---|
| **SDRAM `C1↔C2` 负时序余量**（读侧 `C2→C1` **−6.826 ns / 32 端点**、写侧 `C1→C2` **−2.787 ns / 32 端点**） | 两条路径**都在 `u_sdram` 硬核 + PAD 之内**：读侧是**纯 PAD↔PAD**（`Logic Level 0`、`cell 100% / net 0%`、扇出 0），写侧起点是**厂商控制器内部的寄存器**（`Logic Level 1 / PAD=1`）。⇒ **RTL 侧没有可改的自由度**。★★ **决定性证据（2026-10-04）**：把数据路径逐行拉出来看，读侧只有 **`input (hard ip)` 5.000 ns**（**整数常数**）+ 内部捕获寄存器 1.453 ns，**net 0.000 ns、扇出 0**；写侧是 **`output (hard ip)` −5.000 ns** 直接把要求时间扣掉 5 ns ⇒ **光这一个模型常数（5 ns）就超过 4 ns 的 budget，数学上不可能靠改 RTL 收敛**。★ 厂商自己的出货例程 `lab_ex5_i2s` 有**同名同结构**的路径组（`clkc[2]→ext_mem_clk`，**−6.565 / 32 / 32**，同 4 ns 预算、同 `sdram.dq[*]` 终点）⇒ 这不是我们引入的配置错误；**但"厂商同数"只能作旁证，不能单独作豁免依据**。★ 我们已有的实物证据：M-11（4096 word `BAD=0000`）+ 阶段 10（**307200 word 逐像素零错**），写读两个方向都覆盖；**局限是单板单温度点、非厂商全模式图案、无长时间 soak** | **① B 侧先自己把实物证据做厚**：M-11 补全片稀疏扫描、SDRAM 压力 soak、扩展图案（walking-1 / 全 0 全 1 / 相邻位翻转）—— 都写进 `evidence/board/`。**② 拿路径结构 + 实物证据向厂商/文档确认**：该硬核 DQ 接口的 4 ns 预算是不是正确的检查方式。**③ 整机集成后在 A 的顶层重跑 STA**。★ **不许给 `C1↔C2` 加宽泛 `set_false_path`**（它们真的在传数据），也不许为了刷绿随意降频/改移相角 |
| **PLL `USR-6135`（反馈走局部网络）** | 我们的 `sv_system_pll` 用 `FEEDBK_PATH("CLKC0_EXT")`，而 **C0（100 MHz）扇出 = 0（悬空）**；厂商 `lab_ex4_tf` 用**完全相同**的 `FEEDBK_MODE/FEEDBK_PATH`，但它把 C0 当 `sd_card_clk` 用、**扇出 451**。`CLKC0_EXT` 要求 C0 真的走一条外部（全局）网络绕回 `fbclk`；C0 悬空时反馈没有实际负载，工具判 local **是有据可依的**。★ 这也解释了 A 看到的"物理报告说走了全局资源 / 时序检查仍判 local"的矛盾 —— 两者的前提（C0 有没有负载）不同 | 三个候选（**B 不单方面改**，要与 A 一起定）：**(a)** 让 C0 真正带负载（若整机里正好有 100 MHz 需求，最贴近厂商做法）；**(b)** 改内部反馈模式（相位补偿模型变 ⇒ **必须重验所有相位关系**）；**(c)** 保留现状 + 向厂商确认。★ **不许 `set_false_path` 盖掉，也不许随意改移相角**（会牵动 SDRAM 初始化 / 刷新计数 / 吞吐量 / A 的时钟契约） |
| CMD18 多扇区读 | `sd_sector_reader` 目前只支持 CMD17，`rd_len` 必须为 1，否则明确报错。多扇区读需要额外的 STOP_TRANSMISSION。连带影响：`fat32_directory_scanner` 现在只能"一个扇区一次 CMD17"，根目录越大读得越碎 | 带宽优化阶段（对应 O-11） |
| 超时值未实测 | `safevision_defs.vh` 里的超时是"规范推导 + 裕量"，仿真时用 `SIM_FAST_TO` 缩小以便跑到超时分支 | 板到后执行 M-1~M-3 |
| 板级顶层 | **已解决**：`top_stage5_sector_rd.v` 已写，并新增 `tb_top_stage5_sector_rd.sv` 在仿真里跑通（5 项断言）；仍未上板 | 已做 |
| 引脚约束 | **已解决**：`pin.adc` 与 `timing.sdc` 已写并登记进 TD 工程；`uart_txd = D12` 已确认为 FPGA 发送脚 | 已做 |
| `uart_txd` 物理落点 | **已解决（2026-10-02）**：开发板手册串口引脚表（`RXD=F12`/`TXD=D12`）+ 图2-10 CH340G 原理图（两线交叉）确认 `D12` 是 FPGA 发送脚、对接板载 USB-UART，无需外接 USB-TTL。`pin.adc` 保持不变 | 已完成 |
| 根目录簇链跟随 | **已解决**：阶段 7 抽出 `fat32_cluster_walker.v`，`fat32_directory_scanner` 与 `file_streamer` 共用同一份 | 已完成 |
| `file_index` | **已完成**：编号扫描 + 数字后缀排序 + 索引表冻结 + WAV 配对 | 已完成 |
| **SDRAM 真实 IP 未接** | 仿真用行为模型 `verification/models/frame_memory_model.sv`（不建模 tRCD/CL/tRP/tRFC 与刷新，**不能用于长稳评估**）。真实 PHY 按手册 7.9「第一版不要手写，直接跑通官方 Demo」用安路官方 IP，替换 `mem_ctrl` 内部实现即可 | 板到后（M-10/M-11） |
| **阶段 10 帧缓存回环 —— 已上板验收通过；时序决定"收手"（自研组 −0.218 ns / 3 违例端点）** | 板上用「地址斜坡探针」定案：**一次连续读突发里读地址只推进 4 个字就回绕**（`A0..A3` 对、`A4..AF` 重复），帧级 `BAD` 恰为 153600 的精确 3/4。根因 = `sdram_app_adapter` 上一版把**读预取的地址推进挂在 `Sdr_rd_en` 上**（违反 M-11 已验形态）。第 4 轮板上实测（2026-10-03 晚）：**全部判据一次通过**（`BAD=000000`、三个探针全对）⇒ **功能闭环完成**。**时序**：report16 **−0.992 / 31** → report17 **−0.386 / 6** → report18 **−0.081 / 2** → **report19 −0.218 / 3 / 3982**（report19 里**块 mux 那条已修好 +0.058**，最差换到**适配器突发基址/读命令计数**通路）。**三刀全在报告/索引通路**（瘦身、纯移位收集、报告 mux 两级化 + 块号寄存器），**逐字节等价、回归 558 不变**。⇒ **自研组现有约 10 条路径挤在 0.25 ns 以内，已决定收手**（见 §2.5 的"决策"） | **整机集成后在 A 的 `safevision_top` 上重跑 STA**（本顶层是 bring-up 自测顶层，继续微调转移价值低）；若那时报告通路仍关键 ⇒ 用**有理由的 `set_multicycle_path`**，不用 `set_false_path` 刷绿；若适配器通路仍关键 ⇒ 那是要交付的真逻辑，值得单独优化。**其余**：M-7 / M-8 拔卡 / M-11 稀疏扫描 现在就能做；M-12~M-19 须等整机 |
| **异步 FIFO 用官方 IP** | `sync_fifo.v` 只覆盖同域；跨时钟域（`mem_clk→pixel_clk`、`mem_clk→audio_clk`）用安路软 FIFO（`SHOW_AHEAD=Enable`、`OUT_REG=Disable`）。**禁止手写异步 FIFO** | 整机集成时 |
| **音频链 B04 还剩两块** | `wav_parser` **已完成**；还差 `pcm_ring`（SDRAM `AUDIO_RING` 环形缓冲，解耦慢读与连续消费）与 `audio_cdc_fifo`（`mem_clk→audio_clk`，用安路软 FIFO FWFT）。手册 8.6 要求音频必须走 HDMI 数据岛，**不走外部 I²S Codec** | 见 §三 |
| **媒体格式层** | **已收尾**：`bmp_unpack`（BGR888→RGB565、行填充、方向归一化，`ROUNDING` 参数待 O-1 定夺）与 `wav_parser`（RIFF 解析 + 未知块跳过）。顺带补登记了 `ERR_WAV`(0x07) 与 `DET_WAV_*`(0x71–0x76) —— 原先只写在 interface_spec，代码里缺 | 已完成 |
| **WAV 出错后不排空** | 出错即停收，交上层 abort / 回退提示音（手册 D-7 要求"回退提示音"）。当前实现不主动排空剩余字节 | 整机集成时确认 |
| `bmp_unpack` 的舍入方式未定 | `ROUNDING` 参数（0=截断 / 1=舍入+饱和）已做成参数，等 A/C 一起定（interface_spec 待确认项 O-1） | 与 A/C 定 |
| `bmp_parser` 坏文件要排空整条流 | 校验不通过时当前实现会把该文件剩余字节全部排空（只丢不外送），坏文件大时浪费时间。可加一个 `abort` 输入让上游提前收工 | 有空再做 |
| **帧交换未与 A 联仿** | `frame_swap_ctrl` / `frame_swap_cdc` 只做了 B 侧自测（23 项断言），没有和 A 的像素域一起跑过。这是 A/B 第一次真正协同，**建议优先联调** | 与 A 约定时间 |
| **整机集成未做** | `safevision_core.v`（子系统互连）与 `safevision_top.v`（板级）由 A 负责；B 侧模块已就绪但还没接进子系统 | A 负责 |
| **结构对齐后遗留** | `rtl/common/shift_reg.v` / `spi_byte_rx.v` 是阶段 1 教学件、产品链未例化，现结构无对应项，暂放 `rtl/common/` | 有空再清理 |

---

## 四、变更记录

| 日期 | 变更 |
|---|---|
| **2026-10-05** | ★★ **板级顶层 `safevision_top` 首点亮：HDMI B 出彩条 + `led[3:0]` 全亮** ✓（B 侧主责的板级顶层，接封装内 SDRAM + 厂商 HDMI 1.4b 发送核）。配套：`platform/.../rtl/safevision_top/`、独立约束 `project/board_verify/board_b.adc`（**HDMI B**，不动共享 `pin.adc`）、`board_b.sdc`/`board_cdc.sdc`、`tools/run_board_sta.ps1`（默认不流片，`-Bitgen` 才出位流）。**HDMI B 引脚四方交叉 + TD 实测逐脚核对通过**（正端 C3/G5/F1/E1、负端 **C2/G6/F2/D1**、DDC P2/R2；`#IO=12`、`#pad=16` 精确自洽 ⇒ 无意外占用引脚）。板级 STA：**用户逻辑域全绿**（pixel +27.945 / mem +0.121 / sys +3.113 ns）、**唯一遗留是封装内 SDRAM 硬核物理路径 `−6.565 ns`**（`dq→内部 pad`，cell 100% / net 0%，用户 RTL 无法优化）⇒ ★ **功能实测可用，但不等于时序收敛**。详见 [B链-板级顶层HDMI验证报告](B链-板级顶层HDMI验证报告.md)；观测证据登记于 `evidence/board/INDEX.md`（HDMI-B-BRINGUP-PASS）。**未提交/未推送**：等用户指示 |
| 2026-10-04 | 修复 A/B 集成 `top_sdram_loopback` 的 190 Byte UART 报告选择路径：按行寄存、再选行内字节；C1 自研 setup `−0.094 ns → +0.113 ns`，0/2517 违例。当前 selector 版已用 ModelSim SE-64 10.7 重跑专用应用层回归：六场景 PASS，编译 0 error/0 warning；独立索引映射 190/190 通过。未生成匹配位流/未上板；全局 SDRAM setup 仍 `−6.826 ns`。下一步由用户经 TD GUI 生成匹配位流并做 10 分钟 soak，核验后再议 push |
| — | 初版：阶段 1–5 仿真通过后整理 |
| — | 阶段 6 首块 `fat32_boot_parser` + 四类异常分支测试通过后更新 |
| — | 阶段 6 第二块 `fat32_directory_scanner` 通过后更新（回归 116 项；登记两条真实踩坑：字节消费必须 `valid && ready` 门控、FAT 入口是小端且高 4 bit 需掩掉） |
| — | 阶段 7 通过后更新（回归 206 项）。同时按新结构全仓改名：`rtl/{include,common,storage,media}` + `verification/{unit,models}` + `tools`，回归全绿未回归。新登记三条踩坑：清零逻辑要放状态机之外、文件末字节落在扇区末字节时的同拍判定、BMP 字段同为小端 |
| — | **阶段 8–16 + 阶段 6 收尾通过后更新（回归 382 项）**。新增 `rtl/memory/` 全套（SDRAM wrapper、帧缓存地址、帧写入、仲裁、DMA 读、双缓冲、帧交换、带宽监视）、`rtl/common/`（切分缓冲、同步 FIFO、FIFO 健康度、错误上报）、`frame_memory_model.sv` 行为模型、`file_index.v`。新增 §2.5 存储链实测项 M-10~M-19、§2.6 排查顺序扩到 11 条、"未完成项"表补上 SDRAM 真实 IP / 异步 FIFO / 音频链 / 帧交换联调 / 整机集成 |
| — | **阶段 8–16 全部落地 + 媒体层收尾后更新（回归 457 项）**。补 `bmp_unpack` / `wav_parser` / `file_index` / `error_report`，补登记 `ERR_WAV` 与 `DET_WAV_*` 错误码 |
| — | **v1.7：逐项核对命名后更新（回归 502 项 / 15 个 TB）**。① 重命名 4 处（`wav_parser`、`memory/fifo_health_monitor`、`frame_memory_model`、`tb_frame_writer`）；② 补 `rtl/include/pixel_format_defs.vh`（**冻结地址表唯一来源**）与 `event_code_defs.vh`；③ **修掉"同一个常量在 4 个模块各存一份副本"**（帧几何/地址表全部改为引用 `` `SV_`` 宏，parameter 保留）；④ 补 `rtl/common/crc16_ccitt.v` / `crc7.v`，`sd_sector_reader` 与 `frame_writer` 各自那份重复的 CRC 函数删掉改为例化；⑤ 新增 `tb_crc`(12)、`tb_fat32_cluster_walker`(33，**该模块的判 EOC/越界/判环三条收尾分支此前从未被仿真跑过**)；⑥ 拆分 TB：`tb_frame_swap`→`tb_memory_arbiter`+`tb_frame_swap_ctrl`，`tb_media`→`tb_bmp_unpack`+`tb_wav_parser`（只搬位置不改断言）。**概念更正**：此前说的"宏与 parameter 命名冲突"是误判——宏只在写成 `` `名字 `` 时展开，两者不会冲突（已编译验证） |
| — | **补交付口径与文档同步规则**。① 新增"文档同步义务"说明（本文件属文档三件套，状态/回归数/未完成项变化必须回来改）；② 补一份真正的 `README.md`（目录结构、跑仿真方法、状态总览、硬约定、有意未创建的目录）；③ 修正 §2.2 里 v1.5 改名前的过期路径（`rtl/common/safevision_defs.vh` → `rtl/include/…`、`rtl/sd/` → `rtl/storage/`）；④ 把"开发基准＝手册 V2.0 / 结构基准＝仓库目录结构"写进 interface_spec 与项目规则文件 |
| — | **v1.8：引入队友的项目管理覆盖包（目录骨架 + 管理文档），并把它的过期内容改对**。新增 `.github/` 模板、`docs/` 六个子目录（architecture/interfaces/requirements/management/verification/release）、`evidence/` 七类证据索引、`safevision/{platform,build,assets}`、`rtl/{video,audio,control,safety,top}`、`verification/{subsystem,system,board}`、`tools/check_repo.ps1` —— **全部只有 README 占位，无功能代码**。`.gitignore` 换成覆盖包版本（白名单加 `!/.github/` `!/evidence/`，多排除 `*.lic`/`*.key`/`*.pem`）。**接口/RTL/TB/回归数一字未变，仍 502 项断言 / 15 个 TB**，目录自检 `LAYOUT PASS`。覆盖包是按旧快照（48 文件 / 27 RTL）做的，带进来的过期内容已逐项改对：**27→29 个 RTL、11→15 个 TB、457→502 项断言**、`fifo_health_monitor` 归 `memory/`、`wav_reader`→`wav_parser`、`sdram_model`→`frame_memory_model`、`tb_media`/`tb_mem_write`/`tb_frame_swap` 拆名、并作废"待办清单仍有 `rtl/sd` 旧路径"的指控（v1.7 已修）。另修 `interface_spec` §3.1 的 `rtl/sd/spi_master.v` → `rtl/storage/…` 与 `bmp_unpack.v` 注释里的 `tb_media` → `tb_bmp_unpack` |
| — | **结构基准变更 + 全仓文档去绝对路径 + 清除旧参照物引用**。① **结构基准改为本仓库 [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md)**，原参照物作废，全仓对它的引用（RTL 头注释、模块小节标题、表头列名、历史行里的出处标注）已一并清除；② 清掉覆盖包带进来的本机绝对路径——文档里的 ModelSim 安装路径改为按变量名 `$MSIM_BIN` 描述，文档树根由 `Safe_Vision_FPGA_2026/` 改为 `<仓库根>/`，`run_sim.ps1` 用法注释与原理讲解里的 `f:\...\` 占位改为相对路径。新约定：**文档里只用仓库相对路径** |
| 2026-10-02 | **板级 bring-up 第一版落地**：① 新增板级顶层 `platform/anlogic_eg4s20_hx4s20c/rtl/top_stage5_sector_rd.v`（上电延时 → SD 初始化 → 读 LBA=1000 → 512 Byte 经 UART 回传；两 SD 模块共用一份 `spi_master`，按 `init_done` 二选一；**不接 PLL，全跑板载 50 MHz**）；② 新增 `constraints/pin.adc`（引脚逐个按 `2_FPGA.pdf` / `6_EX_DEVICE.pdf` 核对，并与厂商同器件例程交叉验证）与 `constraints/timing.sdc`（单一 50 MHz：`create_clock -period 20`）；③ TD 工程 `safevision.al` 把 `TOP_MODULE` 从 `crc7` 改为 `top_stage5_sector_rd`，加入顶层与 `reset_sync.v`，并把两约束挂到 `constraint_1`；④ **新增顶层 TB `tb_top_stage5_sector_rd.sv`**（T1 完整命令序列 / T2 CMD17 参数 1000 / T3 512 Byte 经 UART 逐字节与卡模型一致 / T4 顶层进成功态）→ 回归 **502 → 507 项断言 / 15 → 16 个 TB，全 PASS**；⑤ **`run_sim.ps1` 的 ModelSim 路径改为 `-ModelSimBin` 参数 + `MSIM_BIN` 环境变量**（与 `run_clock_sim.ps1` 同口径，删掉写死的本机路径；`check_repo.ps1` 的自检正则同时扩到 `../platform/`）。**待办**：`uart_txd` 物理落点复核（暂取 D12）、TD 里确认依赖分析没误标 `AutoExcluded` |
| 2026-10-02 | **第一次在 TD 里跑依赖分析 + 综合，暴露并修掉一个真 bug**：① **TD 报 `HDL-8007 net 'bdata[7]' is constantly driven from multiple places`**（`sd_initializer.v(120)` + `sd_sector_reader.v(137)`）——这两个模块的 `bdata` 本应只由主状态机驱动，但字节引擎的复位分支里多写了一次 `bdata <= 8'hFF`，两个 `always` 块写同一个 `reg`。**ModelSim 编译/仿真都不报错（回归 507 项全绿也带着它走），TD elaborate 直接把两个模块降级成黑盒**。已把该复位赋值收归主状态机；另写了一遍全仓静态复查（同一 `reg` 出现在 >1 个 `always`/`initial` 块）确认其余 29 个 RTL 没有同类问题。② **`AutoExcluded` 已核对**：`safevision_Runs/syn_1/run.log` 显示 `elaborate -top top_stage5_sector_rd` 把闭包内 7 个模块全部 elaborate 到了，没有被误排除（只有 `crc7.v` 被排除，而它只被 `tb_crc` 用，正确）。③ **`uart_txd = D12` 确认**：开发板手册《HX4S20开发板手册-HDL版2410.pdf》的串口引脚表（`RXD=F12`/`TXD=D12`）+ 图2-10 CH340G 原理图（CH340 pin2→网络 `RXD`、pin3→网络 `TXD`，**两线交叉**）证明网络名按 FPGA 视角命名，`D12` 是 FPGA 发送脚、对接**板载 USB-UART**，**不需要外接 USB-TTL 模块**。④ 新增排查条目 §2.6-13（多驱动只在 TD 报、仿真不报）。⑤ `.gitignore` 增加 TD 运行产物 `*_Runs/` 与 `*.logw` |
| 2026-10-02 | **TD 全流程跑通，位流已生成，可以上板**：修掉多驱动问题后重新综合 → 布局 → 布线 → 位流**一次通过**。**Setup WNS +11.297 ns / Hold WNS +0.046 ns，违反端点 0**（906 端点 / 3480 路径）；50 MHz 约束下报告 **Fmax 114.9 MHz**（余量很大，说明 bring-up 这版逻辑很浅）；资源 **IO 11/188、LUT 814/19600、REG 434/19600、BRAM 0、DSP 0、slices 436（4.45%）**；IO 计数 11 与顶层 11 个端口一致 ⇒ **`pin.adc` 已生效**。`syn_1/run.log` 中 `HDL-8007/9007` 与 `remains a black box` **全部消失**（对比同日早先那次失败的 elaborate）。**原始报告留证**：新建 `evidence/reports/` 条目 TC-Q-STA，复制了 TD 布线后 STA 原文（`final_timing.rpt`）、布线/布局 QoR、综合日志、综合后资源，并在 `evidence/reports/INDEX.md` 记录 SHA-256 与结论（`.bit` 因全局忽略不进仓库，只记存在与生成时间）。**新增 §2.2「上板步骤」**（7 步：插卡 → 下载 → 看 LED 状态码 → 插 USB 开 COM 口 115200 8N1 收 512 Byte → 与 `lba1000_pc.bin` 逐字节比对 → 按复位键重跑）。**唯一遗留的隐患**：Hold（removal）余量 0.046 ns 很薄，源头是 `reset_sync` 输出的复位树，以后在复位域加寄存器或提频需重测；`uart_txd` 等 I/O 路径仍故意未约束（等 M-5/M-6 实测） |
| 2026-10-02 | **改掉比对基准：LBA 1000 → LBA 8192**。读卡器（`Get-Disk` 磁盘 2，卷 `G:` 标签 `HX4S20C`，FAT32，7.38 GB）实测：分区**从物理扇区 8192 开始**，所以原定的**物理 LBA 1000 落在分区前的空隙里、读出来是 512 个 `0x00`** —— 两边全零会让逐字节比对失去证明力。改用**分区首扇区 = FAT32 引导扇区（DBR）**：内容非零、可识别（`eb 58 90 "MSDOS5.0"`…`55 aa`）。参考值存 `evidence/board/lba8192_pc_20261002.bin`（512 B，SHA-256 `E4704165…C426EEE`），已在 `evidence/board/INDEX.md` 记条目 **REF-LBA8192**（含设备、分区表、读法与两个概念陷阱）。`top_stage5_sector_rd.v` 的 `TARGET_LBA` 默认值改为 `32'd8192`；`tb_top_stage5_sector_rd.sv` **刻意保留 1000**（它显式传参，验的是"给定 LBA 原样送出"这条通用性质，断言一字未动），回归仍 **507/507 PASS**。**同时修正 M-5 的预期值**：bring-up 跑 50 MHz 不接 PLL，SCLK 应为**初始化段 200 kHz / 数据段 12.5 MHz**（是 `safevision_defs.vh` 按 100 MHz 推导的 400 kHz / 25 MHz 的一半）。**与此同时 `TC-Q-STA` 那份证据对应的是 LBA=1000 的构建，需要重新综合一次以对齐。** |
| 2026-10-02 | **上板第一次实测：LED 状态码 = 8（成功），并新增上板采集脚本**。① 位流下载成功后板上 **只有 LED4 长亮**。查原理图「4 bit LED」确认 LED 接法是 `FPGA 引脚 → 1K（RN17）→ LED 阳极 → 阴极 → GND`，即**高电平点亮**；我们的状态码里只有 `4'h8`（`1000`）是最高位亮 ⇒ **LED4 单独亮 = 8 = 成功态**（SD 初始化 + CMD17 读 LBA 8192 + 512 Byte 经 UART 发完 + CRC16 对上）。② 收不到数据的原因定位：电脑上只有 **4 个蓝牙串口**（COM3/4/8/9），**没有 CH340** ⇒ **板载 USB-UART 那个口没插线**（下载位流用的是 USB-JTAG，是另一个口）。③ 新增 **`safevision/verification/board/capture_uart_512.ps1`**：列端口 → 115200 8N1 无流控 → 清残留 → 提示按复位键 → 收满 512 Byte → 存**原始二进制**（默认 `evidence/board/uart_capture_<时间戳>.bin`）→ 与参考值逐字节比对，全对打印 `PASS` 返回 0（已在本机验证端口枚举与错误分支正常）。④ §2.2「上板步骤」补到 8 步 + 新增 **LED 状态码速查表**（含接线极性与位序 `led[3]`→LED4），并写明**两个 USB 口的顺序**和"先让脚本等、再按复位键"（512 Byte 只在复位后发一次、45 ms 发完）。⑤ 「USB 转串口模块不需要买」那条已在 §1.1 划掉。 |
| 2026-10-02 | **第二次上板：拿到 UART 数据，但被串口工具的文本模式有损转换**。用户用 Serial Debug 助手存出 `Serial Debug 2026-10-02 175226.txt`（740 B），HxD 里出现大量 `EF BF BD`。**严格验证**：把参考 512 字节按"当 UTF-8 文本解码（非法字节→U+FFFD）再编码"变换一次，得到 **740 字节且与采集文件逐字节完全相同** ⇒ **FPGA 发出的就是参考原文，链路全对**；损失全部来自保存方式（参考里 141 个 `≥0x80` 的字节被替换，512→740，不可逆）。可逐字节确认 371 个 `<0x80` 字节；ASCII 串 `MSDOS5.0` / `NO NAME    FAT32` / `BOOTMGR` / `Disk error` / `Press any key to restart` 全对。**M-9 标记为"数据已证明正确、尚需一次二进制采集"**。证据存 `evidence/board/uart_capture_20261002_175226_textmode_mangled.txt`（740 B，SHA-256 `0B350785…`），索引条目 **CAP-M9-01**。新增排查条目 **§2.6-14**（`EF BF BD` 的识别与判定方法），并在 §2.2 第 6 步写明这个坑。 |
| 2026-10-02 | **★ M-9 通过 —— 阶段 1–5 的实物验收完成**。重新导出改为 **HEX 文本**（无任何 `EF BF BD`），1536 B = 512 个 `XX ` 记号；解码成 512 字节后与参考 `lba8192_pc_20261002.bin` **SHA-256 完全相同**（`e470416567d512c0…`），非零字节 372 个也一致 ⇒ **512/512 逐字节一致**。至此实物验证覆盖：SPI 位序与 SCLK 相位、`CMD0`/`CMD8` 的 CRC7、`CMD55`+`ACMD41`+`CMD58`、`CMD17` 的 LBA 大端字节序、512 Byte 数据通路、CRC16 比对。证据：`evidence/board/uart_capture_20261002_175836.bin`（512 B，与参考同哈希）+ 原始导出 `uart_capture_20261002_175836_hextext.txt`（1536 B），索引条目 **M-9-PASS**。另：**M-5 不再强依赖示波器** —— `uart_tx` 的分频按 50 MHz 算，512 字节能在 115200 下完整收到即说明实际时钟在 ±2% 内就是 50 MHz；`sd_dclk` 精确频率可用 TD 的 ChipWatcher 复核。**下一步候选**：M-6（连读 100 次，需在顶层加连读计数）/ M-7（多卡）/ M-8（拔卡恢复）/ 把 bring-up 顶层往上推一层做阶段 6–7 的板级验证（读 DBR+BPB、扫根目录）/ SDRAM 官方 Demo 读写回环（手册 7.9）。 |
| 2026-10-02 | **★ 为阶段 6–7 板级验证补上"卷基址"这块（`mbr_parser`）—— 这是板级实测逼出来的真缺口**。读代码发现 `fat32_boot_parser` 写死 `sd_rd_addr <= 32'd0`（TB 也有断言 `T11.3 挂载读的是 0 号扇区`），即**整个 FAT32 层假设"卷从 0 号扇区开始"（超级软盘格式）**；但真实 TF 卡是分区的（本卡分区起始 = 物理扇区 8192，卡 0 号扇区是 MBR）⇒ 直接接上去必然 `mount_error`。新增 **`rtl/storage/mbr_parser.v`**：读卡 0 号扇区，按**小端**解析分区 0 的起始 LBA（`446+8..11`）与扇区数（`446+12..15`），给出 `has_mbr` / `vol_base_lba` / `part_secs`；对"无 `0x55AA` 签名 / 分区项为空 / 起始 LBA=0"三种情况**不报错**、按无分区表回退为 0，只透传 SD 层错误。**约定写进 interface_spec §3.2.1**：FAT32 层永远不碰分区偏移，**卷基址只在板级顶层加一次**。新增 `tb_mbr_parser.sv`（T1 有效 MBR 起始 8192 / T2 无签名 / T3 空表项 / T4 起始 LBA=0，**7 项断言**）⇒ 回归 **507 → 514 项断言 / 16 → 17 个 TB，全 PASS**（既有 TB 与 RTL 端口一字未动）。interface_spec 升 **v1.11**。**下一步**：写阶段 6–7 的板级顶层（上电 → init → `mbr_parser` → `fat32_boot_parser` → `fat32_directory_scanner` → UART 回传文本报告比对）。 |
| 2026-10-02 | **★ 阶段 6–7 板级顶层已写 + 仿真通过（未上板）**：`platform/anlogic_eg4s20_hx4s20c/rtl/top_stage6_fat32_mount.v` 串起 上电 → SD 初始化 → `mbr_parser` → `fat32_boot_parser` → `fat32_directory_scanner`(+`fat32_cluster_walker`)，最后经 `uart_tx`(115200) 发**纯 ASCII 报告**（`KEY=HEX` 每行一项，末行 `DONE`）——★ 用 ASCII 是刻意的：连"文本模式把高位字节换成 `EF BF BD`"那个坑都绕过去了，串口助手直接可读、也可被采集脚本按字节比对。**卷基址只加一次**（`rd_addr_to_reader = bus_rd_addr + mbr_vol_base`；MBR 那一轮基址还是 0，所以同一加法器正好落到卡 0 号扇区，无需特例）。卡模型加 `VOL_BASE` 参数（默认 0 时**逐项等价**，老 TB 行为不变）以便模拟分区卡。新增 `tb_top_stage6_fat32_mount.sv`（**16 项断言**，含"FAT32 层 LBA 0 必须落到卡 LBA = 分区基址"这条关键断言）⇒ 回归 **514 → 530 项断言 / 17 → 18 个 TB，全 PASS**；`check_repo.ps1` → `LAYOUT PASS`；**多驱动静态扫描全仓 0 个文件有问题**。TD 工程已登记新顶层（`TOP_MODULE = top_stage6_fat32_mount`，含 `mbr_parser.v` 与 `top_stage6_fat32_mount.v` 两条设计文件）。**待办**：TD 重新综合（确认无 `HDL-8007` / 无 `AutoExcluded`）→ 下载 → 采 UART 报告并与电脑侧独立解析的基准对账。 |
| 2026-10-02 | **★★ TD 综合抓到第二个"仿真抓不到"的真问题：组合除法器导致时序违例，已修复。** 阶段 6-7 顶层综合后 **SWNS = -85.399 ns**（负 = 建立违例）、**28 / 4684 端点违例**、**Fmax 仅 9.488 MHz**（约束 50 MHz）。最长路径落在 `fat32_boot_parser.v:255` 的 `total_clus <= (...) / spc`：**Verilog 除法运算符被综合成组合除法阵列**（Logic Level **100**、ADDER **68**、105 ns）。**修复**：该分支已被 `spc_ok`（`(spc & (spc-1)) == 0`）保证 `spc` 是 **2 的幂**，故改为 `>> w_log2_spc`（`log2` 用一个 3 位优先编码器求）—— **对无符号数逐值等价**，所以接口、行为、断言一字未改，回归仍 **530 / 530 FAIL=0**。全仓扫查除法/取模：`uart_tx` 的是 `localparam`（编译期折叠）、`bmp_unpack` 的 `/4` 与 `frame_writer` 的 `% SAMPLE_STRIDE` 都是 2 的幂（变移位/掩码），**真凶只有这一处**。**教训两条**：① 可综合 RTL 禁用除法/取模（已写进项目规则 §5 第 10 条）；② **"某个顶层时序通过"推不出"它没实例化的模块也能综合"** —— 阶段 5 那次能过，纯粹因为那个顶层没接 FAT32 层。**证据**：`evidence/reports/sta_stage6_fat32_mount_20261002.txt`（节选 10.8 KB；原始 868456 B 未入库），索引条目 **TC-Q-STA-2**。**待办：重新综合，确认 SWNS 转正**（若仍有其它长路径，按同一节奏继续）。 |
| 2026-10-02 | **★★★ 阶段 6–7 板级验收通过（M-10）+ 时序转正 —— 一天里从"炸了"到"过了"。** ① **时序**：重新综合后 **SWNS = +6.042 ns**（原 -85.399）、**STNS = 0**（违例端点 0）、HWNS = +0.030 ns；R-Period **13.958 ns** ⇒ **Fmax 71.644 MHz**（约束 50 MHz，余量约 30%）；**关键路径 Max-Level 从 100 降到 12** —— 这就是"组合除法阵列被移除"的直接证据。证据 `evidence/reports/sta_stage6_fat32_mount_20261002_1959.txt`，索引条目 **TC-Q-STA-3**。② **上板（M-10，阶段 6–7 验收）**：位流 20:01 下载后板上 LED = 成功态 8；UART 报告 450 Byte 与电脑侧基准 `evidence/board/stage6_expected_report_pc_20261002.txt` **逐项对账通过** —— `MBR=00000001`、**`BASE=00002000`（★ 卷基址在实物上成立：FAT32 层的"卷 0 号扇区"确实落到卡的物理扇区 8192，这正是这一轮补的那个缺口）**、`SECS=00ECC000`、`BPS=0200`、`SPC=08`、`NFAT=02`、`FATLBA=000009DE`、`DATALBA=00008000`、`ROOTLBA=00008000`、`TOTSEC=00ECC000`、`TOTCLUS=001D8800`、`ENT=0005`、5 个目录项（`SV0001..SV0005.BMP`，name/attr/首簇/size **全对**，size 均 `000E1036`=921654）、末行 `DONE`。证据 `evidence/board/uart_report_stage6_20261002_200159_hex.txt`（HEX 导出 1350 B），索引条目 **M-10-PASS**。③ **对账中发现两处偏差，都记档**：(a) `ent_index` 是 **0-based** 目录槽号，**我的基准初版按 1-based 记、写错了**（实物 0009/0019/001A/001B/001C，比基准少 1），已按实物更正基准并写明 —— 这就是"电脑侧基准也要被实物检验"的意义；(b) 每行行尾是 **`72 0A`（字母 r + LF）而不是 `0D 0A`（CR+LF）**：**源码写的是 Verilog 字符串 `"...\r\n"`，源码没错**，但这**不是"仿真与综合不一致"，是转义写错了**：★ **Verilog-2001 的转义表里根本没有 `\r`**（只有 `\n` `\t` `\\` `\"` 和八进制 `\ddd`），所以 `"...\r\n"` 在 **TD 与 ModelSim 里都**编成 `72 0A`（字母 r + 换行）；老 TB 之所以通过，是因为 **TB 用同一个错误转义构造期望值、两边错得一样**（这条教训比坑本身更重要：**仿真全绿连"RTL 与 TB 对约定理解一致"都证明不了**）。已改为显式字节 `8'h0D, 8'h0A`，并记进项目规则 §7 工具坑与 §5 第 11 条。属纯外观瑕疵，不影响判定。④ 另有一个**待确认的 0x00 前缀**（可能是采集工具产物，也可能是发射端多打一拍），不影响正文；下次采集顺手确认。**下一步**：修那两个外观项（`\r` 转义、0x00 前缀）→ 或直接推进 M-6/M-7/M-8 / SDRAM 官方 Demo 回环。 |
| 2026-10-02 | **★ 修掉 M-10 的两个"外观项"，并加上 M-6/M-8 的连读阶段（回归 530 → 540）。** ① **`0x00` 前缀的根因确认**：`top_stage6` 的 `hdr_bits` 声明成 `[1471:0]`（184 Byte），但报告头六段实际只有 `21+42+25+51+34+10 = 183` Byte，Verilog 在 MSB 侧补零 ⇒ 整份报告多一个前导 `0x00`（板上 450 = 1 NUL + 183 + 260 + 6 与之完全吻合）。改为 `[1463:0]` / `HDR_BYTES=183`，并对 HDR/ENT/RPT/ERR/DONE 每段保留「逐字节相加 = 声明字节数」的核对注释。② **`\r` 转义**：RTL 全部 `"\r\n"` → 显式字节 `8'h0D, 8'h0A`。★ **实测更正了此前的判断**：用 vlog 10.7 亲测，**ModelSim 也不把字符串里的 `\r` 当转义**（`"DONE\r\n"` 得到 `44 4F 4E 45 72 0A`），旧 TB 用同一转义所以"两边错得一样"、仿真自洽通过；真机上才是 `72 0A`。改显式字节后仿真与硬件都发真 CR。③ **新增连读阶段（M-6 / M-8）**：新参数 `RPT_N`（默认 `16'd100`）；挂载 + 扫目录后，复用**同一个** `sd_sector_reader`（顶层第 5 个读请求方）对同一 LBA（根目录扇区）连读 `RPT_N` 次，**卷基址仍只加一次**，连读阶段 `data_ready` 恒 1 排空 512 Byte，每次的成败由 reader 自带 CRC16/超时判定。**失败也不提前退出**（跑满 `RPT_N` 次：报告长度固定、能区分"1 次坏"与"全坏"、拔卡时每读由 reader 出口兜底必然有界）。报告新增一行 `RPT=<total:4hex> OK=<ok:4hex> BAD=<bad:4hex>`，`BAD!=0` 时末行改发 `ERR=02`；LED 新增 `9 = 连读进行中`。④ `tb_top_stage6_fat32_mount.sv` 扩到 **26 项断言**（两个场景：健康卡 `RPT OK=100 BAD=0`、字节数 372、无前导 0x00、每行 CRLF；连读中拔卡 → 字节数 374、`RPT OK=0 BAD=100`、末行 `ERR=02`、LED=`2`、停 `ST_ERR` 不挂死）。⑤ **文档**：interface_spec 新增 **§3.8**（`top_stage6` 端口/参数/报告格式）升 v1.13；本清单补 **§2.4.1** M-6/M-7/M-8 上板步骤、**§2.6 第 15–17 条**排查、M-6/M-7/M-8 行改写。回归 **540 项断言 / 18 个 TB 全 PASS**，`check_repo.ps1` → `LAYOUT PASS`。**下一步**：按 §2.4.1 上板跑 M-6/M-7/M-8（需重新综合，报告从 450 变 476 Byte、末行前多一行 `RPT=`）。 |
| 2026-10-02 | **厂商 IP 落库 + 写阶段 9 第一步的 SDRAM 回环顶层（`top_sdram_loopback`）。** ① **IP 落库**：`ip/sdram/`（应用级 `sdram.v` + `global_def.v` + **三个安路加密 `sdr_*.enc.v`** + `sdram.ipc`）+ `ip/pll/`（`sys_pll` / `video_pll`）。加密件按用户决定**随仓库提交**，版权/来源/唯一一处前导行改动都写在该目录 `README.md` 里。② **纠一个复制错误**：例程里**有两个同名 `sdram` 模块** —— `IP/sdram.v` 是引脚级 PHY 外壳（端口 `ras_n/cas_n/dq…`，例程顶层**没用它**、`.al` 里也没登记），`SD/sdram.v` 才是被 `sdram U3(...)` 例化的**应用级控制器**；本仓库只保留后者。③ **新事实：EG4S20 的 SDRAM 是封装内硬核**（`EG_PHY_SDRAM_2M_32`，2M×32 = 8 MB），55 根信号不出引脚 ⇒ **`pin.adc` 不需要也不该有** SDRAM 引脚（厂商例程同样一条都没有，这不是遗漏）。④ **应用侧协议**照例程：写是逐 word `App_wr_en`；读是**延迟应答式**（`Sdr_rd_en` 才是取数时刻）；`Sdr_busy`/`Sdr_init_ref_vld` 在例程里**纯直通、从不参与判断** ⇒ 应用侧只需自负「突发留间隔 + 读写不重叠」。⑤ **新顶层** `platform/anlogic_eg4s20_hx4s20c/rtl/top_sdram_loopback.v`：50 MHz → `sys_pll`（C1=125M 给 SDRAM、C2=125M@180°）；**全部逻辑含 `uart_tx` 跑 125 MHz 单域，刻意不做 CDC**；写图案（`pat_of` 把地址摊到 32 bit）→ 落地等待 → 读回比对 → 发**定长 71 Byte 纯 ASCII 报告**（`SV-SDRAM-LOOP` / `INIT=/LOCK=` / `W=/R=/CAP=/BAD=` / `DONE`，显式 `8'h0D`/`8'h0A`）；两个等待态各挂独立超时（`ERR=01` 初始化超时 / `ERR=02` 读回不齐 / `ERR=03` 数据不一致）。⑥ **`timing.sdc` 加 `derive_clocks`** —— 接了 PLL 不加它，125 MHz 域就没有时钟定义、**STA 会是假通过**。⑦ **`.al` 已登记 7 条新文件并把 `TOP_MODULE` 切到 `top_sdram_loopback`**（回退只需改回 `top_stage5_sector_rd`）。★ **顺带发现一处需要你确认的不一致**：磁盘上的 `safevision.al` 现在只有**阶段 5** 的配置（`TOP_MODULE = top_stage5_sector_rd`，且 `mbr_parser.v` / `top_stage6_fat32_mount.v` **不在设计文件表里**），与"M-10 已用阶段 6 顶层上板验收通过"的记录对不上 —— 应是那次验收后把工程回退成了阶段 5；我这一轮是在这个阶段 5 配置上继续加的。⑧ **本顶层无 TB、进不了回归**（控制器是加密 IP，只能 TD 解密），上板步骤见新增的 **§2.4.2**。回归不变 **540 项 / 18 个 TB 全 PASS**；`check_repo.ps1` → `LAYOUT PASS`；新顶层过 `vlog` 编译检查。**下一步**：TD 重新综合（确认有 `sys_pll`/`sdram`、无 `HDL-8007`）→ 下载 → 采 71 Byte 报告对账 `W=R=CAP=1000 BAD=0000`。 |
| 2026-10-02 | **★ 查明"顶层回退到阶段 5"的真相 + M-6 复采确认（证据同哈希）。** 用户在 21:29:55 又采了一份报告（HEX 1428 B），解码 **476 Byte**，SHA-256 `31A4D727…4E8769` —— **与 20:52 的 `uart_report_m6_20261002_205218_hex.txt` 逐字节相同**，故不重复归档（只在 `evidence/board/INDEX.md` 记一段说明）。**这份复采的价值在于坐实了一件重要的事**：TD 在 **21:25:40–21:26:48** 跑了一次完整流程并生成位流，而 `project/safevision_Runs/syn_1/run.log` 写的是 **`elaborate -top top_stage6_fat32_mount`**、`syn_1/safevision.prj` 里 **`TOP_MODULE = top_stage6_fat32_mount` 且文件表中没有任何 `ip/` 文件**。⇒ ① **板子上跑的是阶段 6–7 设计，SDRAM 回环顶层至今没有被综合过**；② **根因是 TD 运行时用的是【内存里的工程状态】，不是磁盘上的 `.al`** —— 磁盘 `.al` 的 `TOP_MODULE` 当时已被改成 `top_sdram_loopback`，但那个正在运行的 TD 会话（进程 `td`，**19:34:49 启动**）是从更早的状态打开的，根本没读我改过的文件。③ **磁盘 `.al` 从来没保存过阶段 6 的登记**：`top_stage6_fat32_mount.v` / `mbr_parser.v` 是在 GUI 内存会话里加的、**没回写 `.al`**，所以 `.al` 一直是更早的**阶段 5 快照** —— 文档里以前写的"TD 工程已登记新顶层（`TOP_MODULE = top_stage6_fat32_mount`）"**描述的是 GUI 状态而不是工程文件**，属表述错误，已更正（见 `module_registry.md`）。④ **已把磁盘 `.al` 修成完整超集**：补回丢掉的 `mbr_parser.v` / `top_stage6_fat32_mount.v`，加上本轮的 `ip/sdram/` 5 个 + `ip/pll/sys_pll.v` + `rtl/top_sdram_loopback.v`，共 9 条，**每条路径都用 `Test-Path` 验证过存在**。⑤ ⚠ **重要操作提醒**：只要那个 TD 会话还在，**在 GUI 里"保存工程"就会用内存状态覆盖磁盘 `.al`、把本轮 9 条登记全部冲掉**。正确做法见 §2.4.2 步 1（在 GUI 里手动添加这 7 条文件 + 设 `TOP_MODULE`，再保存）或关闭 TD 后重开。⑥ **阶段判定**：阶段 **1–7 板级全部通过**（M-9 / M-10 / M-6 / M-8a），但因 ⑤ 的操作风险，**SDRAM 回环（阶段 9 第一步）尚未上板**。 |
| 2026-10-02 | **★ 阶段 9 首次综合：`.al` 采纳成功，但被 `pin.adc` 的 SD 引脚拦住 —— 已修。** ① **`.al` 生效**：`syn_1/run.log` 里出现 **`elaborate -top top_sdram_loopback`**（此前一直是 `top_stage6_fat32_mount`）⇒ 关闭 TD（选【否】）后重开这条路的办法有效，TD 采纳了修好的 `.al`。② **综合失败的唯一根因**：`pin.adc` 第 56–59 行给 `sd_dclk`/`sd_mosi`/`sd_miso`/`sd_ncs` 指定了引脚，但 `top_sdram_loopback` **没有这些端口**（SDRAM 是封装内硬核，不用 TF 卡）。**TD 对此是报错不是警告**：`USR-8168 ERROR: set_pin_assignment { sd_dclk } {...} in ../../../constraints/pin.adc(56) is not a valid ADC command`（GUI 侧另报 `HDL-1492 Failed to find pin sd_dclk in model top_sdram_loopback`），随后 `PRJ-5013 Run syn_1 failed`。③ **修法**：把 `pin.adc` 明确分成两段 —— **公共 6 条**（`clk`/`rst_n`/`uart_txd`/`led[3:0]`，三个 bring-up 顶层都有，恒定生效）+ **`[SD-ONLY]` 4 条**（只有阶段 5/6 顶层有，用 SDRAM 顶层时必须注释）。这是**厂商自己的惯例**（例程 `pin.adc` 里未用的信号就是 `#` 注释掉的）。★ 好消息：**`read_adc` 是每次 Run 都执行的命令**（日志里可见 `RUN-1002 : start command "read_adc ..."`），所以改完 `.adc` **直接重新综合即可，不用关 TD**。④ **其余告警全是无害的**，不要被吓到：`HDL-5007 concat with unsized literal`（6 条，在厂商 `.enc` 文件内部）、`HDL-5917 Input port ... not connected`（1 条，在 `sdr_as_ram.enc.v` 内部实例上）、以及 4 条 `*.vh will not be compiled since it is not included by any other file`（`top_sdram_loopback` 不 include 任何 `.vh`，自然如此）。⑤ 文档：`constraints/README.md` 新增「`[SD-ONLY]` 开关」整节；本清单 §2.4.2 加步 2 并重排步骤。 |
| 2026-10-02 | **★ 阶段 9 综合跑通、位流已生成；STA 的负余量查明是厂商硬核 PAD 路径，不是我们的逻辑。** ① `pin.adc` 修完后重跑：**`read_adc` 无错**、`elaborate -top top_sdram_loopback`、**place → route → bitgen 全过**，位流 `phy_1/safevision.bit`（629639 B，22:01:24）。② STA（**新证据条目 TC-Q-STA-4**）报 `SWNS -6.826 ns / STNS -297.306 ns / HWNS +0.046 / HTNS 0.000`，**但全局 64 个违例端点恰好 = `clkc[1]→clkc[2]`（-2.787/32）+ `clkc[2]→clkc[1]`（-6.826/32）两组之和** —— 这两组里**没有任何 fabric 寄存器**（**`clkc[2]` 扇出 = 1**，只接 `u_sdram.Clk_sft`），违例"路径"`Logic Level 0`、`cell 100% / net 0%`，起止点是硬核 PAD（`u_sdram/sdram.dq[*]` / `u_sdram/sdram_syn_*.bpad`）。**厂商自己的参考设计报同一个数：`lab_ex4_tf` 的 `final_timing.rpt` = `SWNS -6.565 / STNS -297.430`**。③ **我们能控制的路径组全绿**：`clkc[1]→clkc[1]`（自研 818 端点）**+0.130 ns / 0 违例**、Min Period 7.870 ⇒ **Fmax 127.065 MHz**；`clk→clkc[1]` +1.232、`clk→clk` +18.390；Hold +0.046 / 0 违例；`Period Check WNS 0.000`。④ **自己的遗留薄点**：最差 fabric 路径只有 **+0.130 ns**，出在 `top_sdram_loopback.v` 的 `rpt_vec[8*(RPT_LEN-1-rpt_sel) +: 8]`（568 bit 向量变址选取，`Logic Level 7` 含 `ADDER=2`、扇出 39、net 62%）—— 能过但薄，以后再动这个顶层要重看（可选优化：把报告按段拆成小 case，或改成倒计数索引以去掉减法器）。⑤ **判定口径已写进项目规则 §7 最后一条**：全局 SWNS 为负时，先看 Clock Summary 的**扇出与分组**，再看违例是否落进"我们自己的组"，最后拿厂商参考设计对表；**不急着加 `set_false_path` 刷绿**。⑥ 证据：`evidence/reports/sta_sdram_loopback_20261002_2201_excerpt.txt`（节选 11902 B），索引条目 **TC-Q-STA-4**。**下一步：下载上板**（预期报告头 `SV-SDRAM-LOOP`，`W=R=CAP=1000 BAD=0000`）。 |
| 2026-10-02 | **★★★ 阶段 9 第一步通过（M-11）—— 厂商 SDRAM 硬核在本工程里跑通了。** 位流 22:01:24 下载后 UART 收到 **71 Byte**（HEX 导出），解码后与设计值**一字不差**：`SV-SDRAM-LOOP` + CRLF / `INIT=01 LOCK=01` + CRLF / **`W=1000 R=1000 CAP=1000 BAD=0000`** + CRLF / `DONE` + CRLF；**真 CRLF**、**无前导 `0x00`**。逐项含义：`INIT=01` ⇒ `Sdr_init_done` 在 16 ms 超时窗内到齐；**`LOCK=01` ⇒ `sys_pll` 锁定成功 —— ★ 这顺带证伪了我上一轮提的那个担心**（顶层把 `sys_pll` 的 C0 留空会不会破坏 `FEEDBK_PATH=CLKC0_EXT` 的反馈支路；实测没问题，例程的音频 PLL 也是这么留空的）；`W=R=CAP=1000` ⇒ 写了 4096 word、发了 4096 次读命令、**收齐 4096 word**（说明控制器一条读命令都没丢）；**`BAD=0000` ⇒ 32 bit 数据逐字比对零错**。⇒ 加密 SDRAM 控制器能初始化、能写、能按序读回；**32 位数据线与 16 KB 连续区间的地址译码全部正确**（图案 `pat_of` 把地址摊到 4 个字节，所以这 4096 个值覆盖了全部 32 根数据线）。★ **本轮一并解决的四件事**：① `.al` 的"磁盘快照 ≠ TD 内存状态"（关 TD 选【否】再重开才生效，判定只信 `run.log` 的 `elaborate -top`）；② `pin.adc` 的 `[SD-ONLY]` 开关（TD 对顶层不存在的端口**报错**；`read_adc` 每次 Run 都执行，改完直接重综合）；③ STA 全局 SWNS 为负的**判定口径**（100% 出在硬核 PAD 路径，自研组全绿，厂商参考设计同数）；④ 顺带发现自己的薄点（fabric 最差路径仅 +0.130 ns，出在 `rpt_vec` 变址选取）。**证据**：`evidence/board/uart_report_sdram_loopback_20261002_221625_hex.txt`，条目 **M-11-PASS**。**下一步候选**：`ADDR_SHIFT=11 + TEST_WORDS=1024` 做全片稀疏扫描（覆盖行/体译码）/ M-7 多卡 / M-8 连读中途拔卡 / 把 SDRAM 接进帧缓存链（阶段 10–16，须等 A 的整机）。 |
| 2026-10-03 | **★ 系统 PLL 去重：A 的 `sv_system_pll` 收编 B 的 `sys_pll`，删除 `sys_pll.*`。** 两套 PLL 频率相同（100/125 MHz），只差电气参数（A: Medium/13/4；B: High/29/2）与 B 独有的 C2 = 125 MHz@180°。做法：**在 A 的 `sv_system_pll` 上加 C2@180°**（`CLKC2_DIV 8` / `CPHASE 3` / `FPHASE 0`；`.ipc` 加 id=2），**C0/C1 电气参数取 A 的不动**；`top_sdram_loopback` 实例化改 `sv_system_pll`；`safevision.al` 登记 `../ip/pll/sv_system_pll.v`；删除 `ip/pll/sys_pll.v` / `.ipc`。`check_pll_profiles.py` 放宽为「按 `CLKC2_DIV` 是否有来定输出集合 + 系统 PLL 的 C2 允许 180°」（0° 判据与原文逐字等价）⇒ 实跑 `PASS`。回归 **540 项 / 18 个 TB 全 PASS**、`LAYOUT PASS`。★ **已重新综合 + 复测（2026-10-03 17:26:55）通过**：报文与 M-11 **逐字节相同**（71 Byte、`INIT=01 LOCK=01 / W=1000 R=1000 CAP=1000 BAD=0000 / DONE`），证据条目 **M-11-PASS-2** ⇒ 去重未改变 SDRAM 回环行为。 |
| 2026-10-03 | **阶段 10 板级 bring-up 首轮结果 + 三轮突发协议探索（补记）。** 新顶层 `top_stage10_framebuffer`（`framebuffer_loopback_core` + `sdram_app_adapter` + 厂商 `sdram`）上板后：**寻址/读/写通路已通**（帧前 2 word = `59C3ACE1`/`670FB387`，与核心 LFSR 逐步推算完全一致；连续 4 地址自检 `SC` 四个值全对），但**整帧仍有 ≈3/4 像素系统错位**（`RD=04B000 BAD=038400`、`BF=00000A`）。期间用"改一次自检 → 烧一次板"的方式把厂商 App 口的突发协议试清楚了（**这一层是加密 IP，只能板上验**）：① 写/读各只拉 1 拍使能 ⇒ 读回**全 FF**（厂商要 ≥2 拍）；② 同址连发 ⇒ 能写进去但**相邻地址互相覆盖**（写 4 个值读回全是最后写入值 / `SC=44444444 ×4`）；③ 大跨步读回全对、改成"地址每拍 +1"后 4 个值全对（`SC=1111 2222 3333 4444`）⇒ **厂商 app 口在连发时地址每拍自增**（M-11 正是每拍 +1 才对的）。据此把适配器改成"突发桥"：写侧攒 `WB=16` 字成一段突发、读侧预取 `RB=16` 字再顺序供给。★ **证据状态**：本轮 11 份串口采集（HEX 导出，纯 ASCII）目前只在**工作区根目录** `Serial Debug 2026-10-03 *.txt`（不在 `.gitignore` 白名单内、不会进仓库），`evidence/board/` 尚无阶段 10 条目 —— **待补留证**。 |
| 2026-10-03 | **★ 把定位用的「地址斜坡探针」加进核心，取代旧的固定图案自检（回归 549 → 551）。** 动机：`BAD=038400` 恰为帧总 word 数 153600 的**精确 3/4**、而 `BF=00000A` 与"从 word 0 开始的周期 4"自相矛盾 ⇒ 单点索引不足以定位。改法（`framebuffer_loopback_core.v` 的 `S_RAMP`）：**写进去的值 = 它自己的字地址** ⇒ 回读值直接就是"这份数据当初被写在哪个地址"，一次上板读出**错位量 / 步长 / 丢没丢**。① 探针 A：字节 `0x4000`（字 `0x1000`，16 对齐）起连续写 **32** 个 word（正好两段 16 字写突发）、顺序读回 **16** 个；② 探针 B：字节 `0x40D4`（字 `0x1035`，**≠16 对齐**）起写 **4** 个、读回 **4** 个（区分"整段偏移"与"突发边界/漏斗式缓冲"）。报告 **149 → 354 Byte**（删 `SC=`，加 `A0..AF=` / `B0..B3=`），**报告索引改倒计数**（`rpt_vec[8*rpt_idx +: 8]`、9 位、从 353 递减）以**去掉索引里的减法器**（上一版 `RPT_LEN-1-rpt_sel` 的加法器曾被 STA 点名为最薄路径）。探针全程加**无进展看门狗**（`mem_error` 或连续 1e6 拍无 `ready`/`rdata_valid` ⇒ `ERR=06`）⇒ 探针挂住也**有界出报告**，不再出现"LED 停 1、什么也收不到"。★ **接口 / 地址表 / 错误码一字未改**。`tb_framebuffer_loopback_core.sv` 9 → **11 项**（新增 T10「探针写值 = 字地址（36 word）」、T11「探针段内地址严格连续且两段基址 = 0x1000 / 0x1035」）⇒ 回归 **551 项 / 19 个 TB 全 PASS**，`check_repo.ps1` → `LAYOUT PASS`。**待办**：TD 重新综合（**并复查 STA** —— 报告向量 1192 → 2832 bit，`rpt_vec` 变址选择是历史最薄路径）→ 下载 → 按 §2.5 步 7 对账 `A/B` 两行。 |
| 2026-10-03 | **★★★ 阶段 10 定案：地址斜坡探针一次性查出根因，并完成两处修复（回归 551 → 557）。** ① **探针判决（354 Byte 版报文，ID 195845）**：`A0..A3=1000 1001 1002 1003` 对、**`A4..AF` 又重复回这 4 个值**，而 `B0..B3=1035..1038` 全对（B 只读 4 个）⇒ **一次连续读突发里读地址只推进 4 个字就回绕**；`BAD=038400` 恰为帧总 word 数 153600 的**精确 3/4**（每 4 个读回只对 1 个）与探针完全吻合；`W0/W1` 仍与核心 LFSR 逐步推算一致 ⇒ 写侧数据与前 2 word 的读通路正常。② **根因**：厂商 app 口**唯一被实物验证可行**的形态是 M-11 的"**`App_*_en` 连发 + `App_*_addr` 每拍自增 + 突发间静默 + 读侧 1:1 收响应**"，而 `sdram_app_adapter` 上一版把**读预取的地址推进挂在 `Sdr_rd_en` 上**（应答延迟窗内地址"钉住"不前进）。**读引擎已按 M-11 重写**（发命令/收响应两条独立计数 + 1:1 配对 + `RB_GAP=16` 静默），写引擎本就是该形态故未改。③ **适配器首次进回归**：`sdram_app_adapter.v` 加入 `$RTL`，新增 `tb_sdram_app_adapter.sv`（**6 项**，TB 内建"厂商 app 口模型"：en 连发时每拍采样地址、每拍一条读命令、延迟 `RD_LAT` 拍按 1:1 返回）⇒ 守住"**连发期间地址必须每拍自增**"这条约束，**旧版适配器过不了 D4/D5**。★ 该 TB 顺带记下三类"TB 自己的握手坑"：阻塞赋值后同 delta 读组合 `ready`、`while(!rdy)` 遇 X 误判、以及**在 negedge 而非握手上升沿撤 `req`**（前者丢握手、后者让同一字被写两遍）—— 实测把"每字写两遍"和"只写 16 却读 32"都踩了一遍，最后靠打印 `mem` 与回读值对比（`read == mem` 完全一致）把嫌疑锁回 TB。④ **报告瘦身（同轮修 STA）**：探针 A 删掉 512 个回读寄存器，改**边读边比对**只报 `AM`（32 位匹配位图）/`AF`（首个不符序号）/`AV`（该处回读值）；新增**探针 C**（非零偏移 4 字，**用来区分"写错/读错"**）；C/B 各只报低 16 位 ⇒ 报告 **354 → 208 Byte**、向量 **2832 → 1664 bit**、报告寄存器 **640 → 199 个**。**动因**：354 Byte 那版把自研组 `clkc[1]→clkc[1]` 从 **+0.030 ns 打到 −1.083 ns / 475 个违例端点**（最差路径全在 `ra_reg → rpt_vec 选择 → u_uart_tx/shifter`；对比 report13 = +0.030 ns / 0 违例 / 3023 端点，report14 = −1.083 ns / 475 违例 / 4445 端点）。⑤ **对外接口 / 地址表 / 错误码一字未改**；回归 **557 项断言 / 20 个 TB 全 PASS**，`check_repo.ps1` → `LAYOUT PASS`。**待办**：TD 重新综合（**必须复查自研组 SWNS ≥ 0**）→ 下载 → 按 §2.5 步 7 对账（期望 `BAD=000000`、`AM=FFFFFFFF`、`AF=FF`、`C0..C3=1004..1007`、`B0..B3=1035..1038`）。 |

| 2026-10-03 | **★ 第 3 轮：读侧修复在板上得到验证 + 修掉我自己引入的一处死锁与 STA 最差路径（回归 557 → 558）。** ① **板上报文（208 Byte，ID 205358）= 读侧根因根治的铁证**：`AM=FFFFFFFF`（**32 个回读全对，且跨了两次预取**）、`AF=FF`、`AV=00000000`、`C0=1004 C1=1005 C2=1006 C3=1007`（探针 C ⇒ 写侧正常）—— 对比第 2 轮的"每 4 个字回绕一次"，读引擎按 M-11 重写是有效的。② **同一条报文暴露新死锁（我引入的）**：`B0..B3=0000` 且 `WR=000000 CRC=00 SV=00`。原因：探针 B 要读 `0x1035`，而那时缓冲里还留着探针 C 只取了 4 个、**剩 12 个**的字 ⇒ 上一版预取触发条件含 `rcnt==0` ⇒ "**跳到缓冲外地址但缓冲没排空**"永不重预取 ⇒ 永久死等 ⇒ 探针无进展看门狗 1e6 拍后 `ERR=06` 直接出报告，**B 与整帧写入全被跳过**（同一 bug 也会在整帧读的第一笔发作：帧从 word 0 起、缓冲里还是探针区数据）。**修法**：触发条件去掉 `rcnt==0`（未命中即可重预取）。③ **STA 三版对比**：report13（我改前）**+0.030 ns / 0 违例 / 3023 端点** → report14（354 Byte 报告 + 512 回读寄存器）**−1.083 / 475 / 4445** → report15（208 Byte 报告）**−1.562 / 312 / 3691**。⇒ 报告瘦身**确实把端点与违例数压下来了**，但**最差路径换人了**：变成适配器自己的 `rbase + rhead` 32 位加法器（`Logic Level 7` 含 `ADDER=2`）经 `ready` 一路进核内状态机（`u_core/bw[*].ce`，net 占 53%）。**修法**：命中判据用寄存器 `rexp`（下一个待供给字的地址）替换 `rbase+rhead`（**去掉加法器**）+ 读侧 `ready` 改**寄存器输出 `r_go`**（`r_go <= r_serve && !r_go`；供给提交挂在 `r_go` 上）⇒ 长组合路径切成两段；**写侧 ready 不经过它，写握手时序不变**。④ `tb_sdram_app_adapter.sv` 6 → **7 项**：新增 **D7「缓冲没排空时跳到缓冲外地址」** —— 正是上一版 TB 能过、板上暴露的场景（TB 之前那两段读都是"缓冲恰好排空后才跳"，所以没抓到）。⑤ **对外接口 / 地址表 / 错误码一字未改**；回归 **558 项 / 20 个 TB 全 PASS**。**待办**：TD 重新综合（**必须确认自研组 SWNS ≥ 0**）→ 下载 → 期望 `WR=04B000 CRC=01 SV=01`、`RD=04B000 BAD=000000`、`AM=FFFFFFFF`、`AF=FF`、`C0..C3=1004..1007`、`B0..B3=1035..1038`。 |

| 2026-10-03 | **★★★ 阶段 10 帧缓存回环「板上验收通过」+ 收时序（回归 558 不变）。** ① **验收报文（208 Byte，ID 211030）全部判据一次通过**：`INIT=01` / `WR=04B000 CRC=01 SV=01` / **`RD=04B000 BAD=000000`**（整帧 307200 像素逐像素零错）/ `W0=59C3ACE1 W1=670FB387` / **`AM=FFFFFFFF AF=FF AV=00000000`** / **`C0..C3=1004..1007`** / **`B0..B3=1035..1038`** / `BF=000000` / `DONE` ⇒ **从"整帧 3/4 像素错"到零错闭环完成**（根因由地址斜坡探针定案、适配器读引擎按 M-11 重写；中途自引入的死锁也一并修掉并有 TB 用例守着）。② **STA 四版记分**（自研组 `clkc[1]→clkc[1]`）：report13（我改前）**+0.030 / 0 违例 / 3023 端点** → report14 **−1.083 / 475 / 4445** → report15 **−1.562 / 312 / 3691** → **report16 −0.992 / 31 / 3709**。⇒ 违例端点 475 → **31**，只差最后约 1 ns；最差路径已从"报告 mux / 适配器加法器"移到 `u_core/st → amask/bw 的变址译码 → 报告寄存器 CE`（`bw[0]_b1[15]` 这条网单独占 2.9 ns、net 占整条路径 76%）。③ **本轮改动（`framebuffer_loopback_core.v`，为收时序）：回读结果收集由"变址写数组"改成"纯移位"** —— `amask` 每比对完一个 A 段回读就右移一位把结果塞进最高位（32 次后 bit0..bit31 = 第 1..32 个的匹配结果，顺序不变）；`cwq`/`bwq` 每收一个 word 左移 16 位把新值塞进低半（4 次后 {C0..C3} 依次落在 [63:48]/[47:32]/[31:16]/[15:0]）。⇒ 32 路/4 路译码器及其高扇出网一起消失；报告侧改读固定位段，**报告字节流逐字节不变**（`tb_framebuffer_loopback_core` 的 T9 逐字节断言守住）。④ 回归 **558 项 / 20 个 TB 全 PASS**（本机实跑）。**待办**：TD 复算（确认自研组 SWNS ≥ 0）；若仍差一点点，下一根杠杆是把报告 mux 按段拆成小 case（文档里早有记录）。**证据待归档**：`Serial Debug 2026-10-03 211030.txt`（208 Byte 报文）应存进 `evidence/board/` 并在 `INDEX.md` 记一条。 |
| 2026-10-03 | **★ 阶段 10 帧缓存回环：核心仿真通过，板级顶层已写（未综合上板）。** 新增 `rtl/memory/framebuffer_loopback_core.v`（写相 `frame_writer` 直连 `mem_ctrl`、读相 `video_read_dma` 经新写的 `rtl/memory/mem_read_burst.v`）+ 板级 `sdram_app_adapter.v` / `top_stage10_framebuffer.v`。核心 TB `tb_framebuffer_loopback_core.sv` **9/9 PASS**（整帧 640×480 写 → 整帧读回 → 逐像素零错、报告 73 Byte 逐字节），回归 **540 → 549 项 / 18 → 19 个 TB 全 PASS**、`LAYOUT PASS`。★ **两条踩坑（都已修并留档）**：① 厂商 `sdram` 应用口是**脉冲式**（`App_wr_en`/`App_rd_en`/`Sdr_rd_en`），与 `mem_ctrl` 的通用 req/ready 口协议不同，中间必须有 `sdram_app_adapter`；② **`memory_arbiter` 读通道按"`ready` 与 `data_valid` 同拍"设计**，直接接 `mem_ctrl`/`frame_memory_model` 会**每 16 word 突发少收 1 拍**（读方永久等待）——改用 `mem_read_burst`（一次 1 个在途请求），仲裁器读路径留给阶段 13。③ **`frame_address_gen.v` 原本没写 `` `include ``**：TD 按文件独立编译、**不共享宏**，于是 `SV_FRAME_WIDTH` 未定义、分析失败（`HDL-8007`/`PRJ-8644`）——**ModelSim 因把一次 `vlog` 的所有文件当同一编译单元、宏跨文件可见，把这颗雷盖住了**（`run_sim.ps1` 一直全绿也看不出来）。已给 `frame_address_gen.v` 补 `` `include "safevision_defs.vh" ``。教训：**每个 `.v` 必须自带它用到的头文件**，别依赖"别的文件先 include 过"。④ 核心的超时参数原写成 `20_000_000`/`40_000_000`，**超过 24 bit**（`2^24-1=16_777_215`）被截断，已改为 `16_000_000`。⑤ **首次综合后 STA 抓到自研 fabric 的时序违例**：`clkc[1]→clkc[1]` **SWNS −2.579 ns / 45 个违例端点**（把 512 深 FIFO 的**组合读** → 16bit 比较 → 19bit 累加 → CE 串成 9 级 / 10.3 ns）；已把自检器改成 **3 级流水**（FIFO 组合读只到寄存器，比较与累加各占一拍）。★ **全局 `SWNS −6.826 ns` 仍是 SDRAM 硬核 PAD 路径**（`clkc[1]↔clkc[2]`、`clkc[2]` 扇出=1），与 stage 9 的 **TC-Q-STA-4 同一个数**、和厂商参考设计对得上 —— **判定口径照旧：只看自研组**（`clkc[1]→clkc[1]` 应为 0 违例）。⑥ 第二次综合后自研组仍剩 **−1.019 ns / 4 端点**（`rd_ptr` 扇出 **513** 的 FIFO 组合读、以及 `y*640` 被综合成 **MULT18** 乘法阵列），继续压：**像素 FIFO 深度 512→128**（读地址扇出与 mux 变浅）+ **`frame_address_gen` 把 `y*640` 改写为移位相加**（640 = 2⁹+2⁷，逐值等价）。★ 改深度时踩到一个坑：`sync_fifo` 的 `data_count` 位宽 = `$clog2(DEPTH)+1`，**深度一改位宽就变**，接线位宽不匹配会把高位悬空（仿真里是 `Z`）⇒ 水位比较变 X、DMA 永不发起；已改成"位宽随深度 + 零扩展"。⑦ **上板调试定论：厂商 app 口是"每拍地址自增"的突发流**——三轮实验：①"写/读只拉 1 拍"⇒ 全 FF；②"同址连发 HOLD 拍"⇒ `SCR=DEADBEEF` 但**相邻地址互相覆盖**（向 4 个连续 word 写 1111/2222/3333/4444，读回全是 44444444）；③改成 1KB 大跨步后 4 个值**全对** ⇒ 唯一自洽解释：**连发时地址每拍自增**（M-11 也正是每拍 +1 才对的）。⇒ **`sdram_app_adapter` 重写为"突发桥"**：写侧攒 `WB=16` 字成一段突发（`App_wr_en` 连发、地址每拍 +1、数据逐拍送）、读侧预取 `RB=16` 字再顺序供给。自检扩成"4 个**连续** word 写不同值读回"（报告新行 `SC=…`，报文 **138 Byte**）。回归 **549 项全 PASS**；适配器**不进仿真**（依赖加密 IP），只能板上验证。**下一步**：重新综合 → 下载 → 采 **138 Byte** 对账。 |
| 2026-10-03 | **★ report17 复算后：自研组 −0.386 ns / 6 违例端点；本轮把报告 mux 改成两级 + 块寄存器（回归 558 不变）+ 归档阶段 10 板级证据。** ① **TD 复算（report17，顶层 `top_stage10_framebuffer`）**：全局 `SWNS -6.826 / STNS -302.334`（仍是硬核 PAD 组，与 stage 9 同数，正常）；**自研组 `clkc[1]→clkc[1]` = −0.386 ns / 6 违例端点 / 3676 端点，Fmax 119.246 MHz**（report16 是 −0.992 / 31 / 3709）⇒ "回读收集改纯移位"这一刀把违例端点从 **31 收到 6**。**最差路径换人了**：`u_core/rpt_idx[3] → rpt_vec 变址 mux → u_uart_tx/shifter_reg[0]`（数据路径 8.106 ns、**net 占 71%**、`rpt_idx[4]` 扇出 **47**）；6 条违例里 **4 条终止在 `u_uart_tx/shifter_reg`**（另 2 条是 `bad_px` / `bwq` 经同一报告 mux），只有 1 条（`u_fw/px_cnt[17] → lo_pix[15].ce`，−0.047 ns）与报告无关。② **本轮改动（`framebuffer_loopback_core.v`）**：把 208 Byte 报告 mux 从"1664 bit 向量 + 变址选取"改成 **13 块 × 16 Byte 两级 mux + 一块 16 Byte 的块寄存器 `blk_q`**（第 1 级 13:1×128bit → `blk_q`；第 2 级 16:1×8bit → `rep_data`）。块寄存器把"大 mux → 跨芯片送 uart_tx"这条长走线**切在中间**，第 2 级只剩一个窄 mux。★ **逐字节等价**：`rpt_idx` 逐字节递减 ⇒ 同块内 `rpt_idx[8:4]` 恒定；`blk_q` 与 `rpt_idx` **在同一个时钟边沿更新**（装"下一字节"所在的块），所以**恒 ready（TB `rep_ready=1'b1`、报告逐拍流出）也正确**，不需要额外的 priming 拍。★ **踩了一个坑并已修**：块 mux 的位偏移必须按 **128 位/块** 步进（`{k, 7'b0}`），第一版误写成 `{k, 4'b0000}`（= k×16 **位**）⇒ 回归 **T9 逐字节断言立刻 FAIL**（而 T8 的"208 Byte"计数仍是对的）—— **这正是"报告通路必须逐字节断言、不能只数长度"的价值**。③ **接口 / 地址表 / 错误码一字未改**；回归 **558 项断言 / 20 个 TB 全 PASS**（本机实跑）、`check_repo.ps1` → `LAYOUT PASS`。④ **证据归档（交接 §8B 完成）**：`evidence/board/` 新增 3 条 —— **STAGE10-PASS**（`211030`，208 B，验收报文）、**STAGE10-DEADLOCK-208B**（`205358`，208 B，暴露死锁那轮）、**STAGE10-RAMP-354B**（`195845`，354 B，定案那轮）；文件名 `uart_report_stage10_fb_loopback_<时间戳>_hex.txt`，`INDEX.md` 各记 **HEX 与解码后双 SHA-256**，并补了一节"阶段 10 三份采集的来源与去留"（说明为何其余 11 份不入库、原件仍留工作区根目录）。**待办**：TD 再复算一次，确认自研组 SWNS ≥ 0。 |
| 2026-10-03 | **★★ report18 复算：自研组 −0.081 ns / 2 违例端点（只差 0.081 ns）；再收一刀 —— 块号改成寄存器 `blk_nxt`。** ① **TD 复算（report18）**：全局 `SWNS -6.826 / STNS -296.581`（仍是硬核 PAD 组，正常）；**自研组 `clkc[1]→clkc[1]` = −0.081 ns / 2 违例端点 / 3948 端点**（report17 是 −0.386 / 6 / 3676）⇒ 报告 mux 两级化这一刀把**报告通路那 4 条违例全干掉了**，违例端点 6 → **2**，且都只剩 −0.08 ns。② **剩下的 2 条违例是同一个根因，而且是上一刀自己带进来的**：路径 = `rpt_idx → 9 位减法器（4 级 ADDER，共 0.92 ns）→ net rpt_dn[5]（**扇出 195**，1.73 ns）→ 块 mux → blk_q`。那个 `rpt_dn = rpt_idx - 9'd1` 本来**只给状态机算下一个索引**，却被综合塞进了**块 mux 的选择端**，于是"9 位借位链 + 195 扇出的长网"全压在关键路径上（数据路径 7.801 ns，net 占 64%）。③ **改法（`framebuffer_loopback_core.v`）**：把块号**提前一拍算好、存进 5 位寄存器 `blk_nxt`**（恒等于 `block(rpt_idx-1)`，只在"下一字节正好跨块"即 `rpt_idx[3:0]==1` 时 -1）。⇒ 关键路径变成 `blk_nxt（寄存器）→ 块 mux → blk_q`；**减法器退回成只喂 5 个 bit 的轻负载路径**（`rpt_idx → 5 位条件减法 → blk_nxt`）。★ **仍是逐字节等价**：`blk_nxt` 与 `blk_q` 在同一个时钟边沿更新，恒 ready（TB `rep_ready=1'b1`）下也正确。④ **接口 / 地址表 / 错误码一字未改**；回归 **558 项 / 20 个 TB 全 PASS**、`check_repo.ps1` → `LAYOUT PASS`。**待办**：TD 复算（report19）确认自研组 SWNS ≥ 0；若仍差，下一根杠杆 = 块宽 16 Byte → 8 Byte（选择扇出减半）。 |
| 2026-10-03 | **★★ report19：块 mux 那一刀成功（−0.081 → +0.058 ns），但最差路径换到适配器；决定"收手"，转推进整机集成。** ① **report19（TD 复算）**：自研组 `clkc[1]→clkc[1]` = **−0.218 ns / 3 违例端点 / 3982 端点**（report18 是 −0.081 / 2 / 3948）。② **第 3 刀本身是成功的**：块 mux 路径已从 −0.081 ns 变成 **+0.058 ns（通过）**，`blk_nxt` 那条路径（`blk_nxt → 块 mux → blk_q`）确实把 9 位减法器移出了关键路径。③ **但最差换人了**：现在是 `u_adapter` 的**突发基址 / 读命令计数**通路（`rfbase` / `wbase` / `addr[17]` / `rcmd_i`，`sdram_app_adapter.v` 44/106/124 行），**−0.218 ns / 数据路径 7.938 ns / net 占 69% / 扇出 51**（2 个端点）；第 3 条是 `ramp_to → ramp_addr[17].ce` **−0.029 ns**（探针地址寄存器 CE 的 24 位比较器）。⇒ 自研组现在**约 10 条路径挤在 0.25 ns 以内**，是"已跑到预算 99%"的典型形态（修好一条、最差换另一条）。④ **决策：就此收手，不再为这个顶层做 RTL 微调。** 理由：**(a) 这个顶层不会交付** —— `top_stage10_framebuffer` 是 B 侧的 **bring-up 自测顶层**（产品顶层是 A 的 `safevision_top`），`framebuffer_loopback_core` 也是自测夹具而非产品数据通路，整机集成后布局布线完全不同；**(b)** 剩下两条都是"慢逻辑"（报告序列化在 115200 下每字节隔约 8680 拍；适配器突发基址建立），不是吞吐瓶颈；**(c)** 收益递减：475 → 31 → 6 → 2 → 3，每轮成本 = 一次 TD + 一次全量回归 + 一轮文档同步。⑤ **时序债的还法**：**整机集成后在 A 的顶层上重跑 STA**；若报告通路仍关键 ⇒ 用**有理由的 `set_multicycle_path`**（数据在几千拍内稳定），**不用 `set_false_path` 刷绿**；若适配器通路仍关键 ⇒ 那是要交付的真逻辑，值得单独优化。⑥ **本轮代码保持**（不回退 `blk_nxt`：它修好了自己的目标路径，且结构上更正确；report19 的数值变差来自布局变化，属噪声）。回归 **558 项 / 20 个 TB 全 PASS**、`check_repo.ps1` → `LAYOUT PASS`。**下一步：转整机集成 / 与 A 的联调**（B 侧开发阶段 1–16 已全部落地）。 |
| 2026-10-04 | **★★ 回应 A 的阶段十审查：SDRAM `C1↔C2` 与 PLL `USR-6135` 两条遗留项完成核查；修正判定口径；删除交接文档。** ① **A 的更正我们接受**：旧说法"全局 −6.826 ns 100% 出自硬核 PAD 路径"**不准确** —— 读侧 `C2→C1` 是**纯 PAD↔PAD**（`Logic Level 0`、`cell 100% / net 0%`、扇出 0），写侧 `C1→C2` 的**起点是厂商控制器内部的寄存器**（`u_sdram/u2_ram/u2_wrrd/col_en_reg`，`Logic Level 1 / PAD=1`）；准确说法是"**厂商 SDRAM 控制器与封装内 SDRAM 的接口路径**"。两种说法导出的工程结论相同：**RTL 侧没有可改的自由度**。② **新增一条独立证据**：厂商自己的出货例程 `lab_ex5_i2s` 的 `final_timing.rpt` 里有**同名同结构**的路径组（`sys_pll_m0/pll_inst.clkc[2] → ext_mem_clk`，**SWNS −6.565 / 32 违例端点 / 32 总数**，同 4.000 ns 预算、同 `U3/sdram.dq[*]` 终点、`clkc[2]` 同样未命名且扇出 1），且厂商例程**自己的 fabric 组也有小违例**（−0.144 / 2、−0.127 / 1、−0.998 / 1）⇒ **厂商带着同样的数字出货**。★ 按 A 的标准这只是旁证、**不是豁免依据**。③ **`USR-6135` 找到可检验的差异**：我们 `sv_system_pll` 的 `FEEDBK_MODE/FEEDBK_PATH` 与厂商**完全相同**（`NORMAL` / `CLKC0_EXT`），但我们的 **C0（100 MHz）扇出 = 0（悬空）**，厂商把 C0 当 `sd_card_clk` 用、**扇出 451** ⇒ `CLKC0_EXT` 要求 C0 真的走一条外部（全局）网络绕回 `fbclk`；C0 悬空时反馈无实际负载，工具判 local **有据可依**。这正好解释 A 看到的"物理报告说走了全局资源 / 时序检查仍判 local"的矛盾 —— **两者前提不同**。候选改法 (a) 让 C0 真正带负载 / (b) 改内部反馈模式（必须重验相位）/ (c) 保留现状 + 向厂商确认 —— **B 不单方面改**。④ **判定口径修正**（已同步进项目规则 §7 末条）：先按 `Logic Level` / `cell%·net%` / `Max Fanout` / 起止点判**物理归属**，分"纯 PAD↔PAD"、"厂商控制器寄存器→PAD"、"fabric 组"三类；**fabric 组必须修**；**"厂商参考设计同数"不能单独作豁免依据**，豁免至少要有"路径结构证据 + 实物证据 + 厂商说明"里的两样；**不许 `set_false_path` 刷绿**，确需放宽用**有理由的 `set_multicycle_path`**。⑤ **新增文档** `docs/B链-SDRAM接口与PLL时序核查.md`（事实 / 厂商对照 / 实物证据 / 候选改法 / 口径修正），并在 §三 置顶两条遗留项。⑥ **删除 `docs/B链-交接-给下一位Agent.md`**（用户决定：不再交接给下一位、由同一会话持续负责；项目规则 §8 已改写为自给自足的"当前状态锚点"）。⑦ **本轮无 RTL 改动**，回归仍 558 项全 PASS。 |
| 2026-10-04 | **★★ 续：找到 SDRAM 负余量的"决定性证据"（硬核 I/O 模型常数 5.000 ns），并厘清"什么能改、什么改不了"。** ① **把两条违例的 `Delay Type` 数据路径逐行拉出来**（`report19.txt`）：**读侧** `C2→C1` 只有两项 —— `input (hard ip)` **5.000 ns**（**整数常数**）+ `net 0.000 ns`（扇出 0）+ 内部捕获寄存器 `PAD (reg)` 1.453 ns = 6.453 ns；**写侧** `C1→C2` 则是 `output (hard ip)` **−5.000 ns** 把要求时间从 11.287 压到 6.287 ns（到达 9.074）⇒ `−2.787 ns`。★ **含义**：`5.000 ns` 是 `EG_PHY_SDRAM_2M_32` 硬核**库模型里的固定 I/O 延迟**（真实 pad 延迟不会正好整数 5 ns、更不会读写同值反号）；而 budget 只有 **4.000 ns**（因 C2 相对 C1 移相 180°）⇒ **光这一个常数就超过 budget，数学上不可能靠改 RTL 收敛**。② **厘清"能改 / 改不了"的分界线是「明文源码 vs 加密/硬核」，不是「官方 vs 我们的」**：可改 = 厂商例程 top / SD 控制器 / HDMI / PLL wrapper / SDC / 我们复制进来的 `ip/sdram/sdram.v`（**只有 2979 B，通篇只有两个实例化**）；**改不了 = `sdr_as_ram.enc.v` / `sdr_wrrd.enc.v` / `sdr_init_ref.enc.v`（真正的控制器逻辑）+ `EG_PHY_SDRAM_2M_32` + `EG_PHY_PLL` 硬核**。★ 两条违例路径的落点已确证在加密件里：读侧 net 名 `u_sdram/u2_ram/SDRAM_CLK` 来自 **`sdr_as_ram.enc.v`**，写侧起点 `u2_ram/u2_wrrd/col_en_reg` 的 `u2_wrrd` 在 **`sdr_wrrd.enc.v`**。③ **另确认"没有明文旋钮"**：我们与厂商的 `sdram.ipc` **逐字节相同**，内容只有 `Type/Device/create_VHDL/inst` —— **没有 CAS 延迟 / 相位 / 驱动强度等可调项**。④ **决策（回答"先做 M-11 还是先与 A 协商"）**：**并行、互不阻塞** —— M-11 全片稀疏扫描 / soak / 扩展图案**现在就做**（纯 B 侧、不碰 A 的时钟契约、且正是 A 要的实物证据）；同时**向 A 问 PLL `C0` 负载方案**、**向厂商问那个 5.000 ns 常数与 4 ns budget 是否为正确检查方式**（这是唯一能把问题真正关掉的路径）。★ 但要说清 **M-11 的效力边界**：它是单板单温度点证据，**不能单独关掉这条负余量**。⑤ **`.gitignore`**：新增 `/docs/SafeVision技术栈详解-零基础版.pdf` 与 `/docs/SafeVision技术栈详解.html` 两条忽略（用户决定这两份本地生成的讲解材料不进仓库，已验证 `git check-ignore` 生效）。⑥ 网络：代理 502 已消失，但 `git fetch origin` 现在报 `could not read Username`（私有仓库 + 非交互 shell 无法输入凭据）⇒ **A 的 `docs/A_stage10_latency.md` 仍取不到**，需用户在本地 `git fetch` 或由 A 提供正文。⑦ 本轮仍无 RTL 改动，回归 558 不变。 |
| 2026-10-04 | **★ 做 M-11 补测「全片稀疏扫描」：修掉一个"看起来在测、其实几乎没测"的真问题；报告扩到 136 Byte（自描述 + 首个错点）；图案生成抽成可仿真模块 + TB（回归 558 → 569）。** ① **发现并修掉一个真问题**：原 `top_sdram_loopback.v` 里的 `pat_of` **只用了 `a[11:4]` 与 `a[7:0]`**，而稀疏扫描的被测地址是 `a = k<<11`（a[10:0] 恒为 0、a[11:4] 只剩最低位有值）⇒ **1024 个测试点只可能得到 2 种图案（按 k 的奇偶）**，"全片扫描"几乎什么都证明不了。★ 这类错误**写读自比发现不了**（写侧读侧用同一个函数，错得一样照样 `BAD=0000`）。② **改法**：把图案生成抽成**可仿真**的 `rtl/memory/sdr_pat_gen.v`（无引脚、纯组合），映射改为 `b0=a[7:0]^a[20:16]`、`b1=a[15:8]`、`b2={3'b0,a[20:16]}`、`b3=b0^b1^b2^0xA5` —— **单射**（可由 b1/b2/b0 反解 a[20:0]），且稀疏扫描下 4 个字节各自都在变；新增 `tb_sdr_pat_gen`（**11 项**，含 T7 **反向对照**：把旧公式也算一遍、确认它只有 2 种图案 ⇒ 证明 T1 的判据抓得到那个 bug，即"这个 TB 不是摆设"）。③ **步长改为 `STRIDE = (1<<ADDR_SHIFT) + ADDR_LOWSTEP`**，默认 `11 + 1 = 2049` —— ★ 纯 2 的幂步长会把**低位地址位固定住**（步长 2048 时 a[10:0] 恒为 0），列地址与行低位根本没被激励；加 1 后 `k*2049 = (k<<11)+k` ⇒ **每个地址位都在变**。旧的连续扫描 = `ADDR_SHIFT=0, ADDR_LOWSTEP=1`（步长 1）。④ **报告 71 → 136 Byte**：新增 `CFG=hhx BASE=hhhhhh N=hhhhhh`（**自描述**，采集件自己说明烧的是哪套参数）与 `BAD0=hhhhhh E=hhhhhhhh A=hhhhhhhh`（**首个错点的地址/期望/实际**，`FFFFFF` = 无错）—— 这是"一次烧板拿全部信息"（阶段 10 地址斜坡探针的同一条经验）。⑤ **报告索引改 8 位倒计数**（`rpt_vec[{rpt_idx,3'b0} +: 8]`，从 135 递减）：**不含减法器**，避免重蹈阶段 10 那条 `RPT_LEN-1-idx` 减法器被综合进 mux 选择端的最差路径。⑥ **回归 558 → 569 项 / 20 → 21 个 TB 全 PASS**；`run_sim.ps1` 的 `$RTL/$SIM/$TBS` 三个列表同步。⑦ **待办：重新综合（确认 `elaborate -top top_sdram_loopback`）→ 烧板 → 按 §2.4.2 步 7 对账**（期望 `CFG=0B1 BASE=000000 N=000400` / `W=0400 R=0400 CAP=0400 BAD=0000` / `BAD0=FFFFFF E=00000000 A=00000000`）。★ 这一步的产物正是回应 A 审查所需的**实物证据**（见 `docs/B链-SDRAM接口与PLL时序核查.md` §5.1）。 |
| 2026-10-04 | **★★ 把"不可仿真"的 SDRAM 顶层拉进回归：新增 `vendor_ip_stub` + `tb_top_sdram_loopback`，那份 136 Byte 报告现在**逐字节仿真验证过**（回归 569 → 574）。** ① **动机**：`top_sdram_loopback.v` 例化的两个单元 ModelSim 编译不了（安路 RSA 加密的 `sdr_*.enc.v` + TD 的 `EG_PHY_PLL` 宏），所以它历史上**完全没有 TB**；而本轮刚把报告从 71 → 136 Byte、还改了索引方式 —— **这类改动以前只能烧一次板才知道对不对**。② **做法**：新增 `verification/models/vendor_ip_stub.sv`（**仿真桩**，明确标注"不是厂商行为模型"）顶掉那两个黑盒 —— PLL 桩产生 125 MHz 方波；SDRAM 桩是"理想存储器"（`Sdr_init_done` 很快给 1；读命令延迟 4 拍后按 **1:1** 回一个 `Sdr_rd_en` + 该地址的数据，数据由**同一份 `sdr_pat_gen`** 按地址算出）。新增 `tb_top_sdram_loopback.sv`：自建 125 MHz 采样 UART 8N1 接收模型，断言 **报告恰好 136 Byte** / **逐字节与期望串一致** / **`CFG=0B1 BASE=000000 N=000400`** / **`BAD0=FFFFFF E=00000000 A=00000000`** / **`led=8`**（**5 项**）。③ **顺带把 `top_sdram_loopback.v` 加进 `$RTL`**、桩加进 `$SIM` —— 该顶层**第一次进回归**。④ ★ **踩了一个 TB 自己的坑并记档**：`got` 里"第 0 个收到的字节在最高位"，所以取"流字节 [a..b]"的切片基址要按**末字节 b** 算（`got[8*(135-b) +: 8*(b-a+1)]`），按首字节算会把字节顺序倒过来 —— 表现很迷惑：**整串比对（T2）通过、单行比对（T3/T4）却失败**。先用一个秒级的 scratch 仿真把切片打出来才定位（比反复烧 2.5 分钟的回归快得多）。⑤ ★★ **效力边界（必须记住）**：桩是理想存储器，**不模拟初始化/刷新/CAS/突发窗口/地址每拍自增**，读数据也是按地址算出来的 ⇒ **桩里的 `BAD=0000` 是构造保证的，不是数据完整性证明**。**SDRAM 协议与数据完整性仍然只认 M-11 / 阶段 10 的上板实测。** ⑥ **回归 569 → 574 项 / 21 → 22 个 TB 全 PASS**；`run_sim.ps1` 三个列表同步。 |
| 2026-10-04 | **★ TD 工程文件（`.al`）核对与修正：切回 `top_sdram_loopback` + 补登记 `sdr_pat_gen.v` + 清掉两个会致命的过期 `AutoExcluded`。** 起因：用户问"al 工程会不会回退成昨天的"。核对结果：**内容没有被 GUI 覆盖**（与提交 `3ec72c6` 逐字节一致，没有回退），但有**三处必须修**：① **`TOP_MODULE` 还是 `top_stage10_framebuffer`**（阶段 10 那次留下的）—— 烧 M-11 必须切回 `top_sdram_loopback`；② **新模块 `../../../rtl/memory/sdr_pat_gen.v` 根本没登记** —— ★ 不登记 TD 会把它当**黑盒**，`BAD` 会变得毫无意义（这正是"新增模块必须先登记"那条规则的现实版本）；③ `top_sdram_loopback.v` 与 `ip/sdram/global_def.v` 上还挂着**过期的 `AutoExcluded="true"`**（`TOP=stage10` 时算出来的）—— 对现在的顶层是错的，清掉以免万一被采纳就把整个顶层排除掉。修完校验：**51 条 File 条目、路径全部可达、CompileOrder 无重复**、回环顶层闭包 7 个文件全部无排除标记；`pin.adc` 的 `[SD-ONLY]` 四条**本来就是注释状态**（正合本顶层）⇒ 约束侧无需改动。★ **提醒**：`.al` 只是快照，**必须关掉 TD（选【否】不保存）再重开**才生效；`log/` 与 `.al` 的修改时间是 10:04/10:05 ⇒ **TD 当时很可能正开着**，若从 GUI 保存会覆盖掉本次修改。★ 判定只信 `syn_1/run.log` 的 `elaborate -top`。 |
| 2026-10-05 | **★★★ A+B 显示级集成测试跑通并全绿：`pix_ok=307200  pix_bad=0`（整整一帧逐点全对）。** ① **先说结论**：真 BMP 字节流 → `bmp_parser` → `bmp_unpack` → `frame_writer` → `memory_arbiter` 写 → 真存真取存储 → `memory_arbiter` 读 → **A 的 `a_video_display_core`** → 屏幕像素，**307200 个像素逐点与源 BMP 一致**，换帧握手正常（`swap_err=0`）。入口：**`safevision/tools/run_ab_display_sim.ps1`**（独立脚本，21 秒；已登记进 `run_all.ps1`）。② **★ 中途一度以为发现 RTL bug，最后查明是 TB 自己三个错**（记录以免重犯）：(a) **TB 里重复例化了 `frame_swap_cdc`** —— A 的 `a_video_display_core` **内部已经有一个**，TB 又放一个 ⇒ `fs_evt_b`/`ack_evt_b` **双驱动** ⇒ 换帧 FSM 永远收不到 `frame_start`、超时进 SAFE。★ **这正是本项目 `docs/B链-整机集成-存储侧接线表.md` §5 里写的那条禁忌**（"B 侧不要再例化一份"）—— 我在 TB 里违反了自己写的规则；(b) **`TIMEOUT_N` 给得太小**：给 40000 拍（400 µs），而 A 的 core 在**真实垂直消隐**才回 `frame_start`（一帧约 16.7 ms）⇒ 等不到就超时；改用模块默认 5_000_000 拍（50 ms，注释写明"覆盖一整帧"）；(c) **比对窗口太短**：只等 2000 拍、落在消隐期 ⇒ `pix_ok=0`；改为"画面激活后再跨两整帧"。③ **★ 两个观测手段的教训**：(a) **单周期信号必须用 `always` 数边沿**，1 ms 采样根本看不到（我先前据此下过错误结论）；(b) **层次引用（`u_cdc.fs_sync`）在 vopt 下不可靠** —— 读出来的值与实际驱动 `fs_evt_b` 的那份不一定是同一个 ⇒ **只信 TB 顶层信号**。④ **残留观察（不阻塞）**：`commits=0`（B 侧 `active_commit` 没计到）—— 不影响本 TB 结论，但 `active_commit` 是 `frame_buffer_manager` 的输入，**值得另行确认**。⑤ **回归 618 项 / 24 个 TB 仍全 PASS**（`run_sim.ps1` 不含本 TB）；`run_all.ps1` 现在多一条入口。 |
| 2026-10-04 | **★★★ soak 首轮上板报出自相矛盾的报文；定位到自研组时序违例（−3.591 ns / 90 端点）；已做四级流水修复（仿真验证通过，**待重新综合 + 复测**）。** ① **现象**（`Serial Debug 2026-10-04 111710.txt`，HEX 408 B → 190 B）：`RND=00000002/0006DDD0 PAT=1` / `W=0400 R=0400 CAP=0400 **BAD=0001**` / `TOT=0000000800` / **`BAD0=FFFFFFFF:FFFFFF E=00000000 A=00000000`（无错哨兵）**。★ `RND=2/450000` 说明 `ROUNDS=450000` 确实编译进去了（新代码烧进去了）；但按 RTL 逻辑 `bad_cnt` 自增与 `bad0_set` 置位在**同一拍同一分支**，**`BAD=1` 与 `BAD0` 哨兵不可能同时成立**。② **定位**：(a) 报文确实来自新构建 —— `syn_1/run.log` 有 `elaborate -top top_sdram_loopback` 与 `elaborate module sdr_pat_gen`、`phy_1/final_timing.rpt` 的 Top Model 正确、`.al` 也对 ⇒ **排除"烧了旧位流"**；(b) **仿真里复现不了这个矛盾** —— 带桩 TB 制造"第 2 轮 1 个字不符"时 `bad0_set` 会正确置 1 并给出 `BAD0=2:地址 期望 实际` ⇒ **逻辑本身是对的**；(c) **查布线后 STA 找到真问题**：自研组 `clkc[1]→clkc[1]` = **SWNS −3.591 ns / 90 违例端点 / 1431 端点，Fmax 仅 86.274 MHz**（对比 report17 的 119.246 MHz），**最差路径正是** `cap_cnt[5] → 地址加法 → sdr_pat_gen(mode1 xorshift/mux) → 32 位比较 → bad0_exp[*].ce`（数据路径 **11.311 ns**、Logic Level 8、net 占 66%）。⇒ **`BAD0` 没锁存极可能是这条路径的时序违例所致**，而 `BAD=1` 既可能是真实数据错、也可能是同一违例把比较结果打歪 —— **两种都不能排除**。③ **修复（`top_sdram_loopback.v`）**：把回读比对拆成 **4 级流水** —— Stage0 响应采样（`sdr_rd_en` 时锁 `sample_{addr,mode,data}`、`cap_cnt/tot_cnt++`）→ Stage1 期望图案（由 `sample_*` 经 `sdr_pat_gen` 算，锁进 `expect_pat`）→ Stage2 比较（结果锁进 `cmp_bad`，诊断数据锁进 `cmp_{addr,exp,act}`）→ Stage3 提交（`checked_cnt++`/`bad_cnt++`/首次错写 `bad0_*`）；并把 `ST_RDWAIT` 出口从 `cap_cnt >= TEST_WORDS` 改成 **`checked_cnt >= TEST_WORDS`**（必须等比较流水排空，否则会在流水未完时切 `pat_mode` 或发报告）。④ **验证状态**：回归 **588 项 / 22 个 TB 全 PASS**、`LAYOUT PASS`；`tb_top_sdram_loopback` **8/8**，其中阶段 2 已改成"**第 2 轮 mode 1 注入 1 bit 错**"并断言 `RND=2/3 PAT=1`、`BAD=0001`、`BAD0=00000002:002805 E=64F2D804 A=64F2D805` —— **正好覆盖板上失败的那个场景，仿真里是对的**。⑤ **★ 结论与待办**：**这次 soak 既不算通过、也不能当成"发现了真实存储错误"**；**下一步 = TD 重新综合 + 布线（看自研组 SWNS 是否转正）→ 烧 10 秒版复测**；若再出现 `BAD != 0`，这次 `BAD0` 应能给出定位，按判读表定性。⑥ 交接文档已重建：`docs/B链-交接-给下一位Agent.md`（§1 就是这件事）。 |
| 2026-10-05 | **★ 同步远端（A 交付阶段 11–15）→ 核对 B↔A 接口边界 → 补"整机集成存储侧对接包"（接线表 + 注释订正 + 契约守门 TB）。回归 588 → 604 全 PASS。** ① **远端**：`origin/main` 前进到 `0d878aa`（A 的 `7e6c7d2 Complete A stages 11-15` + `0d878aa` 显示/配置压力回归），`interface_spec.md` 升到 **v1.34** 并新增「**A 阶段11–15补充契约**」（明确列了对 B 的要求）；本地干净、严格落后 2 个提交，已 `merge --ff-only` 同步。② **★ 接口边界核对（结论：14 根线全部对齐、可直连）**：A 的 `rd_*`（7 根）与 B 的 `memory_arbiter` Video Read 口**同名同宽、方向互补、单位一致**（地址 = 逻辑**字节**地址；`rd_len` = **32bit word 数**，集成取值 **64**）⇒ **两侧同在 `mem_clk` 域、不需要同步器**；帧交换口 7 根里 **`frame_swap_cdc` 已由 A 的 `a_video_display_core` 例化**（`:43`），B 侧**不要重复例化**；A 的 `frame_start_evt_b`/`swap_ack_evt_b` **已是边沿检测过的单拍脉冲，不要再转 toggle**。③ **★1 新增 `docs/B链-整机集成-存储侧接线表.md`**（B 对契约的应答）：逐根接线表 + 接线片段 + 时序语义 11 条 + **"不该做什么" 6 条**（每条附真实教训）+ 复位约定（三域各自 `reset_sync`、`rst_n` 共同断言）+ **与契约条款的逐条对照（全部一致）** + 验证状态表 + 6 项未决。④ **★2 订正两处误导性注释**：`frame_swap_ctrl.v` 把 `swap_ack` 写成"A→B toggle 的边沿事件"（实际是**已取边沿的单拍**，易被读成"还得自己再检测一次"，正好踩 A 警告的坑）；`memory_arbiter.v` 头注写"O-3 建议 16 或 32 word"（与集成实取值 64 不一致）。**只改注释，RTL 行为零改动**。⑤ **★3 新增 `tb_ab_storage_contract.sv`（16 项，ModelSim 可跑）**：补现有 TB 的真空 —— **★ CDC 往返"恰好一次"**（5 次换帧 ⇒ A 侧恰好 5 次 req / 5 次 ack、B 侧 5 次提交、`swap_req` 5 次翻转；这正是"再次转 toggle"会破坏的性质）、**★ 无效 CRC 不提交不 ACK**（现有 `tb_frame_swap_ctrl` 里 `wr_crc` **恒为 1**，这条分支从没跑过）、以及 `rd_len` 恒 64 / `rd_ack` 单拍 / 每突发 `rd_data_valid` 计数 == `rd_len` / `data_valid` 只在 `busy` 期间 / 突发内 `mem_addr` **+4**。★ **不重复 A 的 TB**：A 的 `tb_a_video_display_core.sv` 是 XSim 上的**端到端功能验证**（且本机**没装 Vivado**），本 TB 是 B 侧的**契约守门**（用符合契约的驱动模型驱动 B 的模块）。⑥ **回归 588 → 604 项 / 22 → 23 个 TB 全 PASS**、`check_repo.ps1` → `LAYOUT PASS`；`run_sim.ps1` 三个列表同步。⑦ **★ 顺手发现两个待处理项**：(a) **验证入口碎片化** —— 8 个 `run_*.ps1`，且 `run_sim.ps1` **完全不含 A 的 9 个 `tb_a_*`** ⇒ **没有"全绿"总门禁**；(b) **文档口径矛盾** —— `test_matrix.md` 写自研 `C1→C1` setup **+0.113 ns / 0 违例**，而 `README.md` 同一项写 **−0.094 ns / 1 端点**，两处互相矛盾，需回 `phy_1/final_timing.rpt` 核对后统一。 |
| 2026-10-05 | **★ 做 ★4：收敛验证入口（新增 `run_all.ps1` 总入口 + `test_matrix.md` 的"验证入口总清单"）+ 核对时序口径。** ① **新增 `safevision/tools/run_all.ps1`**：依次跑 12 个入口里**本机能跑的**，**跑不了的明确报 `SKIP` 并说明缺什么、绝不报 PASS**；**只有 `RESULT: ALL PASS` 才 exit 0**，有 SKIP 时输出 `INCOMPLETE` 并列出被跳过项；本地可用 `-AllowSkip`（但结果行仍写 INCOMPLETE）。② **`test_matrix.md` 新增"★★ 验证入口总清单"**：12 个入口逐条列出**工具链 / 覆盖什么 / 通过判据 / 前置条件**（逐个读脚本得来，不是猜的）。③ **★ 实测（`run_all.ps1 -AllowSkip`）：`PASS=4 FAIL=0 SKIP=7`** —— PASS 的是 `run_sim.ps1`（604/0）、`run_clock_sim.ps1`（88 项）、`run_sdram_loopback_sim.ps1`（走 ModelSim 兜底）、**`run_a_display_sta.ps1`（TD 装着！）**；SKIP 的 7 项（#3 #4 #6 #7 #8 #9 #10）**全因本机没装 Vivado/XSim**。★★ **两台机器的路径必须分清（订正）**：`D:\Xilinx\Vivado\2018.3\bin` 是 **A 的机器**上的路径（所有 `run_*xsim*` / `run_a_*` 脚本的 `-XSimBin` 默认值）；`D:\Anlogic\TD_6.2.1_Engineer_6.2.168.116` 与 `D:\modeltech64_10.7\win64` 才是 **B 这台机器**上的。先前我把 `D:\Xilinx` 说成"本机路径"并据此断言"本机只有 ModelSim"——**说错了**：那只是脚本默认值（A 的机器），而 **B 这台机器装了 TD**，所以 #11（A 显示核心内部 STA）在本机实测 PASS。④ **★ 时序口径核对（结论：不是矛盾，是我读错了）**：`−0.094 ns` 是"两级报告选择器"修复**前**的值、`+0.113 ns` 是修复**后**的值，两处 before→after 表述本来一致；**真正写错的只有 `README.md` 一处**（把修复前的旧值当成当前值）⇒ **已订正**。**权威来源**：`project/report22.txt`（2026-10-04 20:53，顶层 `top_sdram_loopback`）—— 自研 `clkc[1]→clkc[1]` **+0.113 ns / 0 违例 / 2517 端点**；`clk→clkc[1]` +1.360 / 0 / 26；`clk→clk` +18.694 / 0 / 1；`clkc[1]→clkc[2]` **−2.859 / 32 / 48**；`clkc[2]→clkc[1]` **−6.826 / 32 / 32**（**全局 −6.826 就是这一组**）。★ 另注：`safevision_Runs/phy_1/final_timing.rpt` **当前不在磁盘上**（TD 运行目录被清理过），引用时请用 `project/report*.txt` 系列。⑤ **`run_sim.ps1` 三个列表不动**（本次只加聚合脚本，不改主回归）。⑥ **回归仍 604 项 / 23 个 TB 全 PASS**、`check_repo.ps1` → `LAYOUT PASS`。 |
| 2026-10-05 | **★★ 做"把阶段串起来"的集成测试：新增 `tb_b_frame_memory.sv`（14 项，B 侧半段端到端）；A+B 显示级 TB 已写好但**卡在 ModelSim 工具限制**。回归 604 → 618 全 PASS。** ① **新增 `tb_b_frame_memory.sv`（14 项）**：把 **阶段 8（媒体）+ 10（帧写）+ 11（突发）+ 13（仲裁）串成一条**，端到端断言"**真 BMP → 帧缓存内容**" —— TB 生成真 BMP 字节流（54 B 头 + 640×480×24bit、**自底向上**）→ `bmp_parser` → `bmp_unpack` → `frame_writer`（2 像素/word + CRC）→ `memory_arbiter` 写通道 → 真存真取存储模型 → **`memory_arbiter` 读通道**（A 的显示核心就是从这读的）→ 按 A 的读契约读回**逐字比对**。**结果：`wok=153600 wbad=0`** —— 帧缓存 153600 个 word **逐字与源 BMP 像素一致**；另验 `rd_ack` 单拍、`rd_data_valid` 只在 `rd_busy` 期间、2400 次突发 ack。★ **补的是真空**：`bmp_unpack` 的 TB 只看像素流、`frame_writer` 的 TB 用**合成图案**，**没人验过"真 BMP → 帧缓存内容"**。② **A+B 显示级全链路 TB 已写好但未跑**：`verification/unit/tb_ab_frame_display.sv.xsim_handover`（真 BMP → … → A 的 `a_video_display_core` → 屏幕像素，断言显示像素 == BMP 像素）。**卡在 ModelSim 的 vopt 崩溃**：A 的 `a_pixel_fifo_ip.v` **vlog 能过、vopt 崩**（`ram_inst` 端口连接不全：Expected 16 found 14，缺 `dib`/`doa`），`-novopt` 也不行 ⇒ **A 的显示核心只能在 XSim 上跑**（A 的脚本本来如此）。⇒ 该 TB **留给 A 在 XSim 上跑**（或本机装 Vivado 后跑）。③ **★ 本轮踩到并记档的两个 Questa 10.7 陷阱**（都让调试白花几十分钟）：(a) **`func(...)[7:0]`（对函数返回值直接位选）会让 vopt 内部崩溃**（`vgenexpr.c(3346)`，报在**文件最后一行** `endmodule`，极难定位）⇒ 必须**先存临时变量再选位**；(b) **在 `always` 里用了"声明在它后面"的 wire ⇒ 隐式 1 bit 网线、永不驱动** ⇒ 表现是**整条链卡在第 N 字节且无报错**（本 TB 实测：`.ready(bp_ready)` 接错名字 ⇒ `bmp_ready` 悬空 ⇒ 卡在第 1 字节；另有"忘了拉 `fw_start`"⇒ `frame_writer` 没启动 ⇒ 卡在第 59 字节）。两条都已写进 `test_matrix.md` 记档。④ **回归 604 → 618 项 / 23 → 24 个 TB 全 PASS**（耗时 2m42s）、`check_repo.ps1` → `LAYOUT PASS`。⑤ **待办**：把 A+B 显示级 TB 交 A 在 XSim 跑；并**确认一个时钟域问题** —— 本 TB 把 `bmp_parser`/`bmp_unpack` 与 `frame_writer` 都放在 mem_clk，**若产品里这两级跨域，需要补 CDC FIFO**。 |
| 2026-10-05 | **★★ 试 #1 成功：只改 A 的一个文件的端口连接，就让 A 的显示核心在 ModelSim 上跑起来，并拿到 A+B 全链路显示级结论（逐点 0 错）。** ① **根因**：`a_pixel_fifo_ip.v` 里 `ram_inst`（ERAM）只写了 **14/16** 个端口，漏掉 **`doa`（A 口读数据）与 `dib`（B 口写数据）** —— 这两个口在 **SDP 模式下本来就不用**，所以 **XSim 容忍**，但 **ModelSim 的 vopt 会报 `Too few port connections ... Expected 16, found 14` 并在代码生成阶段内部崩溃**（`-novopt` 也不行）。② **修法（零功能改动）**：把这两个端口**显式写出来**（`doa` 留空、`dib` 接 0）⇒ 实测 `[PROBE-A] elaborated and ran OK` ✓。★ **该改动在 A 的文件里，已加注释说明来由，请 A 确认无异议**（综合与仿真行为不变）。③ **A+B 全链路 TB 现在能跑**（`tb_ab_frame_display.sv`，从 `.xsim_handover` 恢复并修好同批 TB 写法问题）：真 BMP 字节流 → `bmp_parser` → `bmp_unpack` → `frame_writer` → `memory_arbiter` 写通道 → 真存真取存储 → `memory_arbiter` 读通道 → **A 的 `a_video_display_core`** → 屏幕像素；**实测 `ok=9950458  bad=0`** —— **显示侧逐点与源 BMP 像素完全一致** ✓✓（另有 `bi=921654` 全 BMP 字节、`fw_px=307200` 整帧写完、`slotv=0010`、`pix_active_valid=1`）。④ **⚠️ 但该 TB 暂未进门禁**：换帧记账（`swap_error`/`commits`）读数不对，属 **TB 自身监视/等待写法问题**（不是 DUT 问题），收尾后再考虑加进 `run_sim.ps1`；**在此之前不要拿它当"整机通过"的依据**（整机结论以逐点 `bad=0` 为准，并以 A 的 XSim TB 独立复核）。⑤ **★ 又记档两个 TB 写法陷阱**（都实测踩过）：(a) **`wait (<单拍信号>)` 会永久挂住**（单拍信号若在 `wait` 之前闪过就等不到）⇒ **要等电平信号**；(b) **不要给期望值额外加延迟** —— A 的 core 输出端 `x`/`y` 本身就是延迟后的扫描坐标，再加 5 拍 = 拿 `x-5` 的期望比 `x` 的像素（表现是"每个像素都错、像横向平移 5 像素"）。⑥ **回归 618 项 / 24 个 TB 仍全 PASS**（3m04s），`check_repo.ps1` → `LAYOUT PASS`。 |
| 2026-10-04 | **★★★ M-11 补测「高位地址稀疏样本」板上通过（条目 M-11-PASS-3；旧 B 图案构建）—— 报告 136 Byte 与当时设计值一致、`BAD=0000`。** 采集（`Serial Debug 2026-10-04 103822.txt`，HEX 导出 408 B = 136×3）解码后 **136 字节**：`SV-SDRAM-LOOP` / `INIT=01 LOCK=01` / **`CFG=0B1 BASE=000000 N=000400`** / **`W=0400 R=0400 CAP=0400 BAD=0000`** / **`BAD0=FFFFFF E=00000000 A=00000000`** / `DONE`，真 CRLF、无前导 `0x00`，**与设计值逐字节一致**。⇒ **步长 2049 × 1024 个样本跨越近乎整个 2M-word 地址范围，所选点读回正确**。后续 A `d6f40a6` 按实际行/列/bank 映射复核：此参数不扫描全部 bank、row、column，故本条只证明该批样本回读与地址混叠检查通过，**不能宣称全地址译码覆盖**。★ **报告自证**：`CFG=0B1` 与 136 Byte 格式**只存在于新版 RTL** ⇒ 这一条同时证明**综合真的采用了含 `sdr_pat_gen.v` 的新代码**（不必再单独去 `run.log` 确认顶层名 —— 报告本身就是证据）。★ 同时本轮修掉一个"看起来在测、其实几乎没测"的真问题：**旧图案公式只用了 `a[11:4]`/`a[7:0]`，在步长 2^11 下 1024 个点只有 2 种图案**（写读自比看不出来，已由 `tb_sdr_pat_gen` 的 T7 反向对照守住）。★ 归档：`evidence/board/uart_report_sdram_sparse_scan_20261004_103822_hex.txt`（HEX 文本 SHA-256 `AA0F261E…44CEFEF`；解码后 136 B，SHA-256 `5BE3B939…4452BDB`），`INDEX.md` 条目 **M-11-PASS-3**。★ 至此 **M-11 的两轮（连续 16 KB + 全片稀疏）都过了**。 |
| 2026-10-04 | **★ 做「扩展图案 + soak」：6 种图案模式 + `ROUNDS` 轮次循环 + 报告扩到 190 Byte；回归 574 → 588 全 PASS。** ① **6 种图案模式**（`sdr_pat_gen` 加 `mode` 输入，逐轮轮换）：`0 ADDR`（地址派生，单射 ⇒ 治地址译码）/ `1 LFSR`（xorshift32，双射 ⇒ 压数据线串扰）/ `2 WALK1`、`3 WALK0`（单根数据线为 1/0 在走 ⇒ 治线间粘连/短路）/ `4 ALT`（全 0 全 1 交替 ⇒ 最坏功耗图案）/ `5 ADJ`（相邻位反向 ⇒ 压相邻线耦合）。② **soak（`ROUNDS` 参数）**：把「写→等落地→读→等收齐」当一轮重复 N 轮，**每轮换一种模式**；`tot_cnt`（40 位，不重置）累计搬运量 ⇒ 报告 `TOT` 就是手册 7.12 要的"实际完成搬运的数据量"口径。★ **出错立即停（fail fast）**：某轮不一致就不再跑后面的轮次，直接出报告 —— 报告里的 `RND` 就是**出错那一轮**。③ **报告 136 → 190 Byte**：加 `RND=hhhhhhhh/hhhhhhhh PAT=h`、`TOT=hhhhhhhhhh`，并给 `BAD0` 加上**轮次**（`BAD0=hhhhhhhh:hhhhhh E=… A=…`）。★ 轮时长**实测 ≈ 22 µs**（2790 拍 @125 MHz）⇒ `ROUNDS ≈ 目标秒数 × 45_000`，60 分钟约 `ROUNDS=1.6e8`（32 位够用）。★ **soak 期间"没有输出"就是好消息**（出错会立刻出报告）。④ **★ 仿真桩改成"真存真取"**（`vendor_ip_stub` 由"按地址算图案"改成 2M×32 bit 理想存储器）—— 因为顶层现在有 6 种模式，桩不可能去猜当前用哪种；同时加了**故障注入**钩子（`STUB_ERR_ADDR`/`STUB_ERR_XOR`）。⑤ **带桩 TB 扩到 8 项**：**阶段 1**（`ROUNDS=3`）验报告**逐字节**正确、`RND=00000003/00000003 PAT=2`（证明 **soak 轮次与模式轮换真的生效**）、`led=8`；**阶段 2**（在 `0x2805` 注入 1 bit 错）验**只跑 1 轮就出报告**、`BAD=0001`、**`BAD0=00000001:002805 E=88002805 A=88002804`**（轮次:地址 精确定位）、`led=3`。⑥ **★ TB 抓出一个真缺陷**：**xorshift 的 0 是不动点** ⇒ 原来"用地址**异或**播种"总有一个地址会输出**全 0**（最弱图案，还会掩盖"数据线卡死在 0"）⇒ 改成**加非零常数**播种（保证种子永不为 0，且仍是双射）。⑦ **回归 574 → 588 项 / 22 个 TB 全 PASS**（`tb_sdr_pat_gen` 11→**22**、`tb_top_sdram_loopback` 5→**8**）。⑧ **板级 soak 已完成（2026-10-04）**：450,000 轮（约 10 秒）、27,000,000 轮（约 10 分钟）、161,000,000 轮（约 60 分钟）均 `BAD=0000`、`BAD0` 无错哨兵、正常 `DONE`；60 分钟累计 `TOT=2662A90000`。report20 显示自研组仍有 1/1919 端点 `SWNS=-0.138 ns`，全局 SDRAM C1/C2 DQ 接口仍负余量，故板测通过不等于 STA 收敛。全量 ModelSim preflight run log 只在本机留存、不进版本库；板级 UART HEX 若作为正式原始证据，则按 §2.4.2 步 9 精选归档并更新索引。 |